/// <mls fileReference="_102043_/l4/workflows/promotionSuggestionLifecycle.defs.ts" enhancement="_blank"/>

export const promotionSuggestionLifecycleDef = {
  "schemaVersion": "2026-06-06",
  "artifactType": "workflow",
  "artifactId": "promotionSuggestionLifecycle",
  "moduleName": "cafeFlow",
  "status": "draft",
  "source": {
    "agentName": "agentPlanWorkflowDefinition",
    "stepId": 76,
    "planId": ""
  },
  "data": {
    "workflowDefinition": {
      "workflowId": "promotionSuggestionLifecycle",
      "title": "Ciclo de Vida de Sugestão de Promoção",
      "purpose": "Gerenciar as sugestões de promoção geradas pela IA, desde a criação até a revisão, aprovação, rejeição ou expiração.",
      "executionMode": "entityLifecycle",
      "createsTask": false,
      "taskConfig": {
        "taskTitleTemplate": "",
        "assigneeRules": [],
        "slaRules": [],
        "taskRoomRequired": false
      },
      "actors": [
        "assistenteIA",
        "gerente"
      ],
      "states": [
        {
          "stateId": "new",
          "description": "Sugestão recém-gerada e aguardando revisão."
        },
        {
          "stateId": "reviewed",
          "description": "Sugestão revisada e pronta para decisão final."
        },
        {
          "stateId": "approved",
          "description": "Sugestão aprovada para promoção."
        },
        {
          "stateId": "rejected",
          "description": "Sugestão rejeitada pelo gerente."
        },
        {
          "stateId": "expired",
          "description": "Sugestão expirada por falta de ação ou validade encerrada."
        }
      ],
      "transitions": [
        {
          "from": "new",
          "to": "reviewed",
          "trigger": "reviewSuggestion",
          "actor": "gerente",
          "conditions": [],
          "actions": [
            "write PromotionSuggestion.suggestion_status = \"reviewed\"",
            "write PromotionSuggestion.updated_at = now"
          ],
          "rulesApplied": []
        },
        {
          "from": "reviewed",
          "to": "approved",
          "trigger": "approveSuggestion",
          "actor": "gerente",
          "conditions": [],
          "actions": [
            "write PromotionSuggestion.suggestion_status = \"approved\"",
            "write PromotionSuggestion.updated_at = now"
          ],
          "rulesApplied": []
        },
        {
          "from": "reviewed",
          "to": "rejected",
          "trigger": "rejectSuggestion",
          "actor": "gerente",
          "conditions": [],
          "actions": [
            "write PromotionSuggestion.suggestion_status = \"rejected\"",
            "write PromotionSuggestion.updated_at = now"
          ],
          "rulesApplied": []
        },
        {
          "from": "new",
          "to": "expired",
          "trigger": "expireSuggestion",
          "actor": "assistenteIA",
          "conditions": [],
          "actions": [
            "write PromotionSuggestion.suggestion_status = \"expired\"",
            "write PromotionSuggestion.updated_at = now"
          ],
          "rulesApplied": []
        },
        {
          "from": "reviewed",
          "to": "expired",
          "trigger": "expireReviewedSuggestion",
          "actor": "assistenteIA",
          "conditions": [],
          "actions": [
            "write PromotionSuggestion.suggestion_status = \"expired\"",
            "write PromotionSuggestion.updated_at = now"
          ],
          "rulesApplied": []
        }
      ],
      "requiredEntities": [
        "PromotionSuggestion",
        "MenuItem"
      ],
      "persistenceRefs": [
        "promotionSuggestion"
      ],
      "usecaseRefs": [
        "usecaseGerarSugestoesPromocaoIA"
      ],
      "metricRefs": [],
      "userActions": [
        "revisarSugestao",
        "aprovarSugestao",
        "rejeitarSugestao"
      ],
      "relatedPages": [],
      "relatedAgents": [
        "assistenteIA"
      ],
      "relatedPlugins": [],
      "rulesApplied": [],
      "implementationSuggestions": [
        {
          "suggestionId": "suggPromoReviewTask",
          "title": "Criar tarefa de revisão para o gerente",
          "priority": "soon",
          "description": "Apesar de o workflow não criar tarefas, adicionar um task workflow futuro pode garantir que o gerente revise sugestões dentro do prazo.",
          "tradeoff": "Exige configuração adicional de tarefas e possíveis notificações para não sobrecarregar o gerente."
        }
      ],
      "workflowScope": "singleModule",
      "moduleRefs": [
        "cafeFlow"
      ],
      "pageRefsByModule": [],
      "entityRefsByModule": [
        {
          "moduleId": "cafeFlow",
          "entity": "PromotionSuggestion"
        }
      ],
      "writesArtifacts": [
        {
          "moduleId": "cafeFlow",
          "artifactType": "workflow",
          "artifactId": "promotionSuggestionLifecycle"
        }
      ]
    },
    "defsPlan": {
      "fileName": "workflows/promotionSuggestionLifecycle.defs.ts",
      "exportName": "promotionSuggestionLifecycleDef",
      "saveAsDefs": true
    }
  }
} as const;

export default promotionSuggestionLifecycleDef;
