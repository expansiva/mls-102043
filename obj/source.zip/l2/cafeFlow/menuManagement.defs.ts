/// <mls fileReference="_102043_/l2/cafeFlow/menuManagement.defs.ts" enhancement="_blank"/>

export const menuManagementPagePlan = {
  "schemaVersion": "2026-06-06",
  "artifactType": "page",
  "artifactId": "menuManagement",
  "moduleName": "cafeFlow",
  "status": "draft",
  "source": {
    "agentName": "agentPlanPageDefinition",
    "stepId": 82,
    "planId": ""
  },
  "data": {
    "pageDefinition": {
      "pageId": "menuManagement",
      "pageName": "Gerenciar Cardápio",
      "actor": "gerente",
      "purpose": "Criar e manter itens do cardápio e suas receitas.",
      "capabilities": [
        "gerenciarCardapio"
      ],
      "flowRefs": {
        "experienceFlows": [],
        "entityLifecycles": [],
        "taskWorkflows": [],
        "automations": []
      },
      "pluginRefs": [],
      "mdmRefs": [
        "menuItem",
        "ingredient"
      ],
      "pageInputs": [],
      "navigationRefs": [
        {
          "direction": "outbound",
          "pageId": "inventoryManagement",
          "trigger": "ajustar ingredientes",
          "description": "Ir para ajustes de estoque e ingredientes quando necessário."
        }
      ],
      "sections": [
        {
          "sectionName": "Lista de itens do cardápio",
          "mode": "view",
          "organisms": [
            {
              "organismName": "listaItensCardapio",
              "purpose": "Exibir itens existentes do cardápio com preço e resumo da receita.",
              "userActions": [
                "visualizarItem",
                "selecionarItemParaEdicao"
              ],
              "requiredEntities": [
                "menuItemEntity",
                "recipeLineEntity"
              ],
              "readsFields": [
                "MenuItem.id",
                "MenuItem.nome",
                "MenuItem.preco",
                "RecipeLine.ingredientId",
                "RecipeLine.quantidade"
              ],
              "writesFields": [],
              "rulesApplied": [
                "rule-menuitem-recipe-required"
              ]
            }
          ]
        },
        {
          "sectionName": "Criar novo item",
          "mode": "edit",
          "organisms": [
            {
              "organismName": "formularioNovoItemCardapio",
              "purpose": "Cadastrar item do cardápio com preço e receita obrigatória.",
              "userActions": [
                "informarNome",
                "informarPreco",
                "adicionarLinhaReceita",
                "removerLinhaReceita",
                "salvarItem"
              ],
              "requiredEntities": [
                "menuItemEntity",
                "recipeLineEntity",
                "ingredientEntity"
              ],
              "readsFields": [
                "Ingredient.id",
                "Ingredient.nome",
                "Ingredient.unidadeMedida"
              ],
              "writesFields": [
                "MenuItem.nome",
                "MenuItem.preco",
                "RecipeLine.ingredientId",
                "RecipeLine.quantidade"
              ],
              "rulesApplied": [
                "rule-menuitem-recipe-required"
              ]
            }
          ]
        }
      ]
    },
    "bffCommands": [
      {
        "commandName": "listMenuItems",
        "purpose": "Exibir itens existentes do cardápio com preço e receita.",
        "kind": "query",
        "input": {
          "filtros": {
            "nome": "string?",
            "ativo": "boolean?"
          }
        },
        "output": {
          "items": [
            {
              "id": "string",
              "nome": "string",
              "preco": "number",
              "receita": [
                {
                  "ingredientId": "string",
                  "quantidade": "number"
                }
              ]
            }
          ]
        },
        "readsEntities": [
          "menuItemEntity",
          "recipeLineEntity"
        ],
        "writesEntities": [],
        "readsTables": [],
        "writesTables": [],
        "usecaseRefs": [
          "usecaseGerenciarCardapio"
        ],
        "layerContract": {
          "controllerLayer": "layer_2_controllers",
          "mustCallLayer": "layer_3_usecases",
          "directTableAccessForbidden": true
        },
        "rulesApplied": [
          "rule-menuitem-recipe-required"
        ]
      },
      {
        "commandName": "listIngredientsForRecipe",
        "purpose": "Listar ingredientes disponíveis para compor a receita do item.",
        "kind": "query",
        "input": {
          "filtros": {
            "nome": "string?"
          }
        },
        "output": {
          "items": [
            {
              "id": "string",
              "nome": "string",
              "unidadeMedida": "string"
            }
          ]
        },
        "readsEntities": [
          "ingredientEntity"
        ],
        "writesEntities": [],
        "readsTables": [],
        "writesTables": [],
        "usecaseRefs": [
          "usecaseGerenciarCardapio"
        ],
        "layerContract": {
          "controllerLayer": "layer_2_controllers",
          "mustCallLayer": "layer_3_usecases",
          "directTableAccessForbidden": true
        },
        "rulesApplied": []
      },
      {
        "commandName": "createMenuItem",
        "purpose": "Criar novo item do cardápio com receita.",
        "kind": "command",
        "input": {
          "nome": "string",
          "preco": "number",
          "receita": [
            {
              "ingredientId": "string",
              "quantidade": "number"
            }
          ]
        },
        "output": {
          "id": "string",
          "nome": "string",
          "preco": "number",
          "receita": [
            {
              "ingredientId": "string",
              "quantidade": "number"
            }
          ]
        },
        "readsEntities": [
          "ingredientEntity"
        ],
        "writesEntities": [
          "menuItemEntity",
          "recipeLineEntity"
        ],
        "readsTables": [],
        "writesTables": [],
        "usecaseRefs": [
          "usecaseGerenciarCardapio"
        ],
        "layerContract": {
          "controllerLayer": "layer_2_controllers",
          "mustCallLayer": "layer_3_usecases",
          "directTableAccessForbidden": true
        },
        "rulesApplied": [
          "rule-menuitem-recipe-required"
        ]
      }
    ]
  }
} as const;

export default menuManagementPagePlan;
