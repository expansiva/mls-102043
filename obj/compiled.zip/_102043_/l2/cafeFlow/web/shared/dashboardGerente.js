var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102043_/l2/cafeFlow/web/shared/dashboardGerente.ts" enhancement="_102027_/l2/enhancementLit.ts" />
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, } from '/_102029_/l2/interactionRuntime.js';
import { subscribe, unsubscribe, getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Cafe Flow',
    pageTitle: 'Dashboard Gerente',
    loaded: 'Dados carregados',
    couldNotLoad: 'Nao foi possivel carregar',
    loadingConsultarDashboardGerente: 'Carregando métricas do dashboard do gerente',
    loadingListarAlertasEstoqueBaixo: 'Carregando alertas de estoque baixo',
};
const message_en = {
    brand: 'Cafe Flow',
    pageTitle: 'Manager Dashboard',
    loaded: 'Data loaded',
    couldNotLoad: 'Could not load',
    loadingConsultarDashboardGerente: 'Loading manager dashboard metrics',
    loadingListarAlertasEstoqueBaixo: 'Loading low stock alerts',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class DashboardGerenteBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            'ui.dashboardGerente.totalRevenue',
            'ui.dashboardGerente.orderCount',
            'ui.dashboardGerente.averageTicket',
            'ui.dashboardGerente.itemsSold',
            'ui.dashboardGerente.serieVendasPorTurno',
            'ui.dashboardGerente.rankingItensMaisVendidos',
            'ui.dashboardGerente.alertasEstoqueBaixo',
        ];
        this.totalRevenue = undefined;
        this.orderCount = undefined;
        this.averageTicket = undefined;
        this.itemsSold = undefined;
        this.serieVendasPorTurno = undefined;
        this.rankingItensMaisVendidos = undefined;
        this.alertasEstoqueBaixo = [];
        this.status = '';
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, { mode: 'silent', signal: pendingLoad?.signal });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
        subscribe(this._stateKeys, this);
        this._stateKeys.forEach(key => {
            const v = getState(key);
            if (v !== undefined)
                this.handleIcaStateChange(key, v);
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe(this._stateKeys, this);
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.dashboardGerente.totalRevenue':
                this.totalRevenue = value ?? 0;
                break;
            case 'ui.dashboardGerente.orderCount':
                this.orderCount = value ?? 0;
                break;
            case 'ui.dashboardGerente.averageTicket':
                this.averageTicket = value ?? 0;
                break;
            case 'ui.dashboardGerente.itemsSold':
                this.itemsSold = value ?? 0;
                break;
            case 'ui.dashboardGerente.serieVendasPorTurno':
                this.serieVendasPorTurno = value ?? '';
                break;
            case 'ui.dashboardGerente.rankingItensMaisVendidos':
                this.rankingItensMaisVendidos = value ?? '';
                break;
            case 'ui.dashboardGerente.alertasEstoqueBaixo':
                this.alertasEstoqueBaixo = value ?? [];
                break;
            default:
                break;
        }
    }
    async loadInitialData(params, options) {
        await this.loadConsultarDashboardGerente(params, options);
        await this.loadListarAlertasEstoqueBaixo(undefined, options);
    }
    async loadConsultarDashboardGerente(params, options) {
        if (window.mls) {
            this.totalRevenue = 1250;
            setState('ui.dashboardGerente.totalRevenue', this.totalRevenue);
            this.orderCount = 48;
            setState('ui.dashboardGerente.orderCount', this.orderCount);
            this.averageTicket = 26;
            setState('ui.dashboardGerente.averageTicket', this.averageTicket);
            this.itemsSold = 132;
            setState('ui.dashboardGerente.itemsSold', this.itemsSold);
            this.serieVendasPorTurno = 'Manhã';
            setState('ui.dashboardGerente.serieVendasPorTurno', this.serieVendasPorTurno);
            this.rankingItensMaisVendidos = 'Capuccino';
            setState('ui.dashboardGerente.rankingItensMaisVendidos', this.rankingItensMaisVendidos);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('cafeFlow.dashboardGerente.consultarDashboardGerente', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.totalRevenue = response.data.totalRevenue;
        setState('ui.dashboardGerente.totalRevenue', this.totalRevenue);
        this.orderCount = response.data.orderCount;
        setState('ui.dashboardGerente.orderCount', this.orderCount);
        this.averageTicket = response.data.averageTicket;
        setState('ui.dashboardGerente.averageTicket', this.averageTicket);
        this.itemsSold = response.data.itemsSold;
        setState('ui.dashboardGerente.itemsSold', this.itemsSold);
        this.serieVendasPorTurno = response.data.serieVendasPorTurno;
        setState('ui.dashboardGerente.serieVendasPorTurno', this.serieVendasPorTurno);
        this.rankingItensMaisVendidos = response.data.rankingItensMaisVendidos;
        setState('ui.dashboardGerente.rankingItensMaisVendidos', this.rankingItensMaisVendidos);
        this.status = this.msg.loaded;
    }
    async loadListarAlertasEstoqueBaixo(params, options) {
        if (window.mls) {
            this.alertasEstoqueBaixo = [
                { alertas: 'Estoque baixo de leite' },
                { alertas: 'Estoque baixo de café' },
                { alertas: 'Estoque baixo de açúcar' },
            ];
            setState('ui.dashboardGerente.alertasEstoqueBaixo', this.alertasEstoqueBaixo);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('cafeFlow.dashboardGerente.listarAlertasEstoqueBaixo', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.alertasEstoqueBaixo = response.data;
        setState('ui.dashboardGerente.alertasEstoqueBaixo', this.alertasEstoqueBaixo);
        this.status = this.msg.loaded;
    }
}
__decorate([
    property()
], DashboardGerenteBase.prototype, "totalRevenue", void 0);
__decorate([
    property()
], DashboardGerenteBase.prototype, "orderCount", void 0);
__decorate([
    property()
], DashboardGerenteBase.prototype, "averageTicket", void 0);
__decorate([
    property()
], DashboardGerenteBase.prototype, "itemsSold", void 0);
__decorate([
    property()
], DashboardGerenteBase.prototype, "serieVendasPorTurno", void 0);
__decorate([
    property()
], DashboardGerenteBase.prototype, "rankingItensMaisVendidos", void 0);
__decorate([
    property()
], DashboardGerenteBase.prototype, "alertasEstoqueBaixo", void 0);
__decorate([
    property()
], DashboardGerenteBase.prototype, "status", void 0);
