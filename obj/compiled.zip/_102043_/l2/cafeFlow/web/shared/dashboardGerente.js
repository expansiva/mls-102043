var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102043_/l2/cafeFlow/web/shared/dashboardGerente.ts" enhancement="_102027_/l2/enhancementLit.ts" />
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, } from '/_102029_/l2/interactionRuntime.js';
import { subscribe, unsubscribe, getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'CafeFlow',
    pageTitle: 'Dashboard do gerente',
    loaded: 'Dados carregados',
    couldNotLoad: 'Não foi possível carregar',
    loadingConsultarDashboardGerente: 'Carregando visão geral do dia',
    loadingListarAlertasEstoqueBaixo: 'Carregando alertas de estoque baixo',
};
const message_en = {
    brand: 'CafeFlow',
    pageTitle: 'Manager Dashboard',
    loaded: 'Data loaded',
    couldNotLoad: 'Could not load',
    loadingConsultarDashboardGerente: 'Loading dashboard overview',
    loadingListarAlertasEstoqueBaixo: 'Loading low stock alerts',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class DashboardGerenteDashboardGerenteBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            'ui.dashboardGerente.totalRevenue',
            'ui.dashboardGerente.orderCount',
            'ui.dashboardGerente.averageTicket',
            'ui.dashboardGerente.itemsSold',
            'ui.dashboardGerente.serieVendasPorTurno',
            'ui.dashboardGerente.rankingItensMaisVendidos',
            'ui.dashboardGerente.alertasEstoqueBaixo',
        ];
        this.totalRevenue = undefined;
        this.orderCount = undefined;
        this.averageTicket = undefined;
        this.itemsSold = undefined;
        this.serieVendasPorTurno = undefined;
        this.rankingItensMaisVendidos = undefined;
        this.alertasEstoqueBaixo = [];
        this.status = '';
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, { mode: 'silent', signal: pendingLoad?.signal });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
        subscribe(this._stateKeys, this);
        this._stateKeys.forEach(key => {
            const v = getState(key);
            if (v !== undefined)
                this.handleIcaStateChange(key, v);
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe(this._stateKeys, this);
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.dashboardGerente.totalRevenue':
                this.totalRevenue = value ?? undefined;
                break;
            case 'ui.dashboardGerente.orderCount':
                this.orderCount = value ?? undefined;
                break;
            case 'ui.dashboardGerente.averageTicket':
                this.averageTicket = value ?? undefined;
                break;
            case 'ui.dashboardGerente.itemsSold':
                this.itemsSold = value ?? undefined;
                break;
            case 'ui.dashboardGerente.serieVendasPorTurno':
                this.serieVendasPorTurno = value ?? undefined;
                break;
            case 'ui.dashboardGerente.rankingItensMaisVendidos':
                this.rankingItensMaisVendidos = value ?? undefined;
                break;
            case 'ui.dashboardGerente.alertasEstoqueBaixo':
                this.alertasEstoqueBaixo = value ?? [];
                break;
            default:
                break;
        }
    }
    async loadInitialData(params, options) {
        await this.loadConsultarDashboardGerente(params, options);
        await this.loadListarAlertasEstoqueBaixo(undefined, options);
    }
    async loadConsultarDashboardGerente(params, options) {
        if (window.mls) {
            this.totalRevenue = 1250;
            setState('ui.dashboardGerente.totalRevenue', this.totalRevenue);
            this.orderCount = 48;
            setState('ui.dashboardGerente.orderCount', this.orderCount);
            this.averageTicket = 26;
            setState('ui.dashboardGerente.averageTicket', this.averageTicket);
            this.itemsSold = 120;
            setState('ui.dashboardGerente.itemsSold', this.itemsSold);
            this.serieVendasPorTurno = 'id-001';
            setState('ui.dashboardGerente.serieVendasPorTurno', this.serieVendasPorTurno);
            this.rankingItensMaisVendidos = 'id-002';
            setState('ui.dashboardGerente.rankingItensMaisVendidos', this.rankingItensMaisVendidos);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('cafeFlow.dashboardGerente.consultarDashboardGerente', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.totalRevenue = response.data.totalRevenue;
        setState('ui.dashboardGerente.totalRevenue', this.totalRevenue);
        this.orderCount = response.data.orderCount;
        setState('ui.dashboardGerente.orderCount', this.orderCount);
        this.averageTicket = response.data.averageTicket;
        setState('ui.dashboardGerente.averageTicket', this.averageTicket);
        this.itemsSold = response.data.itemsSold;
        setState('ui.dashboardGerente.itemsSold', this.itemsSold);
        this.serieVendasPorTurno = response.data.serieVendasPorTurno;
        setState('ui.dashboardGerente.serieVendasPorTurno', this.serieVendasPorTurno);
        this.rankingItensMaisVendidos = response.data.rankingItensMaisVendidos;
        setState('ui.dashboardGerente.rankingItensMaisVendidos', this.rankingItensMaisVendidos);
        this.status = this.msg.loaded;
    }
    async loadListarAlertasEstoqueBaixo(params, options) {
        if (window.mls) {
            this.alertasEstoqueBaixo = [
                { alertas: 'Café em grãos' },
                { alertas: 'Leite integral' },
                { alertas: 'Copos descartáveis' },
            ];
            setState('ui.dashboardGerente.alertasEstoqueBaixo', this.alertasEstoqueBaixo);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('cafeFlow.dashboardGerente.listarAlertasEstoqueBaixo', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.alertasEstoqueBaixo = response.data;
        setState('ui.dashboardGerente.alertasEstoqueBaixo', this.alertasEstoqueBaixo);
        this.status = this.msg.loaded;
    }
}
__decorate([
    property()
], DashboardGerenteDashboardGerenteBase.prototype, "totalRevenue", void 0);
__decorate([
    property()
], DashboardGerenteDashboardGerenteBase.prototype, "orderCount", void 0);
__decorate([
    property()
], DashboardGerenteDashboardGerenteBase.prototype, "averageTicket", void 0);
__decorate([
    property()
], DashboardGerenteDashboardGerenteBase.prototype, "itemsSold", void 0);
__decorate([
    property()
], DashboardGerenteDashboardGerenteBase.prototype, "serieVendasPorTurno", void 0);
__decorate([
    property()
], DashboardGerenteDashboardGerenteBase.prototype, "rankingItensMaisVendidos", void 0);
__decorate([
    property()
], DashboardGerenteDashboardGerenteBase.prototype, "alertasEstoqueBaixo", void 0);
__decorate([
    property()
], DashboardGerenteDashboardGerenteBase.prototype, "status", void 0);
