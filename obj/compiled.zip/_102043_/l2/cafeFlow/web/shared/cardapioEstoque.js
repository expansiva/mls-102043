var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102043_/l2/cafeFlow/web/shared/cardapioEstoque.ts" enhancement="_102027_/l2/enhancementLit.ts" />
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
import { subscribe, unsubscribe, getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Cafe Flow',
    pageTitle: 'Cardápio e Estoque',
    loaded: 'Dados carregados',
    couldNotLoad: 'Não foi possível carregar',
    loadingListarItensCardapio: 'Carregando itens do cardápio',
    loadingListarCategoriasCardapio: 'Carregando categorias do cardápio',
    loadingListarItensEstoque: 'Carregando itens de estoque',
    loadingListarMovimentacoesEstoque: 'Carregando movimentações de estoque',
    loadingListarAlertasEstoqueBaixo: 'Carregando alertas de estoque baixo',
    criarOuAtualizarItemCardapioLabel: 'Salvar item do cardápio',
    criarOuAtualizarItemCardapioLoading: 'Salvando item do cardápio',
    couldNotCriarOuAtualizarItemCardapio: 'Não foi possível salvar o item do cardápio',
    criarOuAtualizarItemEstoqueLabel: 'Salvar item de estoque',
    criarOuAtualizarItemEstoqueLoading: 'Salvando item de estoque',
    couldNotCriarOuAtualizarItemEstoque: 'Não foi possível salvar o item de estoque',
    registrarMovimentacaoEstoqueLabel: 'Registrar movimentação de estoque',
    registrarMovimentacaoEstoqueLoading: 'Registrando movimentação de estoque',
    couldNotRegistrarMovimentacaoEstoque: 'Não foi possível registrar a movimentação de estoque',
    navigateToDashboardGerente: 'Ver métricas de vendas/estoque',
};
const message_en = {
    brand: 'Cafe Flow',
    pageTitle: 'Menu and Stock',
    loaded: 'Data loaded',
    couldNotLoad: 'Could not load',
    loadingListarItensCardapio: 'Loading menu items',
    loadingListarCategoriasCardapio: 'Loading menu categories',
    loadingListarItensEstoque: 'Loading stock items',
    loadingListarMovimentacoesEstoque: 'Loading stock movements',
    loadingListarAlertasEstoqueBaixo: 'Loading low stock alerts',
    criarOuAtualizarItemCardapioLabel: 'Save menu item',
    criarOuAtualizarItemCardapioLoading: 'Saving menu item',
    couldNotCriarOuAtualizarItemCardapio: 'Could not save menu item',
    criarOuAtualizarItemEstoqueLabel: 'Save stock item',
    criarOuAtualizarItemEstoqueLoading: 'Saving stock item',
    couldNotCriarOuAtualizarItemEstoque: 'Could not save stock item',
    registrarMovimentacaoEstoqueLabel: 'Register stock movement',
    registrarMovimentacaoEstoqueLoading: 'Registering stock movement',
    couldNotRegistrarMovimentacaoEstoque: 'Could not register stock movement',
    navigateToDashboardGerente: 'View sales/stock metrics',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class CardapioEstoqueBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            'ui.cardapioEstoque.itensCardapio',
            'ui.cardapioEstoque.categoriasCardapio',
            'ui.cardapioEstoque.itensEstoque',
            'ui.cardapioEstoque.movimentacoesEstoque',
            'ui.cardapioEstoque.alertasEstoqueBaixo',
            'ui.cardapioEstoque.criarOuAtualizarItemCardapio',
            'ui.cardapioEstoque.criarOuAtualizarItemEstoque',
            'ui.cardapioEstoque.registrarMovimentacaoEstoque',
        ];
        this.itensCardapio = [];
        this.categoriasCardapio = [];
        this.itensEstoque = [];
        this.movimentacoesEstoque = [];
        this.alertasEstoqueBaixo = [];
        this.criarOuAtualizarItemCardapioState = 'idle';
        this.criarOuAtualizarItemEstoqueState = 'idle';
        this.registrarMovimentacaoEstoqueState = 'idle';
        this.status = '';
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, { mode: 'silent', signal: pendingLoad?.signal });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
        subscribe(this._stateKeys, this);
        this._stateKeys.forEach(key => {
            const v = getState(key);
            if (v !== undefined)
                this.handleIcaStateChange(key, v);
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe(this._stateKeys, this);
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.cardapioEstoque.itensCardapio':
                this.itensCardapio = value ?? [];
                break;
            case 'ui.cardapioEstoque.categoriasCardapio':
                this.categoriasCardapio = value ?? [];
                break;
            case 'ui.cardapioEstoque.itensEstoque':
                this.itensEstoque = value ?? [];
                break;
            case 'ui.cardapioEstoque.movimentacoesEstoque':
                this.movimentacoesEstoque = value ?? [];
                break;
            case 'ui.cardapioEstoque.alertasEstoqueBaixo':
                this.alertasEstoqueBaixo = value ?? [];
                break;
            case 'ui.cardapioEstoque.criarOuAtualizarItemCardapio':
                this.criarOuAtualizarItemCardapioState = value ?? 'idle';
                break;
            case 'ui.cardapioEstoque.criarOuAtualizarItemEstoque':
                this.criarOuAtualizarItemEstoqueState = value ?? 'idle';
                break;
            case 'ui.cardapioEstoque.registrarMovimentacaoEstoque':
                this.registrarMovimentacaoEstoqueState = value ?? 'idle';
                break;
            default:
                break;
        }
    }
    async loadInitialData(params, options) {
        await this.loadListarItensCardapio(params, options);
        await this.loadListarCategoriasCardapio(undefined, options);
        await this.loadListarItensEstoque(params, options);
        await this.loadListarMovimentacoesEstoque(params, options);
        await this.loadListarAlertasEstoqueBaixo(params, options);
    }
    async loadListarItensCardapio(params, options) {
        if (window.mls) {
            this.itensCardapio = [
                {
                    menuItemId: 'id-001',
                    nome: 'Café expresso',
                    preco: 5,
                    categoriaId: 'id-001',
                    ativo: true,
                },
                {
                    menuItemId: 'id-002',
                    nome: 'Cappuccino',
                    preco: 7,
                    categoriaId: 'id-001',
                    ativo: true,
                },
                {
                    menuItemId: 'id-003',
                    nome: 'Bolo de chocolate',
                    preco: 8,
                    categoriaId: 'id-002',
                    ativo: false,
                },
            ];
            setState('ui.cardapioEstoque.itensCardapio', this.itensCardapio);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('cafeFlow.cardapioEstoque.listarItensCardapio', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.itensCardapio = response.data;
        setState('ui.cardapioEstoque.itensCardapio', this.itensCardapio);
        this.status = this.msg.loaded;
    }
    async loadListarCategoriasCardapio(params, options) {
        if (window.mls) {
            this.categoriasCardapio = [
                {
                    categoriaId: 'id-001',
                    nome: 'Bebidas',
                    ativo: true,
                },
                {
                    categoriaId: 'id-002',
                    nome: 'Sobremesas',
                    ativo: true,
                },
            ];
            setState('ui.cardapioEstoque.categoriasCardapio', this.categoriasCardapio);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('cafeFlow.cardapioEstoque.listarCategoriasCardapio', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.categoriasCardapio = response.data;
        setState('ui.cardapioEstoque.categoriasCardapio', this.categoriasCardapio);
        this.status = this.msg.loaded;
    }
    async loadListarItensEstoque(params, options) {
        if (window.mls) {
            this.itensEstoque = [
                {
                    stockItemId: 'id-001',
                    nome: 'Café em grãos',
                    quantidadeAtual: 12,
                    unidadeMedidaId: 'id-001',
                    quantidadeMinima: 5,
                    status: 'ok',
                },
                {
                    stockItemId: 'id-002',
                    nome: 'Leite',
                    quantidadeAtual: 4,
                    unidadeMedidaId: 'id-002',
                    quantidadeMinima: 6,
                    status: 'baixo',
                },
            ];
            setState('ui.cardapioEstoque.itensEstoque', this.itensEstoque);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('cafeFlow.cardapioEstoque.listarItensEstoque', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.itensEstoque = response.data;
        setState('ui.cardapioEstoque.itensEstoque', this.itensEstoque);
        this.status = this.msg.loaded;
    }
    async loadListarMovimentacoesEstoque(params, options) {
        if (window.mls) {
            this.movimentacoesEstoque = [
                {
                    stockMovementId: 'id-001',
                    stockItemId: 'id-001',
                    movementType: 'entrada',
                    quantity: 10,
                    reason: 'Reposição',
                    occurredAt: '2026-06-19T10:00:00Z',
                },
                {
                    stockMovementId: 'id-002',
                    stockItemId: 'id-002',
                    movementType: 'saída',
                    quantity: 2,
                    reason: 'Consumo',
                    occurredAt: '2026-06-19T14:30:00Z',
                },
            ];
            setState('ui.cardapioEstoque.movimentacoesEstoque', this.movimentacoesEstoque);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('cafeFlow.cardapioEstoque.listarMovimentacoesEstoque', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.movimentacoesEstoque = response.data;
        setState('ui.cardapioEstoque.movimentacoesEstoque', this.movimentacoesEstoque);
        this.status = this.msg.loaded;
    }
    async loadListarAlertasEstoqueBaixo(params, options) {
        if (window.mls) {
            this.alertasEstoqueBaixo = [
                {
                    lowStockAlertId: 'id-001',
                    stockItemId: 'id-002',
                    triggeredAt: '2026-06-19T08:00:00Z',
                    currentQuantity: 4,
                    minimumQuantity: 6,
                    status: 'aberto',
                },
                {
                    lowStockAlertId: 'id-002',
                    stockItemId: 'id-003',
                    triggeredAt: '2026-06-18T18:00:00Z',
                    currentQuantity: 2,
                    minimumQuantity: 5,
                    status: 'em análise',
                },
            ];
            setState('ui.cardapioEstoque.alertasEstoqueBaixo', this.alertasEstoqueBaixo);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('cafeFlow.cardapioEstoque.listarAlertasEstoqueBaixo', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.alertasEstoqueBaixo = response.data;
        setState('ui.cardapioEstoque.alertasEstoqueBaixo', this.alertasEstoqueBaixo);
        this.status = this.msg.loaded;
    }
    async criarOuAtualizarItemCardapio(params, signal) {
        if (window.mls) {
            console.log('[mls mock] cafeFlow.cardapioEstoque.criarOuAtualizarItemCardapio', params);
            this.criarOuAtualizarItemCardapioState = 'success';
            setState('ui.cardapioEstoque.criarOuAtualizarItemCardapio', 'success');
            return;
        }
        this.criarOuAtualizarItemCardapioState = 'loading';
        setState('ui.cardapioEstoque.criarOuAtualizarItemCardapio', 'loading');
        try {
            const response = await execBff('cafeFlow.cardapioEstoque.criarOuAtualizarItemCardapio', params, signal ? { signal } : undefined);
            if (!response.ok)
                throw response.error;
            this.criarOuAtualizarItemCardapioState = 'success';
            setState('ui.cardapioEstoque.criarOuAtualizarItemCardapio', 'success');
            await this.loadListarItensCardapio(undefined, { mode: 'silent' });
        }
        catch (e) {
            this.criarOuAtualizarItemCardapioState = 'error';
            setState('ui.cardapioEstoque.criarOuAtualizarItemCardapio', 'error');
            throw e;
        }
    }
    handleCriarOuAtualizarItemCardapioClick() {
        const params = {};
        void runBlockingUiAction(async (signal) => {
            await this.criarOuAtualizarItemCardapio(params, signal);
        }, {
            busyLabel: this.msg.criarOuAtualizarItemCardapioLoading,
            errorTitle: this.msg.couldNotCriarOuAtualizarItemCardapio,
            retry: () => this.criarOuAtualizarItemCardapio(params),
        });
    }
    async criarOuAtualizarItemEstoque(params, signal) {
        if (window.mls) {
            console.log('[mls mock] cafeFlow.cardapioEstoque.criarOuAtualizarItemEstoque', params);
            this.criarOuAtualizarItemEstoqueState = 'success';
            setState('ui.cardapioEstoque.criarOuAtualizarItemEstoque', 'success');
            return;
        }
        this.criarOuAtualizarItemEstoqueState = 'loading';
        setState('ui.cardapioEstoque.criarOuAtualizarItemEstoque', 'loading');
        try {
            const response = await execBff('cafeFlow.cardapioEstoque.criarOuAtualizarItemEstoque', params, signal ? { signal } : undefined);
            if (!response.ok)
                throw response.error;
            this.criarOuAtualizarItemEstoqueState = 'success';
            setState('ui.cardapioEstoque.criarOuAtualizarItemEstoque', 'success');
            await this.loadListarItensEstoque(undefined, { mode: 'silent' });
        }
        catch (e) {
            this.criarOuAtualizarItemEstoqueState = 'error';
            setState('ui.cardapioEstoque.criarOuAtualizarItemEstoque', 'error');
            throw e;
        }
    }
    handleCriarOuAtualizarItemEstoqueClick() {
        const params = {};
        void runBlockingUiAction(async (signal) => {
            await this.criarOuAtualizarItemEstoque(params, signal);
        }, {
            busyLabel: this.msg.criarOuAtualizarItemEstoqueLoading,
            errorTitle: this.msg.couldNotCriarOuAtualizarItemEstoque,
            retry: () => this.criarOuAtualizarItemEstoque(params),
        });
    }
    async registrarMovimentacaoEstoque(params, signal) {
        if (window.mls) {
            console.log('[mls mock] cafeFlow.cardapioEstoque.registrarMovimentacaoEstoque', params);
            this.registrarMovimentacaoEstoqueState = 'success';
            setState('ui.cardapioEstoque.registrarMovimentacaoEstoque', 'success');
            return;
        }
        this.registrarMovimentacaoEstoqueState = 'loading';
        setState('ui.cardapioEstoque.registrarMovimentacaoEstoque', 'loading');
        try {
            const response = await execBff('cafeFlow.cardapioEstoque.registrarMovimentacaoEstoque', params, signal ? { signal } : undefined);
            if (!response.ok)
                throw response.error;
            this.registrarMovimentacaoEstoqueState = 'success';
            setState('ui.cardapioEstoque.registrarMovimentacaoEstoque', 'success');
            await this.loadListarItensEstoque(undefined, { mode: 'silent' });
            await this.loadListarMovimentacoesEstoque(undefined, { mode: 'silent' });
        }
        catch (e) {
            this.registrarMovimentacaoEstoqueState = 'error';
            setState('ui.cardapioEstoque.registrarMovimentacaoEstoque', 'error');
            throw e;
        }
    }
    handleRegistrarMovimentacaoEstoqueClick() {
        const params = {};
        void runBlockingUiAction(async (signal) => {
            await this.registrarMovimentacaoEstoque(params, signal);
        }, {
            busyLabel: this.msg.registrarMovimentacaoEstoqueLoading,
            errorTitle: this.msg.couldNotRegistrarMovimentacaoEstoque,
            retry: () => this.registrarMovimentacaoEstoque(params),
        });
    }
    handleNavigateToDashboardGerenteClick(params) {
        if (window.mls) {
            console.log('[mls mock] navigate to dashboardGerente', params);
            return;
        }
        setState('navigation.request', { pageId: 'dashboardGerente', params: params ?? {} });
    }
}
__decorate([
    property()
], CardapioEstoqueBase.prototype, "itensCardapio", void 0);
__decorate([
    property()
], CardapioEstoqueBase.prototype, "categoriasCardapio", void 0);
__decorate([
    property()
], CardapioEstoqueBase.prototype, "itensEstoque", void 0);
__decorate([
    property()
], CardapioEstoqueBase.prototype, "movimentacoesEstoque", void 0);
__decorate([
    property()
], CardapioEstoqueBase.prototype, "alertasEstoqueBaixo", void 0);
__decorate([
    property()
], CardapioEstoqueBase.prototype, "criarOuAtualizarItemCardapioState", void 0);
__decorate([
    property()
], CardapioEstoqueBase.prototype, "criarOuAtualizarItemEstoqueState", void 0);
__decorate([
    property()
], CardapioEstoqueBase.prototype, "registrarMovimentacaoEstoqueState", void 0);
__decorate([
    property()
], CardapioEstoqueBase.prototype, "status", void 0);
