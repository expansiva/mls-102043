var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102043_/l2/cafeFlow/web/shared/painelCozinha.ts" enhancement="_102027_/l2/enhancementLit.ts" />
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
import { subscribe, unsubscribe, getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'CafeFlow',
    pageTitle: 'Painel de Cozinha',
    loaded: 'Dados carregados',
    couldNotLoad: 'Não foi possível carregar',
    loadingListarPedidosCozinha: 'Carregando pedidos da cozinha',
    atualizarStatusPedidoLabel: 'Atualizar status do pedido',
    atualizarStatusPedidoLoading: 'Atualizando status do pedido',
    couldNotAtualizarStatusPedido: 'Não foi possível atualizar status do pedido',
};
const message_en = {
    brand: 'CafeFlow',
    pageTitle: 'Kitchen Panel',
    loaded: 'Data loaded',
    couldNotLoad: 'Could not load',
    loadingListarPedidosCozinha: 'Loading kitchen orders',
    atualizarStatusPedidoLabel: 'Update order status',
    atualizarStatusPedidoLoading: 'Updating order status',
    couldNotAtualizarStatusPedido: 'Could not update order status',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class PainelCozinhaPainelCozinhaBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            'ui.painelCozinha.pedidosCozinha',
            'ui.painelCozinha.atualizarStatusPedido',
        ];
        this.pedidosCozinha = [];
        this.atualizarStatusPedidoState = 'idle';
        this.status = '';
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, { mode: 'silent', signal: pendingLoad?.signal });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
        subscribe(this._stateKeys, this);
        this._stateKeys.forEach(key => {
            const v = getState(key);
            if (v !== undefined)
                this.handleIcaStateChange(key, v);
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe(this._stateKeys, this);
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.painelCozinha.pedidosCozinha':
                this.pedidosCozinha = value ?? [];
                break;
            case 'ui.painelCozinha.atualizarStatusPedido':
                this.atualizarStatusPedidoState =
                    value ?? 'idle';
                break;
            default:
                break;
        }
    }
    async loadInitialData(params, options) {
        await this.loadListarPedidosCozinha(params, options);
    }
    async loadListarPedidosCozinha(params, options) {
        if (window.mls) {
            this.pedidosCozinha = [
                {
                    orderId: 'id-001',
                    status: 'Recebido',
                    createdAt: '2026-06-23T10:00:00Z',
                    shiftId: 'shift-001',
                },
                {
                    orderId: 'id-002',
                    status: 'Em preparo',
                    createdAt: '2026-06-23T10:05:00Z',
                    shiftId: 'shift-001',
                },
                {
                    orderId: 'id-003',
                    status: 'Pronto',
                    createdAt: '2026-06-23T10:12:00Z',
                    shiftId: 'shift-002',
                },
            ];
            setState('ui.painelCozinha.pedidosCozinha', this.pedidosCozinha);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('cafeFlow.painelCozinha.listarPedidosCozinha', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.pedidosCozinha = response.data;
        setState('ui.painelCozinha.pedidosCozinha', this.pedidosCozinha);
        this.status = this.msg.loaded;
    }
    async atualizarStatusPedido(params, signal) {
        if (window.mls) {
            console.log('[mls mock] cafeFlow.painelCozinha.atualizarStatusPedido', params);
            this.atualizarStatusPedidoState = 'success';
            setState('ui.painelCozinha.atualizarStatusPedido', 'success');
            return;
        }
        this.atualizarStatusPedidoState = 'loading';
        setState('ui.painelCozinha.atualizarStatusPedido', 'loading');
        try {
            const response = await execBff('cafeFlow.painelCozinha.atualizarStatusPedido', params, signal ? { signal } : undefined);
            if (!response.ok)
                throw response.error;
            this.atualizarStatusPedidoState = 'success';
            setState('ui.painelCozinha.atualizarStatusPedido', 'success');
            await this.loadListarPedidosCozinha(undefined, { mode: 'silent' });
        }
        catch (e) {
            this.atualizarStatusPedidoState = 'error';
            setState('ui.painelCozinha.atualizarStatusPedido', 'error');
            throw e;
        }
    }
    handleAtualizarStatusPedidoClick() {
        const params = {
            orderId: this.pedidosCozinha[0]?.orderId ?? '',
            novoStatus: 'Em preparo',
        };
        void runBlockingUiAction(async (signal) => {
            await this.atualizarStatusPedido(params, signal);
        }, {
            busyLabel: this.msg.atualizarStatusPedidoLoading,
            errorTitle: this.msg.couldNotAtualizarStatusPedido,
            retry: () => this.atualizarStatusPedido(params),
        });
    }
}
__decorate([
    property()
], PainelCozinhaPainelCozinhaBase.prototype, "pedidosCozinha", void 0);
__decorate([
    property()
], PainelCozinhaPainelCozinhaBase.prototype, "atualizarStatusPedidoState", void 0);
__decorate([
    property()
], PainelCozinhaPainelCozinhaBase.prototype, "status", void 0);
