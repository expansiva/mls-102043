var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102043_/l2/cafeFlow/web/shared/fechamentoTurno.ts" enhancement="_102027_/l2/enhancementLit.ts" />
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { bindExpectedNavigationLoad, consumeExpectedNavigationLoad, runBlockingUiAction, } from '/_102029_/l2/interactionRuntime.js';
import { subscribe, unsubscribe, getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    brand: 'Cafe Flow',
    pageTitle: 'Fechamento de Turno',
    loaded: 'Dados carregados',
    couldNotLoad: 'Nao foi possivel carregar',
    loadingListarTurnos: 'Carregando turnos',
    loadingListarPedidos: 'Carregando pedidos',
    loadingObterRelatorioTurno: 'Carregando relatório do turno',
    fecharTurnoLabel: 'Fechar turno',
    fecharTurnoLoading: 'Fechando turno',
    couldNotFecharTurno: 'Não foi possível fechar turno',
    navigateToDashboardGerente: 'Ver resumo do turno',
};
const message_en = {
    brand: 'Cafe Flow',
    pageTitle: 'Shift Closing',
    loaded: 'Data loaded',
    couldNotLoad: 'Could not load',
    loadingListarTurnos: 'Loading shifts',
    loadingListarPedidos: 'Loading orders',
    loadingObterRelatorioTurno: 'Loading shift report',
    fecharTurnoLabel: 'Close shift',
    fecharTurnoLoading: 'Closing shift',
    couldNotFecharTurno: 'Could not close shift',
    navigateToDashboardGerente: 'View shift summary',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
export class FechamentoTurnoFechamentoTurnoBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            'ui.fechamentoTurno.turnos',
            'ui.fechamentoTurno.pedidos',
            'ui.fechamentoTurno.shiftReportId',
            'ui.fechamentoTurno.shiftId',
            'ui.fechamentoTurno.totalSalesAmount',
            'ui.fechamentoTurno.totalOrders',
            'ui.fechamentoTurno.totalItems',
            'ui.fechamentoTurno.notes',
            'ui.fechamentoTurno.createdAt',
            'ui.fechamentoTurno.updatedAt',
            'ui.fechamentoTurno.fecharTurno',
        ];
        this.turnos = [];
        this.pedidos = [];
        this.shiftReportId = undefined;
        this.shiftId = undefined;
        this.totalSalesAmount = undefined;
        this.totalOrders = undefined;
        this.totalItems = undefined;
        this.notes = undefined;
        this.createdAt = undefined;
        this.updatedAt = undefined;
        this.fecharTurnoState = 'idle';
        this.status = '';
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        const pendingLoad = consumeExpectedNavigationLoad();
        const task = this.loadInitialData(undefined, { mode: 'silent', signal: pendingLoad?.signal });
        bindExpectedNavigationLoad(pendingLoad, task);
        void task.catch(() => undefined);
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages['en'];
        subscribe(this._stateKeys, this);
        this._stateKeys.forEach(key => {
            const v = getState(key);
            if (v !== undefined)
                this.handleIcaStateChange(key, v);
        });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe(this._stateKeys, this);
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.fechamentoTurno.turnos':
                this.turnos = value ?? [];
                break;
            case 'ui.fechamentoTurno.pedidos':
                this.pedidos = value ?? [];
                break;
            case 'ui.fechamentoTurno.shiftReportId':
                this.shiftReportId = value ?? undefined;
                break;
            case 'ui.fechamentoTurno.shiftId':
                this.shiftId = value ?? undefined;
                break;
            case 'ui.fechamentoTurno.totalSalesAmount':
                this.totalSalesAmount = value ?? undefined;
                break;
            case 'ui.fechamentoTurno.totalOrders':
                this.totalOrders = value ?? undefined;
                break;
            case 'ui.fechamentoTurno.totalItems':
                this.totalItems = value ?? undefined;
                break;
            case 'ui.fechamentoTurno.notes':
                this.notes = value ?? undefined;
                break;
            case 'ui.fechamentoTurno.createdAt':
                this.createdAt = value ?? undefined;
                break;
            case 'ui.fechamentoTurno.updatedAt':
                this.updatedAt = value ?? undefined;
                break;
            case 'ui.fechamentoTurno.fecharTurno':
                this.fecharTurnoState = value ?? 'idle';
                break;
            default:
                break;
        }
    }
    async loadInitialData(params, options) {
        await this.loadListarTurnos(params, options);
        await this.loadListarPedidos(undefined, options);
        await this.loadObterRelatorioTurno(undefined, options);
    }
    async loadListarTurnos(params, options) {
        if (window.mls) {
            this.turnos = [
                {
                    shiftId: 'id-001',
                    status: 'Aberto',
                    openedAt: '2026-06-23T06:00:00Z',
                    closedAt: '2026-06-23T14:00:00Z',
                    shiftConfigId: 'id-001',
                },
                {
                    shiftId: 'id-002',
                    status: 'Fechado',
                    openedAt: '2026-06-22T14:00:00Z',
                    closedAt: '2026-06-22T22:00:00Z',
                    shiftConfigId: 'id-002',
                },
            ];
            setState('ui.fechamentoTurno.turnos', this.turnos);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('cafeFlow.fechamentoTurno.listarTurnos', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.turnos = response.data;
        setState('ui.fechamentoTurno.turnos', this.turnos);
        this.status = this.msg.loaded;
    }
    async loadListarPedidos(params, options) {
        if (window.mls) {
            this.pedidos = [
                {
                    orderId: 'id-001',
                    status: 'Finalizado',
                    shiftId: 'id-001',
                    createdAt: '2026-06-23T07:10:00Z',
                    updatedAt: '2026-06-23T07:30:00Z',
                },
                {
                    orderId: 'id-002',
                    status: 'Finalizado',
                    shiftId: 'id-001',
                    createdAt: '2026-06-23T08:05:00Z',
                    updatedAt: '2026-06-23T08:20:00Z',
                },
            ];
            setState('ui.fechamentoTurno.pedidos', this.pedidos);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('cafeFlow.fechamentoTurno.listarPedidos', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.pedidos = response.data;
        setState('ui.fechamentoTurno.pedidos', this.pedidos);
        this.status = this.msg.loaded;
    }
    async loadObterRelatorioTurno(params, options) {
        if (window.mls) {
            this.shiftReportId = 'id-001';
            this.shiftId = 'id-001';
            this.totalSalesAmount = '120.50';
            this.totalOrders = 12;
            this.totalItems = 24;
            this.notes = 'Turno tranquilo';
            this.createdAt = '2026-06-23T06:00:00Z';
            this.updatedAt = '2026-06-23T14:10:00Z';
            setState('ui.fechamentoTurno.shiftReportId', this.shiftReportId);
            setState('ui.fechamentoTurno.shiftId', this.shiftId);
            setState('ui.fechamentoTurno.totalSalesAmount', this.totalSalesAmount);
            setState('ui.fechamentoTurno.totalOrders', this.totalOrders);
            setState('ui.fechamentoTurno.totalItems', this.totalItems);
            setState('ui.fechamentoTurno.notes', this.notes);
            setState('ui.fechamentoTurno.createdAt', this.createdAt);
            setState('ui.fechamentoTurno.updatedAt', this.updatedAt);
            this.status = this.msg.loaded;
            return;
        }
        const response = await execBff('cafeFlow.fechamentoTurno.obterRelatorioTurno', params ?? {}, options);
        if (!response.ok || !response.data) {
            if (options?.mode === 'blocking') {
                throw (response.error ?? { code: 'UNEXPECTED_ERROR', message: this.msg.couldNotLoad });
            }
            this.status = this.msg.couldNotLoad;
            return;
        }
        this.shiftReportId = response.data.shiftReportId;
        this.shiftId = response.data.shiftId;
        this.totalSalesAmount = response.data.totalSalesAmount;
        this.totalOrders = response.data.totalOrders;
        this.totalItems = response.data.totalItems;
        this.notes = response.data.notes;
        this.createdAt = response.data.createdAt;
        this.updatedAt = response.data.updatedAt;
        setState('ui.fechamentoTurno.shiftReportId', this.shiftReportId);
        setState('ui.fechamentoTurno.shiftId', this.shiftId);
        setState('ui.fechamentoTurno.totalSalesAmount', this.totalSalesAmount);
        setState('ui.fechamentoTurno.totalOrders', this.totalOrders);
        setState('ui.fechamentoTurno.totalItems', this.totalItems);
        setState('ui.fechamentoTurno.notes', this.notes);
        setState('ui.fechamentoTurno.createdAt', this.createdAt);
        setState('ui.fechamentoTurno.updatedAt', this.updatedAt);
        this.status = this.msg.loaded;
    }
    async fecharTurno(params, signal) {
        if (window.mls) {
            console.log('[mls mock] cafeFlow.fechamentoTurno.fecharTurno', params);
            this.fecharTurnoState = 'success';
            setState('ui.fechamentoTurno.fecharTurno', 'success');
            return;
        }
        this.fecharTurnoState = 'loading';
        setState('ui.fechamentoTurno.fecharTurno', 'loading');
        try {
            const response = await execBff('cafeFlow.fechamentoTurno.fecharTurno', params, signal ? { signal } : undefined);
            if (!response.ok)
                throw response.error;
            this.fecharTurnoState = 'success';
            setState('ui.fechamentoTurno.fecharTurno', 'success');
            await this.loadObterRelatorioTurno({ shiftId: params.shiftId }, { mode: 'silent' });
        }
        catch (e) {
            this.fecharTurnoState = 'error';
            setState('ui.fechamentoTurno.fecharTurno', 'error');
            throw e;
        }
    }
    handleFecharTurnoClick() {
        const params = { shiftId: this.shiftId ?? '' };
        void runBlockingUiAction(async (signal) => {
            await this.fecharTurno(params, signal);
        }, {
            busyLabel: this.msg.fecharTurnoLoading,
            errorTitle: this.msg.couldNotFecharTurno,
            retry: () => this.fecharTurno(params),
        });
    }
    handleNavigateToDashboardGerenteClick(params) {
        if (window.mls) {
            console.log('[mls mock] navigate to dashboardGerente', params);
            return;
        }
        setState('navigation.request', { pageId: 'dashboardGerente', params: params ?? {} });
    }
}
__decorate([
    property()
], FechamentoTurnoFechamentoTurnoBase.prototype, "turnos", void 0);
__decorate([
    property()
], FechamentoTurnoFechamentoTurnoBase.prototype, "pedidos", void 0);
__decorate([
    property()
], FechamentoTurnoFechamentoTurnoBase.prototype, "shiftReportId", void 0);
__decorate([
    property()
], FechamentoTurnoFechamentoTurnoBase.prototype, "shiftId", void 0);
__decorate([
    property()
], FechamentoTurnoFechamentoTurnoBase.prototype, "totalSalesAmount", void 0);
__decorate([
    property()
], FechamentoTurnoFechamentoTurnoBase.prototype, "totalOrders", void 0);
__decorate([
    property()
], FechamentoTurnoFechamentoTurnoBase.prototype, "totalItems", void 0);
__decorate([
    property()
], FechamentoTurnoFechamentoTurnoBase.prototype, "notes", void 0);
__decorate([
    property()
], FechamentoTurnoFechamentoTurnoBase.prototype, "createdAt", void 0);
__decorate([
    property()
], FechamentoTurnoFechamentoTurnoBase.prototype, "updatedAt", void 0);
__decorate([
    property()
], FechamentoTurnoFechamentoTurnoBase.prototype, "fecharTurnoState", void 0);
__decorate([
    property()
], FechamentoTurnoFechamentoTurnoBase.prototype, "status", void 0);
