/// <mls fileReference="_102043_/l2/designSystem.ts" enhancement="_blank" />
export const tokens = [
    {
        "themeName": "default",
        "description": "Default design system",
        "color": {},
        "typography": {},
        "global": {},
        "dsIndex": "1"
    },
    {
        "themeName": "Collab design",
        "description": "Um design system de teste",
        "color": {},
        "typography": {},
        "global": {},
        "dsIndex": "2"
    }
];
