declare module "_102043_/l1/cafeFlow/layer_1_external/dailySalesMetrics.defs" {
    export const dailySalesMetricsTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "dailySalesMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 49;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "dailySalesMetrics";
                readonly tableName: "daily_sales_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Vendas diárias";
                readonly purpose: "Acompanhar faturamento, quantidade de pedidos e ticket médio por turno e dia para tomada de decisão do gerente.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "time";
                readonly columns: readonly [{
                    readonly name: "time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp de referência da métrica.";
                }, {
                    readonly name: "shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Turno em que o pedido foi realizado.";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do pedido no momento da métrica.";
                }, {
                    readonly name: "order_item_id";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "FK para item de pedido relacionado.";
                }, {
                    readonly name: "order_status_history_id";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "FK para histórico de status do pedido relacionado.";
                }, {
                    readonly name: "shift_report_id";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "FK para relatório de fechamento do turno.";
                }, {
                    readonly name: "shift_config_id";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "FK para configuração de turno utilizada.";
                }, {
                    readonly name: "total_revenue";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Receita total dos pedidos.";
                }, {
                    readonly name: "order_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de pedidos.";
                }, {
                    readonly name: "average_ticket";
                    readonly type: "numeric";
                    readonly nullable: true;
                    readonly description: "Ticket médio por pedido.";
                }, {
                    readonly name: "items_sold";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade total de itens vendidos.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "shiftId";
                    readonly column: "shift_id";
                    readonly type: "uuid";
                    readonly description: "Turno em que o pedido foi realizado.";
                }, {
                    readonly dimensionId: "orderStatus";
                    readonly column: "status";
                    readonly type: "string";
                    readonly description: "Status do pedido no momento da métrica.";
                }, {
                    readonly dimensionId: "orderItemId";
                    readonly column: "order_item_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship orderHasItems (Order -> OrderItem).";
                }, {
                    readonly dimensionId: "orderStatusHistoryId";
                    readonly column: "order_status_history_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship orderHasStatusHistory (Order -> OrderStatusHistory).";
                }, {
                    readonly dimensionId: "shiftReportId";
                    readonly column: "shift_report_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship shiftHasReport (Shift -> ShiftReport).";
                }, {
                    readonly dimensionId: "shiftConfigId";
                    readonly column: "shift_config_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship shiftUsesConfig (Shift -> ShiftConfig).";
                }];
                readonly measures: readonly [{
                    readonly measureId: "totalRevenue";
                    readonly column: "total_revenue";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Receita total dos pedidos.";
                }, {
                    readonly measureId: "orderCount";
                    readonly column: "order_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade de pedidos.";
                }, {
                    readonly measureId: "averageTicket";
                    readonly column: "average_ticket";
                    readonly aggregation: "avg";
                    readonly unit: "BRL";
                    readonly description: "Ticket médio por pedido.";
                }, {
                    readonly measureId: "itemsSold";
                    readonly column: "items_sold";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade total de itens vendidos.";
                }];
                readonly sourceWriteEvents: readonly ["orderCreated", "orderStatusUpdated", "shiftClosed"];
                readonly hypertable: {
                    readonly timeColumn: "time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_daily_sales_metrics_time";
                        readonly columns: readonly ["time"];
                        readonly purpose: "Consulta temporal por janela de agregação.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_shift_id_time";
                        readonly columns: readonly ["shift_id", "time"];
                        readonly purpose: "Filtro por turno e período.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_status_time";
                        readonly columns: readonly ["status", "time"];
                        readonly purpose: "Filtro por status e período.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_order_item_id";
                        readonly columns: readonly ["order_item_id"];
                        readonly purpose: "Lookup por item do pedido.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_order_status_history_id";
                        readonly columns: readonly ["order_status_history_id"];
                        readonly purpose: "Lookup por histórico de status.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_shift_report_id";
                        readonly columns: readonly ["shift_report_id"];
                        readonly purpose: "Lookup por relatório de turno.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_shift_config_id";
                        readonly columns: readonly ["shift_config_id"];
                        readonly purpose: "Lookup por configuração de turno.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["registrarPedido", "atualizarStatusCozinha", "fecharTurno"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["orderStatusTransition", "orderRequiresItem", "shiftClosureRequiresNoOpenOrders"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/dailySalesMetrics.defs.ts";
                readonly exportName: "dailySalesMetricsTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default dailySalesMetricsTableDefinition;
    export const pipeline: readonly [{
        readonly id: "dailySalesMetrics__layer_1_external";
        readonly type: "layer_1_external";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_1_external/dailySalesMetrics.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_1_external/dailySalesMetrics.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/dailySalesMetrics" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const dailySalesMetricsTableDef: TableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/lowStockAlert.defs" {
    export const lowStockAlertTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "lowStockAlert";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 48;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "lowStockAlert";
                readonly tableName: "low_stock_alerts";
                readonly moduleId: "cafeFlow";
                readonly title: "Alertas de Estoque Baixo";
                readonly purpose: "Persistir alertas de estoque baixo para acompanhamento do gerente.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "LowStockAlert";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "low_stock_alert_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do alerta de estoque baixo.";
                }, {
                    readonly name: "stock_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Item de estoque associado ao alerta.";
                }, {
                    readonly name: "triggered_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora em que o alerta foi gerado.";
                }, {
                    readonly name: "current_quantity";
                    readonly type: "number";
                    readonly nullable: false;
                    readonly description: "Quantidade atual do item quando o alerta foi gerado.";
                }, {
                    readonly name: "minimum_quantity";
                    readonly type: "number";
                    readonly nullable: false;
                    readonly description: "Quantidade mínima configurada para o item.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Situação atual do alerta.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly primaryKey: readonly ["low_stock_alert_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "stock_item_id";
                    readonly targetEntity: "StockItem";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Item de estoque é entidade MDM referenciada pelo alerta.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_low_stock_alerts_stock_item_id";
                    readonly columns: readonly ["stock_item_id"];
                    readonly unique: false;
                    readonly reason: "Lookup rápido por item de estoque.";
                }, {
                    readonly indexName: "idx_low_stock_alerts_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Filtragem por situação do alerta.";
                }, {
                    readonly indexName: "idx_low_stock_alerts_triggered_at";
                    readonly columns: readonly ["triggered_at"];
                    readonly unique: false;
                    readonly reason: "Ordenação e filtros por data do alerta.";
                }, {
                    readonly indexName: "idx_low_stock_alerts_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly unique: false;
                    readonly reason: "Filtros por período no dashboard.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["lowStockMetricTable"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["lowStockThresholdRule"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/lowStockAlert.defs.ts";
                readonly exportName: "lowStockAlertTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default lowStockAlertTableDefinition;
    export const pipeline: readonly [{
        readonly id: "lowStockAlert__layer_1_external";
        readonly type: "layer_1_external";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_1_external/lowStockAlert.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_1_external/lowStockAlert.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/lowStockAlert" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const lowStockAlertTableDef: TableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/lowStockMetrics.defs" {
    export const lowStockMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "lowStockMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 51;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "lowStockMetrics";
                readonly tableName: "low_stock_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Estoque baixo";
                readonly purpose: "Monitorar a frequência e evolução de alertas de estoque baixo para evitar rupturas.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "time";
                readonly columns: readonly [{
                    readonly name: "time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Momento de referência da métrica de estoque baixo.";
                }, {
                    readonly name: "stock_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Item de estoque com alerta ou movimentação.";
                }, {
                    readonly name: "unit_of_measure_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Unidade de medida do item.";
                }, {
                    readonly name: "alert_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly description: "Número de alertas de estoque baixo.";
                }, {
                    readonly name: "current_quantity";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly description: "Quantidade atual em estoque no momento da métrica.";
                }, {
                    readonly name: "threshold_value";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly description: "Valor limite configurado para disparo do alerta.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "stockItemId";
                    readonly column: "stock_item_id";
                    readonly type: "uuid";
                    readonly description: "Item de estoque com alerta ou movimentação.";
                }, {
                    readonly dimensionId: "unitOfMeasureId";
                    readonly column: "unit_of_measure_id";
                    readonly type: "uuid";
                    readonly description: "Unidade de medida do item.";
                }];
                readonly measures: readonly [{
                    readonly measureId: "alertCount";
                    readonly column: "alert_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Número de alertas de estoque baixo.";
                }, {
                    readonly measureId: "currentQuantity";
                    readonly column: "current_quantity";
                    readonly aggregation: "last";
                    readonly unit: "unit";
                    readonly description: "Quantidade atual em estoque no momento da métrica.";
                }, {
                    readonly measureId: "thresholdValue";
                    readonly column: "threshold_value";
                    readonly aggregation: "last";
                    readonly unit: "unit";
                    readonly description: "Valor limite configurado para disparo do alerta.";
                }];
                readonly sourceWriteEvents: readonly ["lowStockAlertCreated", "stockMovementCreated"];
                readonly hypertable: {
                    readonly timeColumn: "time";
                    readonly chunkTimeInterval: "1 day";
                    readonly retentionPolicy: "6 months";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_low_stock_metrics_time";
                        readonly columns: readonly ["time"];
                        readonly purpose: "Suporte a consultas por janela temporal.";
                    }, {
                        readonly indexName: "idx_low_stock_metrics_stock_item_time";
                        readonly columns: readonly ["stock_item_id", "time"];
                        readonly purpose: "Consultas por item de estoque ao longo do tempo.";
                    }, {
                        readonly indexName: "idx_low_stock_metrics_uom_time";
                        readonly columns: readonly ["unit_of_measure_id", "time"];
                        readonly purpose: "Consultas por unidade de medida ao longo do tempo.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["lowStockThresholdRule"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/lowStockMetrics.defs.ts";
                readonly exportName: "lowStockMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default lowStockMetricsMetricTableDefinition;
    export const pipeline: readonly [{
        readonly id: "lowStockMetrics__layer_1_external";
        readonly type: "layer_1_external";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_1_external/lowStockMetrics.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_1_external/lowStockMetrics.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/lowStockMetrics" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const lowStockMetricsTableDef: TableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/mock" {
    import type { SeedDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const seedDefinitions: SeedDefinition[];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/order.defs" {
    export const orderTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 47;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "order";
                readonly tableName: "orders";
                readonly moduleId: "cafeFlow";
                readonly title: "Pedidos";
                readonly purpose: "Persistir pedidos do POS com itens para operação e status atual.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "Order";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do pedido.";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status atual do pedido.";
                }, {
                    readonly name: "shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Turno em que o pedido foi registrado.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do pedido.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do pedido.";
                }];
                readonly primaryKey: readonly ["order_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "shift_id";
                    readonly targetEntity: "Shift";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Pedido pertence a um turno.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_orders_status";
                    readonly columns: readonly ["status"];
                    readonly reason: "Filtro rápido por status no painel da cozinha e workflow.";
                }, {
                    readonly indexName: "idx_orders_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly reason: "Listagens por data para POS e dashboard.";
                }, {
                    readonly indexName: "idx_orders_shift_id";
                    readonly columns: readonly ["shift_id"];
                    readonly reason: "Consulta por turno para fechamento e operações.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly reason: "Itens do pedido e dados agregados do OrderItem armazenados como JSON.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["orderRequiresItem", "orderStatusTransition", "shiftClosureRequiresNoOpenOrders"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/order.defs.ts";
                readonly exportName: "orderTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default orderTableDefinition;
    export const pipeline: readonly [{
        readonly id: "order__layer_1_external";
        readonly type: "layer_1_external";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_1_external/order.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_1_external/order.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/order" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const orderTableDef: TableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/orderStatusHistory.defs" {
    export const orderStatusHistoryTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "orderStatusHistory";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 48;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "orderStatusHistory";
                readonly tableName: "order_status_history";
                readonly moduleId: "cafeFlow";
                readonly title: "Histórico de Status do Pedido";
                readonly purpose: "Registrar transições de status do pedido para auditoria e acompanhamento de cozinha.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "OrderStatusHistory";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "order_status_history_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do histórico de status do pedido.";
                }, {
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência ao pedido relacionado a este registro de status.";
                }, {
                    readonly name: "from_status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Status anterior do pedido antes da transição.";
                }, {
                    readonly name: "to_status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Novo status do pedido após a transição.";
                }, {
                    readonly name: "changed_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora em que a transição de status ocorreu.";
                }, {
                    readonly name: "changed_by";
                    readonly type: "string";
                    readonly nullable: true;
                    readonly description: "Identificador ou nome do colaborador que efetuou a mudança de status.";
                }, {
                    readonly name: "note";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Observação sobre a mudança de status, se aplicável.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly primaryKey: readonly ["order_status_history_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "order_id";
                    readonly targetEntity: "Order";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Histórico vinculado ao pedido para rastreio de transições.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_order_status_history_order_id_changed_at";
                    readonly columns: readonly ["order_id", "changed_at"];
                    readonly unique: false;
                    readonly reason: "Consulta do histórico por pedido e linha do tempo no painel e workflow.";
                }, {
                    readonly indexName: "idx_order_status_history_changed_at";
                    readonly columns: readonly ["changed_at"];
                    readonly unique: false;
                    readonly reason: "Ordenação e filtros por período para auditoria.";
                }, {
                    readonly indexName: "idx_order_status_history_to_status";
                    readonly columns: readonly ["to_status"];
                    readonly unique: false;
                    readonly reason: "Filtrar transições por status no painel de cozinha.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["orderStatusTransitions"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["orderStatusTransition"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/orderStatusHistory.defs.ts";
                readonly exportName: "orderStatusHistoryTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default orderStatusHistoryTableDefinition;
    export const pipeline: readonly [{
        readonly id: "orderStatusHistory__layer_1_external";
        readonly type: "layer_1_external";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_1_external/orderStatusHistory.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_1_external/orderStatusHistory.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/orderStatusHistory" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const orderStatusHistoryTableDef: TableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/shift" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const shiftTableDef: TableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/salesSummaryRequest" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const salesSummaryRequestTableDef: TableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/shiftReport" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const shiftReportTableDef: TableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const topSellingItemsMetricsTableDef: TableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/stockMovement" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const stockMovementTableDef: TableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/persistence" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const tableDefinitions: TableDefinition[];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/salesSummaryRequest.defs" {
    export const salesSummaryRequestTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "salesSummaryRequest";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 49;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "salesSummaryRequest";
                readonly tableName: "sales_summary_requests";
                readonly moduleId: "cafeFlow";
                readonly title: "Solicitações de Resumo de Vendas";
                readonly purpose: "Rastrear solicitações de resumo de vendas para o assistente IA.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "SalesSummaryRequest";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "sales_summary_request_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da solicitação de resumo de vendas.";
                }, {
                    readonly name: "shift_report_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência à consolidação de vendas usada na solicitação.";
                }, {
                    readonly name: "request_status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly default: "pending";
                    readonly description: "Status da solicitação de resumo de vendas.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação da solicitação.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização da solicitação.";
                }];
                readonly primaryKey: readonly ["sales_summary_request_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "shift_report_id";
                    readonly targetEntity: "ShiftReport";
                    readonly targetOwnership: "existingModuleOwned";
                    readonly reason: "Solicitação depende da consolidação de vendas.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "ix_sales_summary_requests_shift_report_id";
                    readonly columns: readonly ["shift_report_id"];
                    readonly reason: "Busca por solicitações vinculadas ao relatório de turno.";
                }, {
                    readonly indexName: "ix_sales_summary_requests_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly reason: "Filtro por período para geração e auditoria.";
                }, {
                    readonly indexName: "ix_sales_summary_requests_status";
                    readonly columns: readonly ["request_status"];
                    readonly reason: "Filtrar solicitações pendentes ou concluídas.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["salesSummaryUsesLast7Days"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/salesSummaryRequest.defs.ts";
                readonly exportName: "salesSummaryRequestTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default salesSummaryRequestTableDefinition;
    export const pipeline: readonly [{
        readonly id: "salesSummaryRequest__layer_1_external";
        readonly type: "layer_1_external";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_1_external/salesSummaryRequest.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_1_external/salesSummaryRequest.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/shift.defs" {
    export const shiftTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "shift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 49;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "shift";
                readonly tableName: "shifts";
                readonly moduleId: "cafeFlow";
                readonly title: "Turnos";
                readonly purpose: "Controlar abertura e fechamento de turnos diários.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "Shift";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do turno.";
                }, {
                    readonly name: "shift_config_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Configuração de turno aplicada ao período operacional.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Status atual do turno.";
                }, {
                    readonly name: "opened_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de abertura do turno.";
                }, {
                    readonly name: "closed_at";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly description: "Data e hora de fechamento do turno.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly primaryKey: readonly ["shift_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "shift_config_id";
                    readonly targetEntity: "ShiftConfig";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Configuração de turno é entidade mestre MDM.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_shifts_status";
                    readonly columns: readonly ["status"];
                    readonly reason: "Filtrar turnos por status em dashboard e workflow.";
                }, {
                    readonly indexName: "idx_shifts_opened_at";
                    readonly columns: readonly ["opened_at"];
                    readonly reason: "Filtro por data para relatórios e dashboard.";
                }, {
                    readonly indexName: "idx_shifts_shift_config_id";
                    readonly columns: readonly ["shift_config_id"];
                    readonly reason: "Lookup por configuração de turno aplicada.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["dailySalesMetricTable"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/shift.defs.ts";
                readonly exportName: "shiftTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default shiftTableDefinition;
    export const pipeline: readonly [{
        readonly id: "shift__layer_1_external";
        readonly type: "layer_1_external";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_1_external/shift.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_1_external/shift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/shiftReport.defs" {
    export const shiftReportTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "shiftReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 50;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "shiftReport";
                readonly tableName: "shift_reports";
                readonly moduleId: "cafeFlow";
                readonly title: "Relatórios de Fechamento de Turno";
                readonly purpose: "Armazenar resumo do fechamento do turno para consulta gerencial.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "ShiftReport";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "shift_report_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do relatório de fechamento de turno.";
                }, {
                    readonly name: "shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência ao turno consolidado por este relatório.";
                }, {
                    readonly name: "report_status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly default: "gerado";
                    readonly description: "Status do relatório de fechamento do turno.";
                }, {
                    readonly name: "total_sales_amount";
                    readonly type: "money";
                    readonly nullable: false;
                    readonly description: "Total de vendas consolidadas no turno.";
                }, {
                    readonly name: "total_orders";
                    readonly type: "number";
                    readonly nullable: false;
                    readonly description: "Quantidade total de pedidos no turno.";
                }, {
                    readonly name: "total_items";
                    readonly type: "number";
                    readonly nullable: true;
                    readonly description: "Quantidade total de itens vendidos no turno.";
                }, {
                    readonly name: "shift_opened_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de abertura do turno reportado.";
                }, {
                    readonly name: "shift_closed_at";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly description: "Data e hora de fechamento do turno reportado.";
                }, {
                    readonly name: "notes";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Observações adicionais do fechamento do turno.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do relatório.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do relatório.";
                }];
                readonly primaryKey: readonly ["shift_report_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "shift_id";
                    readonly targetEntity: "Shift";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Relatório consolida um turno específico.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_shift_reports_shift_id_unique";
                    readonly columns: readonly ["shift_id"];
                    readonly unique: true;
                    readonly reason: "Garante um relatório por turno e lookup rápido pelo turno.";
                }, {
                    readonly indexName: "idx_shift_reports_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly unique: false;
                    readonly reason: "Filtro por período de criação em consultas gerenciais.";
                }, {
                    readonly indexName: "idx_shift_reports_shift_closed_at";
                    readonly columns: readonly ["shift_closed_at"];
                    readonly unique: false;
                    readonly reason: "Filtro por data de fechamento do turno no dashboard.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "ShiftReportDetails";
                    readonly reason: "Armazenar quebras consolidadas (formas de pagamento, categorias, descontos) sem necessidade de colunas próprias.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["dailySalesMetricTable"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/shiftReport.defs.ts";
                readonly exportName: "shiftReportTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default shiftReportTableDefinition;
    export const pipeline: readonly [{
        readonly id: "shiftReport__layer_1_external";
        readonly type: "layer_1_external";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_1_external/shiftReport.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_1_external/shiftReport.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/stockMovement.defs" {
    export const stockMovementTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "stockMovement";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 51;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "stockMovement";
                readonly tableName: "stock_movements";
                readonly moduleId: "cafeFlow";
                readonly title: "Movimentações de Estoque";
                readonly purpose: "Registrar entradas e saídas de estoque ligadas à operação diária.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "StockMovement";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "stock_movement_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da movimentação de estoque.";
                }, {
                    readonly name: "stock_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Item de estoque associado à movimentação.";
                }, {
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Pedido vinculado à saída de estoque, quando aplicável.";
                }, {
                    readonly name: "movement_type";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Tipo de movimentação realizada.";
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                    readonly nullable: false;
                    readonly description: "Quantidade movimentada do item de estoque.";
                }, {
                    readonly name: "reason";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Motivo ou observação da movimentação, especialmente para ajustes.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly default: "active";
                    readonly description: "Status do registro de movimentação.";
                }, {
                    readonly name: "occurred_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora em que a movimentação ocorreu.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly primaryKey: readonly ["stock_movement_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "stock_item_id";
                    readonly targetEntity: "StockItem";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Movimentação vinculada a item de estoque master.";
                }, {
                    readonly fieldName: "order_id";
                    readonly targetEntity: "Order";
                    readonly targetOwnership: "existingModuleOwned";
                    readonly reason: "Saídas podem estar vinculadas a pedidos existentes no módulo.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_stock_movements_stock_item_id";
                    readonly columns: readonly ["stock_item_id"];
                    readonly unique: false;
                    readonly reason: "Consulta por item de estoque para alertas e gestão.";
                }, {
                    readonly indexName: "idx_stock_movements_order_id";
                    readonly columns: readonly ["order_id"];
                    readonly unique: false;
                    readonly reason: "Rastrear movimentações relacionadas a pedidos.";
                }, {
                    readonly indexName: "idx_stock_movements_occurred_at";
                    readonly columns: readonly ["occurred_at"];
                    readonly unique: false;
                    readonly reason: "Filtros por período no dashboard e auditoria.";
                }, {
                    readonly indexName: "idx_stock_movements_movement_type";
                    readonly columns: readonly ["movement_type"];
                    readonly unique: false;
                    readonly reason: "Filtragem por tipo de movimentação.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["lowStockMetricTable", "dailySalesMetricTable", "topSellingItemsMetricTable"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["lowStockThresholdRule"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/stockMovement.defs.ts";
                readonly exportName: "stockMovementTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default stockMovementTableDefinition;
    export const pipeline: readonly [{
        readonly id: "stockMovement__layer_1_external";
        readonly type: "layer_1_external";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_1_external/stockMovement.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_1_external/stockMovement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.defs" {
    export const topSellingItemsMetricsTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "topSellingItemsMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 50;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "topSellingItemsMetrics";
                readonly tableName: "top_selling_items_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Itens mais vendidos";
                readonly purpose: "Identificar os produtos com maior saída e receita para otimização de cardápio e compras.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "time";
                readonly columns: readonly [{
                    readonly name: "time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp da métrica agregada.";
                }, {
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Pedido de origem do item";
                }, {
                    readonly name: "menu_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Item do cardápio vendido";
                }, {
                    readonly name: "menu_category_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Categoria do item no cardápio";
                }, {
                    readonly name: "shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Turno em que o item foi vendido";
                }, {
                    readonly name: "stock_item_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship menuItemUsesStockItem (MenuItem -> StockItem)";
                }, {
                    readonly name: "order_item_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship orderHasItems (Order -> OrderItem)";
                }, {
                    readonly name: "order_status_history_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship orderHasStatusHistory (Order -> OrderStatusHistory)";
                }, {
                    readonly name: "shift_report_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship shiftHasReport (Shift -> ShiftReport)";
                }, {
                    readonly name: "shift_config_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship shiftUsesConfig (Shift -> ShiftConfig)";
                }, {
                    readonly name: "quantity_sold";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade vendida do item";
                }, {
                    readonly name: "item_revenue";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Receita gerada pelo item";
                }, {
                    readonly name: "order_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Número de pedidos contendo o item";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "orderId";
                    readonly column: "order_id";
                    readonly type: "uuid";
                    readonly description: "Pedido de origem do item";
                }, {
                    readonly dimensionId: "menuItemId";
                    readonly column: "menu_item_id";
                    readonly type: "uuid";
                    readonly description: "Item do cardápio vendido";
                }, {
                    readonly dimensionId: "menuCategoryId";
                    readonly column: "menu_category_id";
                    readonly type: "uuid";
                    readonly description: "Categoria do item no cardápio";
                }, {
                    readonly dimensionId: "shiftId";
                    readonly column: "shift_id";
                    readonly type: "uuid";
                    readonly description: "Turno em que o item foi vendido";
                }, {
                    readonly dimensionId: "stockItemId";
                    readonly column: "stock_item_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship menuItemUsesStockItem (MenuItem -> StockItem)";
                }, {
                    readonly dimensionId: "orderItemId";
                    readonly column: "order_item_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship orderHasItems (Order -> OrderItem)";
                }, {
                    readonly dimensionId: "orderStatusHistoryId";
                    readonly column: "order_status_history_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship orderHasStatusHistory (Order -> OrderStatusHistory)";
                }, {
                    readonly dimensionId: "shiftReportId";
                    readonly column: "shift_report_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship shiftHasReport (Shift -> ShiftReport)";
                }, {
                    readonly dimensionId: "shiftConfigId";
                    readonly column: "shift_config_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship shiftUsesConfig (Shift -> ShiftConfig)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "quantitySold";
                    readonly column: "quantity_sold";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade vendida do item";
                }, {
                    readonly measureId: "itemRevenue";
                    readonly column: "item_revenue";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Receita gerada pelo item";
                }, {
                    readonly measureId: "orderCount";
                    readonly column: "order_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Número de pedidos contendo o item";
                }];
                readonly sourceWriteEvents: readonly ["orderCreated", "orderStatusUpdated"];
                readonly hypertable: {
                    readonly timeColumn: "time";
                    readonly chunkTimeInterval: "1 day";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_top_selling_items_metrics_time";
                        readonly columns: readonly ["time"];
                        readonly purpose: "Ordenação e retenção por tempo.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_time_menu_item";
                        readonly columns: readonly ["time", "menu_item_id"];
                        readonly purpose: "Ranking de itens por período.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_time_menu_category";
                        readonly columns: readonly ["time", "menu_category_id"];
                        readonly purpose: "Análise por categoria ao longo do tempo.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_time_shift";
                        readonly columns: readonly ["time", "shift_id"];
                        readonly purpose: "Comparação de vendas por turno.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_time_order";
                        readonly columns: readonly ["time", "order_id"];
                        readonly purpose: "Rastreio por pedido.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_stock_item";
                        readonly columns: readonly ["stock_item_id"];
                        readonly purpose: "Análise de consumo por insumo.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_order_item";
                        readonly columns: readonly ["order_item_id"];
                        readonly purpose: "Rastreio por item de pedido.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_order_status_history";
                        readonly columns: readonly ["order_status_history_id"];
                        readonly purpose: "Conciliação com transições de status.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_shift_report";
                        readonly columns: readonly ["shift_report_id"];
                        readonly purpose: "Vincular ao relatório de turno.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_shift_config";
                        readonly columns: readonly ["shift_config_id"];
                        readonly purpose: "Análise por configuração de turno.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["registrarPedido", "atualizarStatusCozinha", "fecharTurno"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["orderStatusTransition", "orderRequiresItem", "menuItemRequiresCategory"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/topSellingItemsMetrics.defs.ts";
                readonly exportName: "topSellingItemsMetricsTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default topSellingItemsMetricsTableDefinition;
    export const pipeline: readonly [{
        readonly id: "topSellingItemsMetrics__layer_1_external";
        readonly type: "layer_1_external";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.defs" {
    export const definition: ({
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: string[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    } | {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: string[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    })[];
    export const pipeline: readonly [{
        readonly id: "cardapioEstoque__layer_2_controllers";
        readonly type: "layer_2_controllers";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_3_usecases/listarItensCardapio.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/listarCategoriasCardapio.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/criarOuAtualizarItemCardapio.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/listarItensEstoque.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/criarOuAtualizarItemEstoque.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/registrarMovimentacaoEstoque.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/listarMovimentacoesEstoque.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/listarAlertasEstoqueBaixo.d.ts", "_102043_/l2/cafeFlow/web/contracts/cardapioEstoque.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["menuItemRequiresCategory", "lowStockThresholdRule"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IDataRuntime } from '_102034_/l1/server/layer_1_external/data/runtime';
    export type CardapioRecord = {
        menuItemId: string;
        name: string;
        description?: string | null;
        price: number;
        menuCategoryId: string;
        isActive: boolean;
        createdAt: string;
        updatedAt: string;
    };
    export interface CreateCardapioInput {
        name: string;
        description?: string | null;
        price: number;
        menuCategoryId: string;
        isActive: boolean;
    }
    export interface UpdateCardapioInput {
        menuItemId: string;
        patch: Partial<Pick<CardapioRecord, 'name' | 'description' | 'price' | 'menuCategoryId' | 'isActive'>>;
    }
    export interface ListCardapioFilter {
        menuCategoryId?: string;
        isActive?: boolean;
    }
    export interface ICardapioEntity {
        create(ctx: RequestContext, input: CreateCardapioInput, runtime?: IDataRuntime): Promise<CardapioRecord>;
        update(ctx: RequestContext, input: UpdateCardapioInput, runtime?: IDataRuntime): Promise<CardapioRecord>;
        getById(ctx: RequestContext, menuItemId: string, runtime?: IDataRuntime): Promise<CardapioRecord>;
        list(ctx: RequestContext, filter?: ListCardapioFilter, runtime?: IDataRuntime): Promise<CardapioRecord[]>;
    }
    export const CardapioEntity: ICardapioEntity;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarItensCardapio" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type CardapioRecord } from "_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity";
    export interface ListarItensCardapioInput {
    }
    export interface ListarItensCardapioOutput {
        itensCardapio: CardapioRecord[];
    }
    export function listarItensCardapio(ctx: RequestContext, _input: ListarItensCardapioInput): Promise<ListarItensCardapioOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarCategoriasCardapio" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    type MenuCategory = never;
    export interface ListarCategoriasCardapioInput {
    }
    export interface ListarCategoriasCardapioOutput {
        categorias: MenuCategory[];
    }
    export function listarCategoriasCardapio(ctx: RequestContext, input: ListarCategoriasCardapioInput): Promise<ListarCategoriasCardapioOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarOuAtualizarItemCardapio" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type CardapioRecord } from "_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity";
    export interface CriarOuAtualizarItemCardapioInput {
        cardapioEntity: CardapioRecord;
    }
    export interface CriarOuAtualizarItemCardapioOutput {
        cardapioEntity: CardapioRecord;
    }
    export function criarOuAtualizarItemCardapio(ctx: RequestContext, input: CriarOuAtualizarItemCardapioInput): Promise<CriarOuAtualizarItemCardapioOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IDataRuntime } from '_102034_/l1/server/layer_1_external/data/runtime';
    export type StockMovementType = 'entrada' | 'saida' | 'ajuste';
    export interface StockMovementRecord {
        stock_movement_id: string;
        stock_item_id: string;
        order_id?: string | null;
        movement_type: StockMovementType;
        quantity: number;
        reason?: string | null;
        occurred_at: string;
        created_at: string;
        updated_at: string;
    }
    export interface CreateEstoqueInput {
        stockItemId: string;
        orderId?: string | null;
        movementType: StockMovementType;
        quantity: number;
        reason?: string | null;
        occurredAt: string;
    }
    export interface UpdateEstoqueInput {
        stockMovementId: string;
        stockItemId?: string;
        orderId?: string | null;
        movementType?: StockMovementType;
        quantity?: number;
        reason?: string | null;
        occurredAt?: string;
    }
    export interface ListEstoqueFilter {
        stockItemId?: string;
        orderId?: string;
        movementType?: StockMovementType;
    }
    export interface IEstoqueEntity {
        create(ctx: RequestContext, input: CreateEstoqueInput, runtime?: IDataRuntime): Promise<StockMovementRecord>;
        update(ctx: RequestContext, input: UpdateEstoqueInput, runtime?: IDataRuntime): Promise<StockMovementRecord>;
        getById(ctx: RequestContext, stockMovementId: string, runtime?: IDataRuntime): Promise<StockMovementRecord>;
        list(ctx: RequestContext, filter?: ListEstoqueFilter, runtime?: IDataRuntime): Promise<StockMovementRecord[]>;
    }
    export const EstoqueEntity: IEstoqueEntity;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarItensEstoque" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type StockMovementRecord } from "_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity";
    export interface ListarItensEstoqueInput {
    }
    export interface ListarItensEstoqueOutput {
        itensEstoque: StockMovementRecord[];
    }
    export function listarItensEstoque(ctx: RequestContext, _input: ListarItensEstoqueInput): Promise<ListarItensEstoqueOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarOuAtualizarItemEstoque" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type CreateEstoqueInput, type UpdateEstoqueInput, type StockMovementRecord } from "_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity";
    export interface CriarOuAtualizarItemEstoqueInput {
        estoqueEntity: CreateEstoqueInput | UpdateEstoqueInput;
    }
    export interface CriarOuAtualizarItemEstoqueOutput {
        estoqueEntity: StockMovementRecord;
    }
    export function criarOuAtualizarItemEstoque(ctx: RequestContext, input: CriarOuAtualizarItemEstoqueInput): Promise<CriarOuAtualizarItemEstoqueOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/metricasEntity" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IDataRuntime } from '_102034_/l1/server/layer_1_external/data/runtime';
    export type DailySalesMetricsRecord = Record<string, unknown>;
    export type TopSellingItemsMetricsRecord = Record<string, unknown>;
    export type LowStockMetricsRecord = Record<string, unknown>;
    export type MetricasMetricTableName = 'daily_sales_metrics' | 'top_selling_items_metrics' | 'low_stock_metrics';
    export type MetricasMetricRecord = DailySalesMetricsRecord | TopSellingItemsMetricsRecord | LowStockMetricsRecord;
    export interface MetricasGetByIdInput {
        tableName: MetricasMetricTableName;
        key: Record<string, unknown>;
    }
    export interface MetricasUpdateInput {
        tableName: MetricasMetricTableName;
        record: MetricasMetricRecord;
    }
    export interface IMetricasEntity {
        getById(ctx: RequestContext, input: MetricasGetByIdInput, runtime?: IDataRuntime): Promise<MetricasMetricRecord>;
        update(ctx: RequestContext, input: MetricasUpdateInput, runtime?: IDataRuntime): Promise<MetricasMetricRecord>;
    }
    export const MetricasEntity: IMetricasEntity;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/registrarMovimentacaoEstoque" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface RegistrarMovimentacaoEstoqueInput {
        stockItemId: string;
        movementType: string;
        quantity: number;
        unitOfMeasureId: string;
        movementDate?: Date;
        reason?: string;
    }
    export interface RegistrarMovimentacaoEstoqueOutput {
        stockItemId: string;
        quantity: number;
    }
    export function registrarMovimentacaoEstoque(ctx: RequestContext, input: RegistrarMovimentacaoEstoqueInput): Promise<RegistrarMovimentacaoEstoqueOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarMovimentacoesEstoque" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type StockMovementRecord } from "_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity";
    export interface ListarMovimentacoesEstoqueInput {
    }
    export interface ListarMovimentacoesEstoqueOutput {
        movimentacoes: StockMovementRecord[];
    }
    export function listarMovimentacoesEstoque(ctx: RequestContext, _input: ListarMovimentacoesEstoqueInput): Promise<ListarMovimentacoesEstoqueOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarAlertasEstoqueBaixo" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { StockMovementRecord } from "_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity";
    export interface ListarAlertasEstoqueBaixoInput {
    }
    export interface ListarAlertasEstoqueBaixoOutput {
        alertas: StockMovementRecord[];
    }
    export function listarAlertasEstoqueBaixo(_ctx: RequestContext, _input: ListarAlertasEstoqueBaixoInput): Promise<ListarAlertasEstoqueBaixoOutput>;
    export const implementation: {
        readonly functionName: "listarAlertasEstoqueBaixo";
        readonly inputTypeName: "ListarAlertasEstoqueBaixoInput";
        readonly outputTypeName: "ListarAlertasEstoqueBaixoOutput";
        readonly tsFileRef: "_102043_/l1/cafeFlow/layer_3_usecases/listarAlertasEstoqueBaixo.ts";
    };
}
declare module "_102043_/l2/cafeFlow/web/contracts/cardapioEstoque" {
    export interface CardapioEstoqueListarItensCardapioInput {
        categoriaId?: string;
        disponivel?: boolean;
    }
    export interface CardapioEstoqueListarItensCardapioOutputItem {
        menuItemId: string;
        nome: string;
        preco: number;
        categoriaId: string;
        ativo: boolean;
    }
    export type CardapioEstoqueListarItensCardapioOutput = CardapioEstoqueListarItensCardapioOutputItem[];
    export interface CardapioEstoqueListarCategoriasCardapioInput {
    }
    export interface CardapioEstoqueListarCategoriasCardapioOutputItem {
        categoriaId: string;
        nome: string;
        ativo: boolean;
    }
    export type CardapioEstoqueListarCategoriasCardapioOutput = CardapioEstoqueListarCategoriasCardapioOutputItem[];
    export interface CardapioEstoqueCriarOuAtualizarItemCardapioInput {
        menuItemId?: string;
        nome: string;
        preco: number;
        categoriaId: string;
        ativo: boolean;
    }
    export interface CardapioEstoqueCriarOuAtualizarItemCardapioOutput {
        menuItemId: string;
    }
    export interface CardapioEstoqueListarItensEstoqueInput {
        categoriaId?: string;
        status?: string;
    }
    export interface CardapioEstoqueListarItensEstoqueOutputItem {
        stockItemId: string;
        nome: string;
        quantidadeAtual: number;
        unidadeMedidaId: string;
        quantidadeMinima: number;
        status: string;
    }
    export type CardapioEstoqueListarItensEstoqueOutput = CardapioEstoqueListarItensEstoqueOutputItem[];
    export interface CardapioEstoqueCriarOuAtualizarItemEstoqueInput {
        stockItemId?: string;
        nome: string;
        unidadeMedidaId: string;
        quantidadeMinima: number;
        ativo: boolean;
    }
    export interface CardapioEstoqueCriarOuAtualizarItemEstoqueOutput {
        stockItemId: string;
    }
    export interface CardapioEstoqueRegistrarMovimentacaoEstoqueInput {
        stockItemId: string;
        movementType: string;
        quantity: number;
        reason?: string;
        occurredAt: string;
    }
    export interface CardapioEstoqueRegistrarMovimentacaoEstoqueOutput {
        stockMovementId: string;
    }
    export interface CardapioEstoqueListarMovimentacoesEstoqueInput {
        stockItemId?: string;
        dataInicio?: string;
        dataFim?: string;
    }
    export interface CardapioEstoqueListarMovimentacoesEstoqueOutputItem {
        stockMovementId: string;
        stockItemId: string;
        movementType: string;
        quantity: number;
        reason: string;
        occurredAt: string;
    }
    export type CardapioEstoqueListarMovimentacoesEstoqueOutput = CardapioEstoqueListarMovimentacoesEstoqueOutputItem[];
    export interface CardapioEstoqueListarAlertasEstoqueBaixoInput {
        status?: string;
    }
    export interface CardapioEstoqueListarAlertasEstoqueBaixoOutputItem {
        lowStockAlertId: string;
        stockItemId: string;
        triggeredAt: string;
        currentQuantity: number;
        minimumQuantity: number;
        status: string;
    }
    export type CardapioEstoqueListarAlertasEstoqueBaixoOutput = CardapioEstoqueListarAlertasEstoqueBaixoOutputItem[];
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const CafeFlowCardapioEstoqueListarItensCardapioHandler: BffHandler;
    export const CafeFlowCardapioEstoqueListarCategoriasCardapioHandler: BffHandler;
    export const CafeFlowCardapioEstoqueCriarOuAtualizarItemCardapioHandler: BffHandler;
    export const CafeFlowCardapioEstoqueListarItensEstoqueHandler: BffHandler;
    export const CafeFlowCardapioEstoqueCriarOuAtualizarItemEstoqueHandler: BffHandler;
    export const CafeFlowCardapioEstoqueRegistrarMovimentacaoEstoqueHandler: BffHandler;
    export const CafeFlowCardapioEstoqueListarMovimentacoesEstoqueHandler: BffHandler;
    export const CafeFlowCardapioEstoqueListarAlertasEstoqueBaixoHandler: BffHandler;
    export const cardapioEstoqueRouter: {
        readonly 'cafeFlow.cardapioEstoque.listarItensCardapio': {
            readonly handlerName: "CafeFlowCardapioEstoqueListarItensCardapioHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.js";
        };
        readonly 'cafeFlow.cardapioEstoque.listarCategoriasCardapio': {
            readonly handlerName: "CafeFlowCardapioEstoqueListarCategoriasCardapioHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.js";
        };
        readonly 'cafeFlow.cardapioEstoque.criarOuAtualizarItemCardapio': {
            readonly handlerName: "CafeFlowCardapioEstoqueCriarOuAtualizarItemCardapioHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.js";
        };
        readonly 'cafeFlow.cardapioEstoque.listarItensEstoque': {
            readonly handlerName: "CafeFlowCardapioEstoqueListarItensEstoqueHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.js";
        };
        readonly 'cafeFlow.cardapioEstoque.criarOuAtualizarItemEstoque': {
            readonly handlerName: "CafeFlowCardapioEstoqueCriarOuAtualizarItemEstoqueHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.js";
        };
        readonly 'cafeFlow.cardapioEstoque.registrarMovimentacaoEstoque': {
            readonly handlerName: "CafeFlowCardapioEstoqueRegistrarMovimentacaoEstoqueHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.js";
        };
        readonly 'cafeFlow.cardapioEstoque.listarMovimentacoesEstoque': {
            readonly handlerName: "CafeFlowCardapioEstoqueListarMovimentacoesEstoqueHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.js";
        };
        readonly 'cafeFlow.cardapioEstoque.listarAlertasEstoqueBaixo': {
            readonly handlerName: "CafeFlowCardapioEstoqueListarAlertasEstoqueBaixoHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.js";
        };
    };
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/dashboardGerente.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: any[];
    }[];
    export const pipeline: readonly [{
        readonly id: "dashboardGerente__layer_2_controllers";
        readonly type: "layer_2_controllers";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_2_controllers/dashboardGerente.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_2_controllers/dashboardGerente.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_3_usecases/consultarDashboardGerente.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/listarAlertasEstoqueBaixo.d.ts", "_102043_/l2/cafeFlow/web/contracts/dashboardGerente.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/consultarDashboardGerente" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type DailySalesMetricsRecord, type TopSellingItemsMetricsRecord, type LowStockMetricsRecord } from "_102043_/l1/cafeFlow/layer_4_entities/metricasEntity";
    export interface ConsultarDashboardGerenteInput {
    }
    export interface ConsultarDashboardGerenteResult {
        metricas: {
            dailySalesMetrics: DailySalesMetricsRecord;
            topSellingItemsMetrics: TopSellingItemsMetricsRecord;
            lowStockMetrics: LowStockMetricsRecord;
        };
    }
    export function consultarDashboardGerente(ctx: RequestContext, _input: ConsultarDashboardGerenteInput): Promise<ConsultarDashboardGerenteResult>;
}
declare module "_102043_/l2/cafeFlow/web/contracts/dashboardGerente" {
    export interface DashboardGerenteConsultarDashboardGerenteInput {
        periodoInicio?: string;
        periodoFim?: string;
        turnoId?: string;
    }
    export interface DashboardGerenteConsultarDashboardGerenteOutput {
        totalRevenue: number;
        orderCount: number;
        averageTicket: number;
        itemsSold: number;
        serieVendasPorTurno: string;
        rankingItensMaisVendidos: string;
    }
    export interface DashboardGerenteListarAlertasEstoqueBaixoInput {
        statusAlerta?: string;
    }
    export interface DashboardGerenteListarAlertasEstoqueBaixoOutputItem {
        alertas: string;
    }
    export type DashboardGerenteListarAlertasEstoqueBaixoOutput = DashboardGerenteListarAlertasEstoqueBaixoOutputItem[];
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/dashboardGerente" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowDashboardGerenteConsultarDashboardGerenteHandler: BffHandler;
    export const cafeFlowDashboardGerenteListarAlertasEstoqueBaixoHandler: BffHandler;
    export const dashboardGerenteRoutes: {
        readonly 'cafeFlow.dashboardGerente.consultarDashboardGerente': {
            readonly handlerName: "cafeFlowDashboardGerenteConsultarDashboardGerenteHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/dashboardGerente.js";
        };
        readonly 'cafeFlow.dashboardGerente.listarAlertasEstoqueBaixo': {
            readonly handlerName: "cafeFlowDashboardGerenteListarAlertasEstoqueBaixoHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/dashboardGerente.js";
        };
    };
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/fechamentoTurno.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: string[];
        writesTables: string[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "fechamentoTurno__layer_2_controllers";
        readonly type: "layer_2_controllers";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_2_controllers/fechamentoTurno.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_2_controllers/fechamentoTurno.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_3_usecases/listarTurnos.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidos.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/fecharTurno.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/obterRelatorioTurno.d.ts", "_102043_/l2/cafeFlow/web/contracts/fechamentoTurno.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/turnoEntity" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IDataRuntime } from '_102034_/l1/server/layer_1_external/data/runtime';
    export type TurnoStatus = 'aberto' | 'emFechamento' | 'fechado';
    export interface TurnoRecord {
        shift_id: string;
        shift_config_id: string;
        status: TurnoStatus;
        opened_at: string;
        closed_at?: string | null;
        created_at: string;
        updated_at: string;
    }
    export interface CreateTurnoInput {
        shiftConfigId: string;
        status: TurnoStatus;
        openedAt: string;
        closedAt?: string | null;
    }
    export interface UpdateTurnoInput {
        shiftId: string;
        patch: {
            shiftConfigId?: string;
            status?: TurnoStatus;
            openedAt?: string;
            closedAt?: string | null;
        };
    }
    export interface ListTurnoFilter {
        shiftConfigId?: string;
        status?: TurnoStatus;
    }
    export interface ITurnoEntity {
        create(ctx: RequestContext, input: CreateTurnoInput, runtime?: IDataRuntime): Promise<TurnoRecord>;
        getById(ctx: RequestContext, shiftId: string, runtime?: IDataRuntime): Promise<TurnoRecord>;
        list(ctx: RequestContext, filter?: ListTurnoFilter, runtime?: IDataRuntime): Promise<TurnoRecord[]>;
        update(ctx: RequestContext, input: UpdateTurnoInput, runtime?: IDataRuntime): Promise<TurnoRecord>;
    }
    export const TurnoEntity: ITurnoEntity;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarTurnos" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type TurnoRecord } from "_102043_/l1/cafeFlow/layer_4_entities/turnoEntity";
    export interface ListarTurnosInput {
    }
    export interface ListarTurnosResult {
        turnos: TurnoRecord[];
    }
    export function listarTurnos(ctx: RequestContext, _input: ListarTurnosInput): Promise<ListarTurnosResult>;
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IDataRuntime } from '_102034_/l1/server/layer_1_external/data/runtime';
    export type PedidoStatus = 'recebido' | 'emPreparo' | 'pronto' | 'entregue' | 'cancelado';
    export interface PedidoRecord {
        order_id: string;
        status: PedidoStatus;
        shift_id: string;
        created_at: string;
        updated_at: string;
    }
    export interface PedidoStatusHistoryRecord {
        id: string;
        order_id: string;
        from_status?: PedidoStatus | null;
        to_status: PedidoStatus;
        created_at: string;
    }
    export interface CreatePedidoInput {
        status: PedidoStatus;
        shiftId: string;
    }
    export interface UpdatePedidoInput {
        orderId: string;
        status?: PedidoStatus;
        shiftId?: string;
    }
    export interface ListPedidoFilter {
        status?: PedidoStatus;
        shiftId?: string;
    }
    export interface IPedidoEntity {
        create(ctx: RequestContext, input: CreatePedidoInput, runtime?: IDataRuntime): Promise<PedidoRecord>;
        getById(ctx: RequestContext, orderId: string, runtime?: IDataRuntime): Promise<PedidoRecord>;
        update(ctx: RequestContext, input: UpdatePedidoInput, runtime?: IDataRuntime): Promise<PedidoRecord>;
        list(ctx: RequestContext, filter?: ListPedidoFilter, runtime?: IDataRuntime): Promise<PedidoRecord[]>;
    }
    export const PedidoEntity: IPedidoEntity;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidos" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type PedidoRecord } from "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity";
    export interface ListarPedidosInput {
    }
    export interface ListarPedidosOutput {
        pedidos: PedidoRecord[];
    }
    export function listarPedidos(ctx: RequestContext, _input: ListarPedidosInput): Promise<ListarPedidosOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/fecharTurno" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface FecharTurnoInput {
        turnoId: string;
    }
    export interface FecharTurnoOutput {
        turnoId: string;
        status: string;
    }
    export function fecharTurno(ctx: RequestContext, input: FecharTurnoInput): Promise<FecharTurnoOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/obterRelatorioTurno" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type TurnoRecord } from "_102043_/l1/cafeFlow/layer_4_entities/turnoEntity";
    export interface ObterRelatorioTurnoInput {
        turnoId: string;
    }
    export interface ObterRelatorioTurnoOutput {
        turno: TurnoRecord;
    }
    export function obterRelatorioTurno(ctx: RequestContext, input: ObterRelatorioTurnoInput): Promise<ObterRelatorioTurnoOutput>;
}
declare module "_102043_/l2/cafeFlow/web/contracts/fechamentoTurno" {
    export interface FechamentoTurnoListarTurnosInput {
        dataInicio?: string;
        dataFim?: string;
        status?: string;
    }
    export interface FechamentoTurnoListarTurnosOutputItem {
        shiftId: string;
        status: string;
        openedAt: string;
        closedAt: string;
        shiftConfigId: string;
    }
    export type FechamentoTurnoListarTurnosOutput = FechamentoTurnoListarTurnosOutputItem[];
    export interface FechamentoTurnoListarPedidosInput {
        shiftId: string;
        status?: string;
    }
    export interface FechamentoTurnoListarPedidosOutputItem {
        orderId: string;
        status: string;
        shiftId: string;
        createdAt: string;
        updatedAt: string;
    }
    export type FechamentoTurnoListarPedidosOutput = FechamentoTurnoListarPedidosOutputItem[];
    export interface FechamentoTurnoFecharTurnoInput {
        shiftId: string;
    }
    export interface FechamentoTurnoFecharTurnoOutput {
        shiftId: string;
        status: string;
        closedAt: string;
        shiftReportId: string;
    }
    export interface FechamentoTurnoObterRelatorioTurnoInput {
        shiftId: string;
    }
    export interface FechamentoTurnoObterRelatorioTurnoOutput {
        shiftReportId: string;
        shiftId: string;
        totalSalesAmount: string;
        totalOrders: number;
        totalItems: number;
        notes: string;
        createdAt: string;
        updatedAt: string;
    }
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/fechamentoTurno" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowFechamentoTurnoListarTurnosHandler: BffHandler;
    export const cafeFlowFechamentoTurnoListarPedidosHandler: BffHandler;
    export const cafeFlowFechamentoTurnoFecharTurnoHandler: BffHandler;
    export const cafeFlowFechamentoTurnoObterRelatorioTurnoHandler: BffHandler;
    export const fechamentoTurnoRouter: {
        'cafeFlow.fechamentoTurno.listarTurnos': {
            handlerName: string;
            importPath: string;
        };
        'cafeFlow.fechamentoTurno.listarPedidos': {
            handlerName: string;
            importPath: string;
        };
        'cafeFlow.fechamentoTurno.fecharTurno': {
            handlerName: string;
            importPath: string;
        };
        'cafeFlow.fechamentoTurno.obterRelatorioTurno': {
            handlerName: string;
            importPath: string;
        };
    };
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/painelCozinha.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: string[];
        writesTables: string[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "painelCozinha__layer_2_controllers";
        readonly type: "layer_2_controllers";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_2_controllers/painelCozinha.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_2_controllers/painelCozinha.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_3_usecases/listarPedidosCozinha.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/atualizarStatusPedido.d.ts", "_102043_/l2/cafeFlow/web/contracts/painelCozinha.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["orderStatusTransition"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidosCozinha" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type PedidoRecord } from "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity";
    export interface ListarPedidosCozinhaInput {
    }
    export interface ListarPedidosCozinhaOutput {
        pedidos: PedidoRecord[];
    }
    export function listarPedidosCozinha(ctx: RequestContext, _input: ListarPedidosCozinhaInput): Promise<ListarPedidosCozinhaOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/atualizarStatusPedido" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type PedidoRecord } from "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity";
    export interface AtualizarStatusPedidoInput {
        pedidoId: string;
        novoStatus: string;
    }
    export interface AtualizarStatusPedidoOutput {
        pedido: PedidoRecord;
    }
    export function atualizarStatusPedido(ctx: RequestContext, input: AtualizarStatusPedidoInput): Promise<AtualizarStatusPedidoOutput>;
}
declare module "_102043_/l2/cafeFlow/web/contracts/painelCozinha" {
    export interface PainelCozinhaListarPedidosCozinhaInput {
        status?: string;
        shiftId?: string;
    }
    export interface PainelCozinhaListarPedidosCozinhaOutputItem {
        orderId: string;
        status: string;
        createdAt: string;
        shiftId: string;
    }
    export type PainelCozinhaListarPedidosCozinhaOutput = PainelCozinhaListarPedidosCozinhaOutputItem[];
    export interface PainelCozinhaAtualizarStatusPedidoInput {
        orderId: string;
        novoStatus: string;
    }
    export interface PainelCozinhaAtualizarStatusPedidoOutput {
        orderId: string;
        status: string;
        updatedAt: string;
    }
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/painelCozinha" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowPainelCozinhaListarPedidosCozinhaHandler: BffHandler;
    export const cafeFlowPainelCozinhaAtualizarStatusPedidoHandler: BffHandler;
    export const painelCozinhaRouter: {
        readonly 'cafeFlow.painelCozinha.listarPedidosCozinha': {
            readonly handlerName: "cafeFlowPainelCozinhaListarPedidosCozinhaHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/painelCozinha.js";
        };
        readonly 'cafeFlow.painelCozinha.atualizarStatusPedido': {
            readonly handlerName: "cafeFlowPainelCozinhaAtualizarStatusPedidoHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/painelCozinha.js";
        };
    };
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/posRapido.defs" {
    export const definition: ({
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: string[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: any[];
    } | {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: string[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    })[];
    export const pipeline: readonly [{
        readonly id: "posRapido__layer_2_controllers";
        readonly type: "layer_2_controllers";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_2_controllers/posRapido.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_2_controllers/posRapido.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_3_usecases/listarPedidos.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/criarPedido.d.ts", "_102043_/l2/cafeFlow/web/contracts/posRapido.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["orderRequiresItem"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarPedido" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type CardapioRecord } from "_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity";
    import { type CreatePedidoInput, type PedidoRecord } from "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity";
    export interface CriarPedidoInput {
        pedido: CreatePedidoInput;
        itens: CardapioRecord[];
    }
    export interface CriarPedidoOutput {
        pedido: PedidoRecord;
    }
    export function criarPedido(ctx: RequestContext, input: CriarPedidoInput): Promise<CriarPedidoOutput>;
}
declare module "_102043_/l2/cafeFlow/web/contracts/posRapido" {
    export interface PosRapidoListarPedidosInput {
        status?: string;
        dateFrom?: string;
        dateTo?: string;
    }
    export interface PosRapidoListarPedidosOutputItem {
        orderId: string;
        status: string;
        createdAt: string;
        updatedAt: string;
    }
    export type PosRapidoListarPedidosOutput = PosRapidoListarPedidosOutputItem[];
    export interface PosRapidoCriarPedidoInput {
        orderItems: string;
        observacao?: string;
    }
    export interface PosRapidoCriarPedidoOutput {
        orderId: string;
        status: string;
        createdAt: string;
        updatedAt: string;
    }
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/posRapido" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowPosRapidoListarPedidosHandler: BffHandler;
    export const cafeFlowPosRapidoCriarPedidoHandler: BffHandler;
    export const posRapidoRoutes: {
        'cafeFlow.posRapido.listarPedidos': {
            handler: BffHandler;
            importPath: string;
        };
        'cafeFlow.posRapido.criarPedido': {
            handler: BffHandler;
            importPath: string;
        };
    };
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/router" {
    import type { BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export function createCafeFlowRouter(): Map<string, BffHandler>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/abrirTurno.defs" {
    export const useCase: {
        readonly usecaseId: "abrirTurno";
        readonly title: "Abrir turno";
        readonly purpose: "Iniciar um turno diário.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["turnoEntity"];
        readonly outputEntities: readonly ["turnoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "ShiftConfig";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "shifts";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["metricasEntity", "turnoEntity"];
        readonly commands: readonly [{
            readonly commandId: "abrirTurno";
            readonly input: readonly [{
                readonly name: "turnoId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "turnoId";
                readonly type: "string";
            }];
        }];
        readonly pendingQuestions: readonly ["Quais campos obrigatórios do turnoEntity devem ser informados para abrir o turno (ex.: data, lojaId, gerenteId), além de um possível turnoId?"];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "abrirTurno__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/abrirTurno.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/abrirTurno.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/metricasEntity.d.ts", "_102043_/l1/cafeFlow/layer_4_entities/turnoEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/abrirTurno" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface AbrirTurnoInput {
        turnoId: string;
    }
    export interface AbrirTurnoOutput {
        turnoId: string;
    }
    export function abrirTurno(_ctx: RequestContext, _input: AbrirTurnoInput): Promise<AbrirTurnoOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/atualizarStatusPedido.defs" {
    export const useCase: {
        readonly usecaseId: "atualizarStatusPedido";
        readonly title: "Atualizar status do pedido";
        readonly purpose: "Atualizar status de preparo e entrega do pedido.";
        readonly actor: "cozinha";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["pedidoEntity"];
        readonly outputEntities: readonly ["pedidoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_status_history";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["orderStatusTransition"];
        readonly entityRefs: readonly ["metricasEntity", "pedidoEntity"];
        readonly commands: readonly [{
            readonly commandId: "atualizarStatusPedido";
            readonly input: readonly [{
                readonly name: "pedidoId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "novoStatus";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "pedido";
                readonly type: "pedidoEntity";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "atualizarStatusPedido__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/atualizarStatusPedido.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/atualizarStatusPedido.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/metricasEntity.d.ts", "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["orderStatusTransition"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/consultarDashboardGerente.defs" {
    export const useCase: {
        readonly usecaseId: "consultarDashboardGerente";
        readonly title: "Consultar dashboard do gerente";
        readonly purpose: "Consultar métricas de vendas, itens mais vendidos e estoque baixo.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["metricasEntity"];
        readonly outputEntities: readonly ["metricasEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["metricasEntity"];
        readonly commands: readonly [{
            readonly commandId: "consultarDashboardGerente";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "metricas";
                readonly type: "metricasEntity";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "consultarDashboardGerente__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/consultarDashboardGerente.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/consultarDashboardGerente.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/metricasEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarOuAtualizarItemCardapio.defs" {
    export const useCase: {
        readonly usecaseId: "criarOuAtualizarItemCardapio";
        readonly title: "Criar ou atualizar item do cardápio";
        readonly purpose: "Cadastrar ou editar item do cardápio.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["cardapioEntity"];
        readonly outputEntities: readonly ["cardapioEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "MenuCategory";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "MenuItem";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly ["menuItemRequiresCategory"];
        readonly entityRefs: readonly ["cardapioEntity"];
        readonly commands: readonly [{
            readonly commandId: "criarOuAtualizarItemCardapio";
            readonly input: readonly [{
                readonly name: "cardapioEntity";
                readonly type: "cardapioEntity";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "cardapioEntity";
                readonly type: "cardapioEntity";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "criarOuAtualizarItemCardapio__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/criarOuAtualizarItemCardapio.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/criarOuAtualizarItemCardapio.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["menuItemRequiresCategory"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarOuAtualizarItemEstoque.defs" {
    export const useCase: {
        readonly usecaseId: "criarOuAtualizarItemEstoque";
        readonly title: "Criar ou atualizar item de estoque";
        readonly purpose: "Cadastrar ou editar item de estoque.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["estoqueEntity"];
        readonly outputEntities: readonly ["estoqueEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "UnitOfMeasure";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "StockItem";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["estoqueEntity"];
        readonly commands: readonly [{
            readonly commandId: "criarOuAtualizarItemEstoque";
            readonly input: readonly [{
                readonly name: "estoqueEntity";
                readonly type: "estoqueEntity";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "estoqueEntity";
                readonly type: "estoqueEntity";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "criarOuAtualizarItemEstoque__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/criarOuAtualizarItemEstoque.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/criarOuAtualizarItemEstoque.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarPedido.defs" {
    export const useCase: {
        readonly usecaseId: "criarPedido";
        readonly title: "Criar pedido";
        readonly purpose: "Registrar um novo pedido no POS com itens.";
        readonly actor: "atendente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["pedidoEntity", "cardapioEntity"];
        readonly outputEntities: readonly ["pedidoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "MenuItem";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_status_history";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["orderRequiresItem"];
        readonly entityRefs: readonly ["cardapioEntity", "metricasEntity", "pedidoEntity"];
        readonly commands: readonly [{
            readonly commandId: "criarPedido";
            readonly input: readonly [{
                readonly name: "pedido";
                readonly type: "pedidoEntity";
                readonly required: true;
            }, {
                readonly name: "itens";
                readonly type: "cardapioEntity[]";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "pedido";
                readonly type: "pedidoEntity";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "criarPedido__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/criarPedido.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/criarPedido.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity.d.ts", "_102043_/l1/cafeFlow/layer_4_entities/metricasEntity.d.ts", "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["orderRequiresItem"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/fecharTurno.defs" {
    export const useCase: {
        readonly usecaseId: "fecharTurno";
        readonly title: "Fechar turno";
        readonly purpose: "Encerrar o turno e gerar relatório de fechamento.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["turnoEntity", "pedidoEntity"];
        readonly outputEntities: readonly ["turnoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "shifts";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "shifts";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "shift_reports";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
        readonly entityRefs: readonly ["metricasEntity", "pedidoEntity", "turnoEntity"];
        readonly commands: readonly [{
            readonly commandId: "fecharTurno";
            readonly input: readonly [{
                readonly name: "turnoId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "turnoId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "fecharTurno__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/fecharTurno.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/fecharTurno.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/metricasEntity.d.ts", "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity.d.ts", "_102043_/l1/cafeFlow/layer_4_entities/turnoEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarAlertasEstoqueBaixo.defs" {
    export const useCase: {
        readonly usecaseId: "listarAlertasEstoqueBaixo";
        readonly title: "Listar alertas de estoque baixo";
        readonly purpose: "Consultar alertas de estoque baixo.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["estoqueEntity"];
        readonly outputEntities: readonly ["estoqueEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "low_stock_alerts";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["estoqueEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarAlertasEstoqueBaixo";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "alertas";
                readonly type: "estoqueEntity[]";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "listarAlertasEstoqueBaixo__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarAlertasEstoqueBaixo.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarAlertasEstoqueBaixo.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarCategoriasCardapio.defs" {
    export const useCase: {
        readonly usecaseId: "listarCategoriasCardapio";
        readonly title: "Listar categorias do cardápio";
        readonly purpose: "Consultar categorias disponíveis para cardápio.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["cardapioEntity"];
        readonly outputEntities: readonly ["cardapioEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "MenuCategory";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["cardapioEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarCategoriasCardapio";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "categorias";
                readonly type: "MenuCategory[]";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "listarCategoriasCardapio__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarCategoriasCardapio.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarCategoriasCardapio.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarItensCardapio.defs" {
    export const useCase: {
        readonly usecaseId: "listarItensCardapio";
        readonly title: "Listar itens do cardápio";
        readonly purpose: "Consultar itens do cardápio e suas categorias.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["cardapioEntity"];
        readonly outputEntities: readonly ["cardapioEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "MenuItem";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "MenuCategory";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["cardapioEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarItensCardapio";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "itensCardapio";
                readonly type: "cardapioEntity[]";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "listarItensCardapio__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarItensCardapio.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarItensCardapio.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarItensEstoque.defs" {
    export const useCase: {
        readonly usecaseId: "listarItensEstoque";
        readonly title: "Listar itens de estoque";
        readonly purpose: "Consultar itens de estoque cadastrados.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["estoqueEntity"];
        readonly outputEntities: readonly ["estoqueEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "StockItem";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "UnitOfMeasure";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["estoqueEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarItensEstoque";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "itensEstoque";
                readonly type: "estoqueEntity[]";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "listarItensEstoque__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarItensEstoque.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarItensEstoque.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarMovimentacoesEstoque.defs" {
    export const useCase: {
        readonly usecaseId: "listarMovimentacoesEstoque";
        readonly title: "Listar movimentações de estoque";
        readonly purpose: "Consultar histórico de movimentações de estoque.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["estoqueEntity"];
        readonly outputEntities: readonly ["estoqueEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "stock_movements";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["estoqueEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarMovimentacoesEstoque";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "movimentacoes";
                readonly type: "estoqueEntity[]";
            }];
        }];
        readonly pendingQuestions: readonly ["Quais filtros de entrada são obrigatórios ou opcionais para listar movimentações (por exemplo, estoqueId, período, produto, depósito)?", "Quais campos devem compor cada item retornado em uma movimentação de estoque?"];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "listarMovimentacoesEstoque__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarMovimentacoesEstoque.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarMovimentacoesEstoque.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidos.defs" {
    export const useCase: {
        readonly usecaseId: "listarPedidos";
        readonly title: "Listar pedidos";
        readonly purpose: "Listar pedidos com status atual.";
        readonly actor: "atendente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["pedidoEntity"];
        readonly outputEntities: readonly ["pedidoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_status_history";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["pedidoEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarPedidos";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "pedidos";
                readonly type: "pedidoEntity[]";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "listarPedidos__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidos.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidos.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidosCozinha.defs" {
    export const useCase: {
        readonly usecaseId: "listarPedidosCozinha";
        readonly title: "Listar pedidos para cozinha";
        readonly purpose: "Exibir fila de pedidos para preparo.";
        readonly actor: "cozinha";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["pedidoEntity"];
        readonly outputEntities: readonly ["pedidoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["pedidoEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarPedidosCozinha";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "pedidos";
                readonly type: "pedidoEntity[]";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "listarPedidosCozinha__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidosCozinha.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidosCozinha.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarSolicitacoesResumoVendas.defs" {
    export const useCase: {
        readonly usecaseId: "listarSolicitacoesResumoVendas";
        readonly title: "Listar solicitações de resumo de vendas";
        readonly purpose: "Consultar solicitações de resumo de vendas registradas.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["resumoVendasEntity"];
        readonly outputEntities: readonly ["resumoVendasEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "sales_summary_requests";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["resumoVendasEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarSolicitacoesResumoVendas";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "solicitacoes";
                readonly type: "resumoVendasEntity[]";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "listarSolicitacoesResumoVendas__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarSolicitacoesResumoVendas.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarSolicitacoesResumoVendas.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/resumoVendasEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/resumoVendasEntity" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IDataRuntime } from '_102034_/l1/server/layer_1_external/data/runtime';
    export interface ResumoVendasRecord {
        sales_summary_request_id: string;
        shift_report_id: string;
        created_at: string;
        updated_at: string;
    }
    export interface CreateResumoVendasInput {
        shiftReportId: string;
    }
    export interface ListResumoVendasFilter {
        shiftReportId?: string;
    }
    export interface IResumoVendasEntity {
        create(ctx: RequestContext, input: CreateResumoVendasInput, runtime?: IDataRuntime): Promise<ResumoVendasRecord>;
        getById(ctx: RequestContext, salesSummaryRequestId: string, runtime?: IDataRuntime): Promise<ResumoVendasRecord>;
        list(ctx: RequestContext, filter?: ListResumoVendasFilter, runtime?: IDataRuntime): Promise<ResumoVendasRecord[]>;
    }
    export const ResumoVendasEntity: IResumoVendasEntity;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarSolicitacoesResumoVendas" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type ResumoVendasRecord } from "_102043_/l1/cafeFlow/layer_4_entities/resumoVendasEntity";
    export interface ListarSolicitacoesResumoVendasInput {
    }
    export interface ListarSolicitacoesResumoVendasOutput {
        solicitacoes: ResumoVendasRecord[];
    }
    export function listarSolicitacoesResumoVendas(ctx: RequestContext, _input: ListarSolicitacoesResumoVendasInput): Promise<ListarSolicitacoesResumoVendasOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarTurnos.defs" {
    export const useCase: {
        readonly usecaseId: "listarTurnos";
        readonly title: "Listar turnos";
        readonly purpose: "Consultar turnos diários.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["turnoEntity"];
        readonly outputEntities: readonly ["turnoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "shifts";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["turnoEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarTurnos";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "turnos";
                readonly type: "turnoEntity[]";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "listarTurnos__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarTurnos.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarTurnos.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/turnoEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/obterPedido.defs" {
    export const useCase: {
        readonly usecaseId: "obterPedido";
        readonly title: "Obter pedido";
        readonly purpose: "Consultar detalhes de um pedido.";
        readonly actor: "atendente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["pedidoEntity"];
        readonly outputEntities: readonly ["pedidoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_status_history";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["pedidoEntity"];
        readonly commands: readonly [{
            readonly commandId: "obterPedido";
            readonly input: readonly [{
                readonly name: "pedidoId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "pedido";
                readonly type: "pedidoEntity";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "obterPedido__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/obterPedido.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/obterPedido.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/obterPedido" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type PedidoRecord } from "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity";
    export interface ObterPedidoInput {
        pedidoId: string;
    }
    export interface ObterPedidoOutput {
        pedido: PedidoRecord;
    }
    export function obterPedido(ctx: RequestContext, input: ObterPedidoInput): Promise<ObterPedidoOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/obterRelatorioTurno.defs" {
    export const useCase: {
        readonly usecaseId: "obterRelatorioTurno";
        readonly title: "Obter relatório de turno";
        readonly purpose: "Consultar relatório de fechamento de um turno.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["turnoEntity"];
        readonly outputEntities: readonly ["turnoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "shift_reports";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["turnoEntity"];
        readonly commands: readonly [{
            readonly commandId: "obterRelatorioTurno";
            readonly input: readonly [{
                readonly name: "turnoId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "turno";
                readonly type: "turnoEntity";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "obterRelatorioTurno__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/obterRelatorioTurno.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/obterRelatorioTurno.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/turnoEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/registrarMovimentacaoEstoque.defs" {
    export const useCase: {
        readonly usecaseId: "registrarMovimentacaoEstoque";
        readonly title: "Registrar movimentação de estoque";
        readonly purpose: "Registrar entrada ou saída de estoque e gerar alerta quando necessário.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["estoqueEntity"];
        readonly outputEntities: readonly ["estoqueEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "StockItem";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "UnitOfMeasure";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "stock_movements";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_alerts";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["lowStockThresholdRule"];
        readonly entityRefs: readonly ["estoqueEntity", "metricasEntity"];
        readonly commands: readonly [{
            readonly commandId: "registrarMovimentacaoEstoque";
            readonly input: readonly [{
                readonly name: "stockItemId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "movementType";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "quantity";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "unitOfMeasureId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "movementDate";
                readonly type: "date";
                readonly required: false;
            }, {
                readonly name: "reason";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "stockItemId";
                readonly type: "string";
            }, {
                readonly name: "quantity";
                readonly type: "number";
            }];
        }];
        readonly pendingQuestions: readonly ["Quais campos obrigatórios devem compor a movimentação (ex.: data, motivo)?", "O tipo de movimentação é um enum específico (ex.: ENTRADA/SAÍDA)? Se sim, qual o identificador do enum?", "A resposta deve incluir algum indicador/ID de alerta de estoque baixo ou apenas o estoque atualizado?"];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "registrarMovimentacaoEstoque__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/registrarMovimentacaoEstoque.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/registrarMovimentacaoEstoque.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity.d.ts", "_102043_/l1/cafeFlow/layer_4_entities/metricasEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["lowStockThresholdRule"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/solicitarResumoVendasDia.defs" {
    export const useCase: {
        readonly usecaseId: "solicitarResumoVendasDia";
        readonly title: "Solicitar resumo de vendas do dia";
        readonly purpose: "Registrar solicitação de resumo de vendas para o assistente IA.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["resumoVendasEntity"];
        readonly outputEntities: readonly ["resumoVendasEntity"];
        readonly readsTables: readonly [];
        readonly writesTables: readonly [{
            readonly tableName: "sales_summary_requests";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["salesSummaryUsesLast7Days"];
        readonly entityRefs: readonly ["resumoVendasEntity"];
        readonly commands: readonly [{
            readonly commandId: "solicitarResumoVendasDia";
            readonly input: readonly [{
                readonly name: "resumoVendas";
                readonly type: "resumoVendasEntity";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "resumoVendas";
                readonly type: "resumoVendasEntity";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "solicitarResumoVendasDia__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/solicitarResumoVendasDia.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/solicitarResumoVendasDia.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/resumoVendasEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["salesSummaryUsesLast7Days"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/solicitarResumoVendasDia" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type CreateResumoVendasInput, type ResumoVendasRecord } from "_102043_/l1/cafeFlow/layer_4_entities/resumoVendasEntity";
    export interface SolicitarResumoVendasDiaInput {
        resumoVendas: CreateResumoVendasInput;
    }
    export interface SolicitarResumoVendasDiaOutput {
        resumoVendas: ResumoVendasRecord;
    }
    export function solicitarResumoVendasDia(ctx: RequestContext, input: SolicitarResumoVendasDiaInput): Promise<SolicitarResumoVendasDiaOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity.defs" {
    export const entity: {
        readonly entityId: "cardapioEntity";
        readonly title: "Entidade de caso de uso: Cardápio";
        readonly purpose: "Gerenciar itens e categorias do cardápio.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "menuItemId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do item do cardápio.";
        }, {
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
            readonly description: "Nome do item do cardápio.";
        }, {
            readonly fieldId: "description";
            readonly type: "text";
            readonly required: false;
            readonly description: "Descrição do item do cardápio.";
        }, {
            readonly fieldId: "price";
            readonly type: "money";
            readonly required: true;
            readonly description: "Preço de venda do item do cardápio.";
        }, {
            readonly fieldId: "menuCategoryId";
            readonly type: "MenuCategory";
            readonly required: true;
            readonly description: "Categoria à qual o item do cardápio pertence.";
        }, {
            readonly fieldId: "isActive";
            readonly type: "boolean";
            readonly required: true;
            readonly description: "Indica se o item do cardápio está ativo para venda.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do item do cardápio.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do item do cardápio.";
        }];
        readonly sourceTables: readonly [{
            readonly tableName: "MenuItem";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "MenuCategory";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "MenuItem";
            readonly domainId: "menu";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["Todo item do cardápio deve estar associado a uma categoria ativa (regra menuItemRequiresCategory).", "Apenas o ator gerente pode criar, editar ou inativar itens e categorias do cardápio.", "Itens inativados não devem aparecer no POS para novos pedidos."];
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "MenuCategory";
            readonly domainId: "menu";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["Todo item do cardápio deve estar associado a uma categoria ativa (regra menuItemRequiresCategory).", "Apenas o ator gerente pode criar, editar ou inativar itens e categorias do cardápio.", "Itens inativados não devem aparecer no POS para novos pedidos."];
        }];
        readonly allowedOperations: readonly ["create", "update", "read", "list"];
        readonly rulesApplied: readonly ["menuItemRequiresCategory"];
        readonly usecaseRefs: readonly ["criarPedido", "criarOuAtualizarItemCardapio", "listarItensCardapio", "listarCategoriasCardapio"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/CardapioEntity.ts";
            readonly className: "CardapioEntity";
            readonly contractName: "ICardapioEntity";
        };
    };
    export default entity;
    export const pipeline: readonly [{
        readonly id: "cardapioEntity__layer_4_entities";
        readonly type: "layer_4_entities";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["menuItemRequiresCategory"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity.defs" {
    export const entity: {
        readonly entityId: "estoqueEntity";
        readonly title: "Entidade de caso de uso: Estoque";
        readonly purpose: "Controlar movimentações e alertas de estoque.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "stockMovementId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da movimentação de estoque.";
        }, {
            readonly fieldId: "stockItemId";
            readonly type: "StockItem";
            readonly required: true;
            readonly description: "Item de estoque associado à movimentação.";
        }, {
            readonly fieldId: "orderId";
            readonly type: "Order";
            readonly required: false;
            readonly description: "Pedido vinculado à saída de estoque, quando aplicável.";
        }, {
            readonly fieldId: "movementType";
            readonly type: "string";
            readonly required: true;
            readonly description: "Tipo de movimentação realizada.";
            readonly enum: readonly ["entrada", "saida", "ajuste"];
        }, {
            readonly fieldId: "quantity";
            readonly type: "number";
            readonly required: true;
            readonly description: "Quantidade movimentada do item de estoque.";
        }, {
            readonly fieldId: "reason";
            readonly type: "text";
            readonly required: false;
            readonly description: "Motivo ou observação da movimentação, especialmente para ajustes.";
        }, {
            readonly fieldId: "occurredAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora em que a movimentação ocorreu.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro.";
        }];
        readonly sourceTables: readonly [{
            readonly tableName: "stock_movements";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_alerts";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "StockItem";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "UnitOfMeasure";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "stockMovement";
            readonly tableName: "stock_movements";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/stockMovement.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "lowStockAlert";
            readonly tableName: "low_stock_alerts";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/lowStockAlert.defs.ts";
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "StockItem";
            readonly domainId: "stock";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["Gerar alerta quando nível de estoque ficar abaixo do mínimo definido (regra lowStockThresholdRule).", "Apenas o ator gerente pode cadastrar ou ajustar itens de estoque e unidades de medida.", "Unidades de medida não podem ser excluídas se estiverem vinculadas a itens de estoque."];
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "UnitOfMeasure";
            readonly domainId: "stock";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["Gerar alerta quando nível de estoque ficar abaixo do mínimo definido (regra lowStockThresholdRule).", "Apenas o ator gerente pode cadastrar ou ajustar itens de estoque e unidades de medida.", "Unidades de medida não podem ser excluídas se estiverem vinculadas a itens de estoque."];
        }];
        readonly allowedOperations: readonly ["create", "update", "read", "list"];
        readonly rulesApplied: readonly ["lowStockThresholdRule"];
        readonly usecaseRefs: readonly ["criarOuAtualizarItemEstoque", "listarItensEstoque", "registrarMovimentacaoEstoque", "listarMovimentacoesEstoque", "listarAlertasEstoqueBaixo"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/EstoqueEntity.ts";
            readonly className: "EstoqueEntity";
            readonly contractName: "IEstoqueEntity";
        };
    };
    export default entity;
    export const pipeline: readonly [{
        readonly id: "estoqueEntity__layer_4_entities";
        readonly type: "layer_4_entities";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_1_external/stockMovement.d.ts", "_102043_/l1/cafeFlow/layer_1_external/lowStockAlert.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["lowStockThresholdRule"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/metricasEntity.defs" {
    export const entity: {
        readonly entityId: "metricasEntity";
        readonly title: "Entidade de caso de uso: Métricas";
        readonly purpose: "Ler métricas operacionais e atualizar métricas derivadas.";
        readonly layer: "layer_4_entities";
        readonly sourceTables: readonly [{
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "metricTable";
            readonly metricTableId: "dailySalesMetrics";
            readonly tableName: "daily_sales_metrics";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/dailySalesMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "topSellingItemsMetrics";
            readonly tableName: "top_selling_items_metrics";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "lowStockMetrics";
            readonly tableName: "low_stock_metrics";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/lowStockMetrics.defs.ts";
        }];
        readonly allowedOperations: readonly ["read", "update"];
        readonly rulesApplied: readonly [];
        readonly usecaseRefs: readonly ["criarPedido", "atualizarStatusPedido", "registrarMovimentacaoEstoque", "abrirTurno", "fecharTurno", "consultarDashboardGerente"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/MetricasEntity.ts";
            readonly className: "MetricasEntity";
            readonly contractName: "IMetricasEntity";
        };
    };
    export default entity;
    export const pipeline: readonly [{
        readonly id: "metricasEntity__layer_4_entities";
        readonly type: "layer_4_entities";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_4_entities/metricasEntity.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_4_entities/metricasEntity.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_1_external/dailySalesMetrics.d.ts", "_102043_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.d.ts", "_102043_/l1/cafeFlow/layer_1_external/lowStockMetrics.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity.defs" {
    export const entity: {
        readonly entityId: "pedidoEntity";
        readonly title: "Entidade de caso de uso: Pedido";
        readonly purpose: "Gerenciar pedidos e histórico de status.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "orderId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do pedido.";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Status atual do pedido.";
            readonly enum: readonly ["recebido", "emPreparo", "pronto", "entregue", "cancelado"];
        }, {
            readonly fieldId: "shiftId";
            readonly type: "Shift";
            readonly required: true;
            readonly description: "Turno em que o pedido foi registrado.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do pedido.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do pedido.";
        }];
        readonly statusEnum: readonly ["recebido", "emPreparo", "pronto", "entregue", "cancelado"];
        readonly sourceTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_status_history";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "order";
            readonly tableName: "orders";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/order.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "orderStatusHistory";
            readonly tableName: "order_status_history";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/orderStatusHistory.defs.ts";
        }];
        readonly allowedOperations: readonly ["create", "update", "read", "list"];
        readonly rulesApplied: readonly ["orderRequiresItem", "orderStatusTransition"];
        readonly usecaseRefs: readonly ["criarPedido", "listarPedidos", "obterPedido", "listarPedidosCozinha", "atualizarStatusPedido", "fecharTurno"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/PedidoEntity.ts";
            readonly className: "PedidoEntity";
            readonly contractName: "IPedidoEntity";
        };
    };
    export default entity;
    export const pipeline: readonly [{
        readonly id: "pedidoEntity__layer_4_entities";
        readonly type: "layer_4_entities";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_1_external/order.d.ts", "_102043_/l1/cafeFlow/layer_1_external/orderStatusHistory.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["orderRequiresItem", "orderStatusTransition"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/resumoVendasEntity.defs" {
    export const entity: {
        readonly entityId: "resumoVendasEntity";
        readonly title: "Entidade de caso de uso: Resumo de vendas";
        readonly purpose: "Registrar solicitações de resumo de vendas do dia.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "salesSummaryRequestId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da solicitação de resumo de vendas.";
        }, {
            readonly fieldId: "shiftReportId";
            readonly type: "ShiftReport";
            readonly required: true;
            readonly description: "Referência à consolidação de vendas usada na solicitação.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação da solicitação.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização da solicitação.";
        }];
        readonly sourceTables: readonly [{
            readonly tableName: "sales_summary_requests";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "salesSummaryRequest";
            readonly tableName: "sales_summary_requests";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/salesSummaryRequest.defs.ts";
        }];
        readonly allowedOperations: readonly ["create", "read", "list"];
        readonly rulesApplied: readonly ["salesSummaryUsesLast7Days"];
        readonly usecaseRefs: readonly ["solicitarResumoVendasDia", "listarSolicitacoesResumoVendas"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/ResumoVendasEntity.ts";
            readonly className: "ResumoVendasEntity";
            readonly contractName: "IResumoVendasEntity";
        };
    };
    export default entity;
    export const pipeline: readonly [{
        readonly id: "resumoVendasEntity__layer_4_entities";
        readonly type: "layer_4_entities";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_4_entities/resumoVendasEntity.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_4_entities/resumoVendasEntity.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_1_external/salesSummaryRequest.d.ts", "_102043_/l1/cafeFlow/layer_1_external/shiftReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["salesSummaryUsesLast7Days"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/turnoEntity.defs" {
    export const entity: {
        readonly entityId: "turnoEntity";
        readonly title: "Entidade de caso de uso: Turno";
        readonly purpose: "Gerenciar turnos diários e relatórios de fechamento.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "shiftId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do turno.";
        }, {
            readonly fieldId: "shiftConfigId";
            readonly type: "ShiftConfig";
            readonly required: true;
            readonly description: "Configuração de turno aplicada ao período operacional.";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Status atual do turno.";
            readonly enum: readonly ["aberto", "emFechamento", "fechado"];
        }, {
            readonly fieldId: "openedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de abertura do turno.";
        }, {
            readonly fieldId: "closedAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data e hora de fechamento do turno.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro.";
        }];
        readonly statusEnum: readonly ["aberto", "emFechamento", "fechado"];
        readonly sourceTables: readonly [{
            readonly tableName: "shifts";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "shift_reports";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "ShiftConfig";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "shift";
            readonly tableName: "shifts";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/shift.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "shiftReport";
            readonly tableName: "shift_reports";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/shiftReport.defs.ts";
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "ShiftConfig";
            readonly domainId: "shiftConfig";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["Apenas o ator gerente pode alterar configurações de turno.", "Configurações de turno não podem ser removidas se houver turnos históricos vinculados."];
        }];
        readonly allowedOperations: readonly ["create", "update", "read", "list"];
        readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
        readonly usecaseRefs: readonly ["abrirTurno", "fecharTurno", "listarTurnos", "obterRelatorioTurno"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/TurnoEntity.ts";
            readonly className: "TurnoEntity";
            readonly contractName: "ITurnoEntity";
        };
    };
    export default entity;
    export const pipeline: readonly [{
        readonly id: "turnoEntity__layer_4_entities";
        readonly type: "layer_4_entities";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_4_entities/turnoEntity.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_4_entities/turnoEntity.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_1_external/shift.d.ts", "_102043_/l1/cafeFlow/layer_1_external/shiftReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 11 color families (base key = `<family>-color`). `grey` has a distinct variant shape. */
    export const MANDATORY_COLOR_FAMILIES: readonly ["text-primary", "text-secondary", "bg-primary", "bg-secondary", "grey", "error", "success", "warning", "info", "active", "link"];
    export type MandatoryColorFamily = typeof MANDATORY_COLOR_FAMILIES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102043_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102043_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102043_/l2/cafeFlow/cardapioEstoque.defs" {
    export const cardapioEstoquePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "cardapioEstoque";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 57;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "cardapioEstoque";
                readonly pageName: "Cardápio e estoque";
                readonly actor: "gerente";
                readonly purpose: "Gerenciar itens do cardápio, categorias, estoque e alertas de baixo estoque.";
                readonly capabilities: readonly ["gerenciarCardapio", "gerenciarEstoque"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["lowStockAlertWorkflow"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["menu", "stock"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "dashboardGerente";
                    readonly trigger: "Ver métricas de vendas/estoque";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Gestão de cardápio";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "FiltroEListaItensCardapio";
                        readonly purpose: "Filtrar e visualizar itens do cardápio e suas categorias.";
                        readonly userActions: readonly ["filtrarItensCardapio", "selecionarItemCardapio"];
                        readonly requiredEntities: readonly ["MenuItem", "MenuCategory"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "CadastroEdicaoItemCardapio";
                        readonly purpose: "Criar ou atualizar item do cardápio associado a uma categoria.";
                        readonly userActions: readonly ["criarItemCardapio", "editarItemCardapio"];
                        readonly requiredEntities: readonly ["MenuItem", "MenuCategory"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["menuItemRequiresCategory"];
                    }, {
                        readonly organismName: "ListaCategoriasCardapio";
                        readonly purpose: "Exibir categorias disponíveis para seleção no item do cardápio.";
                        readonly userActions: readonly ["selecionarCategoriaCardapio"];
                        readonly requiredEntities: readonly ["MenuCategory"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Gestão de estoque";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "FiltroEListaItensEstoque";
                        readonly purpose: "Filtrar e visualizar itens de estoque com quantidades.";
                        readonly userActions: readonly ["filtrarItensEstoque", "selecionarItemEstoque"];
                        readonly requiredEntities: readonly ["StockItem", "UnitOfMeasure"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "CadastroEdicaoItemEstoque";
                        readonly purpose: "Criar ou atualizar item de estoque e unidade de medida.";
                        readonly userActions: readonly ["criarItemEstoque", "editarItemEstoque"];
                        readonly requiredEntities: readonly ["StockItem", "UnitOfMeasure"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "RegistroMovimentacaoEstoque";
                        readonly purpose: "Registrar entrada, saída ou ajuste de estoque.";
                        readonly userActions: readonly ["registrarEntradaEstoque", "registrarSaidaEstoque", "registrarAjusteEstoque"];
                        readonly requiredEntities: readonly ["StockMovement", "StockItem"];
                        readonly readsFields: readonly ["stockItemId", "movementType", "quantity", "reason", "occurredAt"];
                        readonly writesFields: readonly ["stockItemId", "movementType", "quantity", "reason", "occurredAt"];
                        readonly rulesApplied: readonly ["lowStockThresholdRule"];
                    }, {
                        readonly organismName: "HistoricoMovimentacoesEstoque";
                        readonly purpose: "Exibir histórico de movimentações por item e período.";
                        readonly userActions: readonly ["filtrarMovimentacoesEstoque", "inspecionarMovimentacao"];
                        readonly requiredEntities: readonly ["StockMovement"];
                        readonly readsFields: readonly ["stockMovementId", "stockItemId", "movementType", "quantity", "reason", "occurredAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "AlertasEstoqueBaixo";
                        readonly purpose: "Visualizar alertas de estoque baixo e status.";
                        readonly userActions: readonly ["filtrarAlertasEstoqueBaixo", "verDetalheAlerta"];
                        readonly requiredEntities: readonly ["LowStockAlert"];
                        readonly readsFields: readonly ["lowStockAlertId", "stockItemId", "triggeredAt", "currentQuantity", "minimumQuantity", "status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["lowStockThresholdRule"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listarItensCardapio";
                readonly purpose: "Exibir itens do cardápio";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "categoriaId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "disponivel";
                    readonly type: "boolean";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                }, {
                    readonly name: "nome";
                    readonly type: "string";
                }, {
                    readonly name: "preco";
                    readonly type: "number";
                }, {
                    readonly name: "categoriaId";
                    readonly type: "string";
                }, {
                    readonly name: "ativo";
                    readonly type: "boolean";
                }];
                readonly readsEntities: readonly ["MenuItem", "MenuCategory"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarItensCardapio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listarCategoriasCardapio";
                readonly purpose: "Exibir categorias do cardápio para seleção";
                readonly kind: "query";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "categoriaId";
                    readonly type: "string";
                }, {
                    readonly name: "nome";
                    readonly type: "string";
                }, {
                    readonly name: "ativo";
                    readonly type: "boolean";
                }];
                readonly readsEntities: readonly ["MenuCategory"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarCategoriasCardapio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "criarOuAtualizarItemCardapio";
                readonly purpose: "Criar ou atualizar item do cardápio";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "nome";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "preco";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "categoriaId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "ativo";
                    readonly type: "boolean";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["MenuCategory"];
                readonly writesEntities: readonly ["MenuItem"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["criarOuAtualizarItemCardapio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["menuItemRequiresCategory"];
            }, {
                readonly commandName: "listarItensEstoque";
                readonly purpose: "Exibir itens de estoque com quantidades";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "categoriaId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                }, {
                    readonly name: "nome";
                    readonly type: "string";
                }, {
                    readonly name: "quantidadeAtual";
                    readonly type: "number";
                }, {
                    readonly name: "unidadeMedidaId";
                    readonly type: "string";
                }, {
                    readonly name: "quantidadeMinima";
                    readonly type: "number";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["StockItem", "UnitOfMeasure"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarItensEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "criarOuAtualizarItemEstoque";
                readonly purpose: "Criar ou atualizar item de estoque";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "nome";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "unidadeMedidaId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "quantidadeMinima";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "ativo";
                    readonly type: "boolean";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["UnitOfMeasure"];
                readonly writesEntities: readonly ["StockItem"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["criarOuAtualizarItemEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "registrarMovimentacaoEstoque";
                readonly purpose: "Registrar entrada/saída/ajuste de estoque";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "movementType";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "occurredAt";
                    readonly type: "date";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "stockMovementId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["StockItem", "UnitOfMeasure"];
                readonly writesEntities: readonly ["StockMovement", "LowStockAlert"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["stock_movements", "low_stock_alerts", "low_stock_metrics"];
                readonly usecaseRefs: readonly ["registrarMovimentacaoEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["lowStockThresholdRule"];
            }, {
                readonly commandName: "listarMovimentacoesEstoque";
                readonly purpose: "Exibir histórico de movimentações";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "dataInicio";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "dataFim";
                    readonly type: "date";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "stockMovementId";
                    readonly type: "string";
                }, {
                    readonly name: "stockItemId";
                    readonly type: "string";
                }, {
                    readonly name: "movementType";
                    readonly type: "string";
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                }, {
                    readonly name: "occurredAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["StockMovement"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["stock_movements"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarMovimentacoesEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listarAlertasEstoqueBaixo";
                readonly purpose: "Exibir alertas de estoque baixo";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "lowStockAlertId";
                    readonly type: "string";
                }, {
                    readonly name: "stockItemId";
                    readonly type: "string";
                }, {
                    readonly name: "triggeredAt";
                    readonly type: "date";
                }, {
                    readonly name: "currentQuantity";
                    readonly type: "number";
                }, {
                    readonly name: "minimumQuantity";
                    readonly type: "number";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["LowStockAlert"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["low_stock_alerts"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarAlertasEstoqueBaixo"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["lowStockThresholdRule"];
            }];
        };
    };
    export default cardapioEstoquePagePlan;
}
declare module "_102043_/l2/cafeFlow/dashboardGerente.defs" {
    export const dashboardGerentePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "dashboardGerente";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 59;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "dashboardGerente";
                readonly pageName: "Dashboard do gerente";
                readonly actor: "gerente";
                readonly purpose: "Acompanhar métricas operacionais e de vendas do dia.";
                readonly capabilities: readonly ["consultarDashboard"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "periodoInicio";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Data inicial do período para filtros do dashboard.";
                }, {
                    readonly name: "periodoFim";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Data final do período para filtros do dashboard.";
                }, {
                    readonly name: "turnoId";
                    readonly type: "turnoId";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Turno selecionado para filtrar métricas.";
                    readonly entityRef: "turnoEntity";
                    readonly fieldRef: "turnoId";
                }, {
                    readonly name: "statusAlerta";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Status do alerta de estoque baixo para filtragem.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "cardapioEstoque";
                    readonly trigger: "Acessar métricas a partir do cardápio/estoque";
                }, {
                    readonly direction: "inbound";
                    readonly pageId: "fechamentoTurno";
                    readonly trigger: "Acessar métricas após fechamento";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "VisaoGeralDoDia";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "ResumoVendasDiarias";
                        readonly purpose: "Exibir receita total, quantidade de pedidos e ticket médio do período.";
                        readonly userActions: readonly ["viewDashboard"];
                        readonly requiredEntities: readonly ["metricasEntity"];
                        readonly readsFields: readonly ["metricasEntity.totalRevenue", "metricasEntity.orderCount", "metricasEntity.averageTicket", "metricasEntity.itemsSold"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "GraficoVendasPorTurno";
                        readonly purpose: "Exibir evolução de vendas por turno no período selecionado.";
                        readonly userActions: readonly ["viewDashboard"];
                        readonly requiredEntities: readonly ["metricasEntity"];
                        readonly readsFields: readonly ["metricasEntity.totalRevenue", "metricasEntity.orderCount", "metricasEntity.shiftId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "ItensMaisVendidos";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "RankingItensMaisVendidos";
                        readonly purpose: "Listar itens mais vendidos e receita gerada.";
                        readonly userActions: readonly ["viewDashboard"];
                        readonly requiredEntities: readonly ["metricasEntity"];
                        readonly readsFields: readonly ["metricasEntity.menuItemId", "metricasEntity.menuCategoryId", "metricasEntity.quantitySold", "metricasEntity.itemRevenue", "metricasEntity.orderCount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "AlertasDeEstoqueBaixo";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "ListaAlertasEstoqueBaixo";
                        readonly purpose: "Exibir alertas ativos de estoque baixo.";
                        readonly userActions: readonly ["viewDashboard"];
                        readonly requiredEntities: readonly ["estoqueEntity"];
                        readonly readsFields: readonly ["estoqueEntity.stockItemId", "estoqueEntity.currentQuantity", "estoqueEntity.thresholdValue", "estoqueEntity.alertCount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "consultarDashboardGerente";
                readonly purpose: "Carregar métricas e visão geral do dia.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "periodoInicio";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "periodoFim";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "turnoId";
                    readonly type: "turnoId";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "totalRevenue";
                    readonly type: "number";
                }, {
                    readonly name: "orderCount";
                    readonly type: "number";
                }, {
                    readonly name: "averageTicket";
                    readonly type: "number";
                }, {
                    readonly name: "itemsSold";
                    readonly type: "number";
                }, {
                    readonly name: "serieVendasPorTurno";
                    readonly type: "metricasEntityId";
                }, {
                    readonly name: "rankingItensMaisVendidos";
                    readonly type: "metricasEntityId";
                }];
                readonly readsEntities: readonly ["metricasEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["consultarDashboardGerente"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listarAlertasEstoqueBaixo";
                readonly purpose: "Exibir alertas de estoque baixo no painel.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "statusAlerta";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "alertas";
                    readonly type: "estoqueEntityId";
                }];
                readonly readsEntities: readonly ["estoqueEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarAlertasEstoqueBaixo"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default dashboardGerentePagePlan;
}
declare module "_102043_/l2/cafeFlow/fechamentoTurno.defs" {
    export const fechamentoTurnoPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "fechamentoTurno";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 58;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "fechamentoTurno";
                readonly pageName: "Fechamento de turno";
                readonly actor: "gerente";
                readonly purpose: "Validar pedidos do turno e confirmar o fechamento com geração de relatório.";
                readonly capabilities: readonly ["fecharTurno"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["shiftClosureWorkflow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["shiftConfig"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "dashboardGerente";
                    readonly trigger: "Ver resumo do turno";
                    readonly description: "Após confirmar o fechamento e revisar o relatório.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Seleção de turno";
                    readonly mode: "selection";
                    readonly organisms: readonly [{
                        readonly organismName: "Seletor de turno";
                        readonly purpose: "Selecionar o turno a fechar e visualizar seu status.";
                        readonly userActions: readonly ["selecionarTurno"];
                        readonly requiredEntities: readonly ["Shift"];
                        readonly readsFields: readonly ["Shift.shiftId", "Shift.status", "Shift.openedAt", "Shift.closedAt", "Shift.shiftConfigId"];
                        readonly writesFields: readonly ["Shift.shiftId"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Validação de pedidos do turno";
                    readonly mode: "review";
                    readonly organisms: readonly [{
                        readonly organismName: "Lista de pedidos do turno";
                        readonly purpose: "Validar se todos os pedidos do turno estão finalizados.";
                        readonly userActions: readonly ["filtrarPedidos", "revisarStatus"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.orderId", "Order.status", "Order.shiftId", "Order.createdAt", "Order.updatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
                    }];
                }, {
                    readonly sectionName: "Relatório do turno";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "Resumo de fechamento";
                        readonly purpose: "Exibir o relatório consolidado do turno selecionado.";
                        readonly userActions: readonly ["visualizarRelatorio"];
                        readonly requiredEntities: readonly ["ShiftReport"];
                        readonly readsFields: readonly ["ShiftReport.shiftReportId", "ShiftReport.shiftId", "ShiftReport.totalSalesAmount", "ShiftReport.totalOrders", "ShiftReport.totalItems", "ShiftReport.notes", "ShiftReport.createdAt", "ShiftReport.updatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Confirmação de fechamento";
                    readonly mode: "action";
                    readonly organisms: readonly [{
                        readonly organismName: "Confirmar fechamento";
                        readonly purpose: "Confirmar o fechamento do turno e gerar o relatório.";
                        readonly userActions: readonly ["confirmarFechamento"];
                        readonly requiredEntities: readonly ["Shift", "ShiftReport", "Order"];
                        readonly readsFields: readonly ["Shift.shiftId", "Shift.status"];
                        readonly writesFields: readonly ["Shift.status", "Shift.closedAt", "ShiftReport.shiftReportId"];
                        readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listarTurnos";
                readonly purpose: "Carregar turnos para seleção.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "dataInicio";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "dataFim";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "Shift";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "openedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "closedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "shiftConfigId";
                    readonly type: "ShiftConfig";
                }];
                readonly readsEntities: readonly ["Shift"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["shifts"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarTurnos"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listarPedidos";
                readonly purpose: "Listar pedidos do turno para validação.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "Shift";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "shiftId";
                    readonly type: "Shift";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["orders", "order_status_history"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarPedidos"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "fecharTurno";
                readonly purpose: "Confirmar fechamento do turno e gerar relatório.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "Shift";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "Shift";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "closedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "shiftReportId";
                    readonly type: "ShiftReport";
                }];
                readonly readsEntities: readonly ["Shift", "Order"];
                readonly writesEntities: readonly ["Shift", "ShiftReport"];
                readonly readsTables: readonly ["shifts", "orders"];
                readonly writesTables: readonly ["shifts", "shift_reports", "daily_sales_metrics"];
                readonly usecaseRefs: readonly ["fecharTurno"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
            }, {
                readonly commandName: "obterRelatorioTurno";
                readonly purpose: "Exibir relatório do turno selecionado.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "Shift";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "shiftReportId";
                    readonly type: "ShiftReport";
                }, {
                    readonly name: "shiftId";
                    readonly type: "Shift";
                }, {
                    readonly name: "totalSalesAmount";
                    readonly type: "money";
                }, {
                    readonly name: "totalOrders";
                    readonly type: "number";
                }, {
                    readonly name: "totalItems";
                    readonly type: "number";
                }, {
                    readonly name: "notes";
                    readonly type: "text";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["ShiftReport"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["shift_reports"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["obterRelatorioTurno"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default fechamentoTurnoPagePlan;
}
declare module "_102029_/l2/runtimeConfigTypes" {
    export type ProjectType = 'master frontend' | 'master backend' | 'client' | 'lib';
    export interface ProjectModuleFrontendEntrypoint {
        entrypoint: string;
        componentTag: string;
    }
    export interface ProjectFrontendPageConfig {
        pageId: string;
        route: string;
        source: string;
        definition?: string;
        componentTag: string;
        title?: string;
    }
    export interface ProjectModuleFrontendConfig {
        layer?: 'l2' | string;
        moduleEntrypoint?: string;
        moduleSource?: string;
        pages?: ProjectFrontendPageConfig[];
        pageTests?: string[];
    }
    export interface ProjectPersistenceModuleConfig {
        moduleId: string;
        persistenceEntrypoint?: string;
        tableDefsDir?: string;
    }
    export interface ProjectRegionRendererConfig {
        entrypoint: string;
        tag: string;
        source?: string;
    }
    export interface ProjectDynamicRegionConfig {
        renderer: ProjectRegionRendererConfig;
        widthPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface ProjectShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, ProjectDynamicRegionConfig>;
    }
    export interface ProjectClientShellConfig {
        mode: 'spa' | 'pwa';
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: ProjectShellRegionProfiles;
            aside?: ProjectShellRegionProfiles;
        };
    }
    export interface ProjectNavigationEntry {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface ProjectModuleConfig {
        moduleId: string;
        basePath: string;
        shellMode: 'spa' | 'pwa';
        navigation?: ProjectNavigationEntry[];
        frontendEntrypoints?: {
            desktop?: ProjectModuleFrontendEntrypoint;
            mobile?: ProjectModuleFrontendEntrypoint;
        };
        frontend?: ProjectModuleFrontendConfig;
        backendRouter?: string;
        backendControllers?: string;
        backend?: Record<string, unknown>;
    }
    export interface ProjectConfigRecord {
        root: string;
        type?: ProjectType;
        role?: string;
        runtime?: ProjectRuntimeMetadata;
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    export interface ProjectRuntimeMetadata {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
    }
    export interface PublicationTargetConfig {
        assetBaseUrl?: string;
        serveStaticFromServer?: boolean;
        minify?: boolean;
        sourcemap?: boolean;
    }
    export interface PublicationConfig {
        defaultTarget: string;
        targets: Record<string, PublicationTargetConfig>;
    }
    export interface ProjectsConfig {
        defaultProjectId: string;
        shellTemplates: {
            spa: string;
            pwa: string;
        };
        publication: PublicationConfig;
        clientShell?: ProjectClientShellConfig;
        projects: Record<string, ProjectConfigRecord>;
    }
    /** System modules a production master ships with (e.g. 102034: mdm, monitor, audit).
     *  The publish composer merges this into projects[<runtimeProject>] of the composed
     *  config.json — the master stays self-describing and agnostic to clients. */
    export interface MasterRuntimeManifest {
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    /** Signature written by a change agent: who generated this side of the project. */
    export interface L5MasterSignature {
        /** Studio (dev) project that hosts the agent, e.g. 102020 / 102021. */
        masterProject: number;
        /** Agent folder inside <masterProject>/l2; the publish resolves the composer at
         *  mls-<masterProject>/l2/<agentFolder>/nodejsSaveConfigJson.ts */
        agentFolder: string;
        /** Production master referenced in the composed config.json, e.g. 102033 / 102034. */
        runtimeProject: number;
    }
    export interface L5Masters {
        frontend?: L5MasterSignature;
        backend?: L5MasterSignature;
    }
    export interface L5ModuleBackendConfig {
        backendControllers: string;
        persistence: {
            tableDefsDir: string;
        };
        routeKeys: string[];
    }
    export interface L5Module {
        moduleName: string;
        backend?: L5ModuleBackendConfig;
    }
    export interface L5Dependency {
        projectId: string;
        kind?: string;
    }
    export interface L5Language {
        language: string;
        name?: string;
        path?: string;
    }
    export interface L5Layout {
        name?: string;
        [key: string]: unknown;
    }
    /** Manual customization carried by the client project; composers translate these
     *  fields into the generated config.json instead of hand-editing it (the composed
     *  file is overwritten on every publish). */
    export interface L5RuntimeCustomize {
        clientShell?: ProjectClientShellConfig;
        publication?: PublicationConfig;
        shellTemplates?: {
            spa: string;
            pwa: string;
        };
        navigationLabels?: Record<string, string>;
    }
    export interface L5ProjectJson {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
        orgName?: string;
        designSystems?: Array<Record<string, unknown>>;
        languages?: L5Language[];
        layouts?: Record<string, L5Layout>;
        plugins?: Record<string, unknown>;
        reasons?: Record<string, unknown>;
        services?: unknown[];
        links?: unknown[];
        servicesConfigEnabled?: boolean;
        masters?: L5Masters;
        modules?: L5Module[];
        dependencies?: L5Dependency[];
        customize?: L5RuntimeCustomize;
    }
    export type L4ContextSource = 'userInput' | 'actorSession' | 'businessContext' | 'currentWorkspace' | 'selectedEntity' | 'activeLifecycleInstance' | 'workflowState' | 'routeParam' | 'previousStepOutput' | 'systemDefault';
    export const L4_CONTEXT_ORIGIN_CATALOG: {
        readonly actorSession: readonly ["actorSession.actorId", "actorSession.scope"];
        readonly businessContext: readonly ["businessContext.activeCompanyId", "businessContext.activeUnitId"];
        readonly currentWorkspace: readonly ["currentWorkspace.workspaceId"];
        readonly systemDefault: readonly ["systemDefault.now", "systemDefault.uuid", "systemDefault.locale"];
    };
    export interface L4ContextResolution {
        inputId?: string;
        /** Entity.field, input.<inputId>, filter.<name>, or a catalogued runtime context attribute. */
        targetRef: string;
        source: L4ContextSource;
        originRef: string;
        description: string;
    }
    export type L5GenerationTodoLayer = 'frontend' | 'backend';
    export type L5GenerationTodoStatus = 'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done';
    export type L5GenerationTodoOwnerType = 'workflow' | 'operation';
    export interface L5GenerationTodoOwner {
        ownerType: L5GenerationTodoOwnerType;
        ownerId: string;
        title: string;
        status: L5GenerationTodoStatus;
        defPath: string;
        pageId?: string;
        commandName?: string;
        bffName?: string;
        capabilityId?: string;
    }
    export interface L5GenerationTodo {
        schemaVersion: string;
        moduleName: string;
        layer: L5GenerationTodoLayer;
        updatedAt: string;
        owners: L5GenerationTodoOwner[];
    }
}
declare module "_102029_/l2/contracts/bootstrap" {
    import type { ProjectNavigationEntry } from "_102029_/l2/runtimeConfigTypes";
    export type MasterFrontendShellMode = 'spa' | 'pwa';
    export type MasterFrontendDeviceKind = 'desktop' | 'mobile';
    export type MasterFrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export type Platform = "web" | "mobile";
    export type ISkillConfig = "layer1" | "layer2" | "layer3" | "layer4" | "contract" | "architecture" | "definition";
    export type PathConfig = {
        sharedPath: string;
        sharedSkill: string;
    };
    export type ISkill = Partial<Record<ISkillConfig, {
        skillPath: string[];
    }>>;
    export type IPaths = Partial<Record<Platform, PathConfig>>;
    export interface IGenomeConfig {
        device: MasterFrontendDeviceKind;
        designSystem: string;
        layout: string;
    }
    export interface MasterFrontendRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export type MasterFrontendRegionName = 'header' | 'aside' | 'content';
    export interface MasterFrontendLayoutConfig {
        regions: {
            desktop: MasterFrontendRegionVisibility;
            mobile: MasterFrontendRegionVisibility;
        };
        asideMode: {
            desktop: MasterFrontendAsideMode;
            mobile: MasterFrontendAsideMode;
        };
        asideSize?: {
            desktopWidthPx?: number;
            drawerWidthPx?: number;
        };
    }
    export interface MasterFrontendRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export interface MasterFrontendDynamicRegionConfig {
        renderer: MasterFrontendRegionRendererConfig;
        widthPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface MasterFrontendShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, MasterFrontendDynamicRegionConfig>;
    }
    export interface MasterFrontendClientShellConfig {
        mode: MasterFrontendShellMode;
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: MasterFrontendShellRegionProfiles;
            aside?: MasterFrontendShellRegionProfiles;
        };
    }
    export type MasterFrontendRouteMatchMode = 'exact' | 'prefix';
    export interface MasterFrontendRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: MasterFrontendRouteMatchMode;
    }
    export interface MasterFrontendModuleFrontendDefinition {
        pageTitle?: string;
        device?: MasterFrontendDeviceKind;
        navigation?: ProjectNavigationEntry[];
        routes: MasterFrontendRouteDefinition[];
        headerRenderer?: MasterFrontendRegionRendererConfig;
        asideRenderer?: MasterFrontendRegionRendererConfig;
    }
    export interface MasterFrontendModuleShellPreferences {
        layout?: Partial<MasterFrontendLayoutConfig>;
    }
    export interface MasterFrontendBootConfig {
        projectId: string;
        moduleId: string;
        basePath: string;
        shellMode: MasterFrontendShellMode;
        device: MasterFrontendDeviceKind;
        routes: MasterFrontendRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: ProjectNavigationEntry[];
        moduleLinks?: ProjectNavigationEntry[];
        layout: MasterFrontendLayoutConfig;
        clientShell?: MasterFrontendClientShellConfig;
    }
    export type MasterFrontendInteractionMode = 'blocking' | 'silent';
    export type MasterFrontendBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface MasterFrontendNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface MasterFrontendBlockingErrorState {
        title: string;
        error: MasterFrontendNormalizedError;
        canRetry: boolean;
    }
    export interface MasterFrontendInteractionState {
        busy: boolean;
        busyPhase: MasterFrontendBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: MasterFrontendBlockingErrorState;
    }
    global {
        interface Window {
            collabMasterFrontendShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
                setHeaderRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setAsideRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setShellProfile: (profileName: string) => Promise<void>;
            };
        }
        interface Window {
            collabBoot?: MasterFrontendBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabMasterFrontendInteractionState?: MasterFrontendInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
declare module "_102043_/l2/cafeFlow/module" {
    import type { AuraModuleFrontendDefinition, IPaths, ISkill, IGenomeConfig } from "_102029_/l2/contracts/bootstrap";
    export const moduleGenome: Record<string, IGenomeConfig>;
    export const shared: IPaths;
    export const skills: ISkill;
    export const moduleStates: {};
    export const moduleShellPreferences: {
        readonly layout: {
            readonly asideMode: {
                readonly desktop: "inline";
                readonly mobile: "fullscreen";
            };
        };
    };
    export const moduleFrontendDefinition: AuraModuleFrontendDefinition;
}
declare module "_102043_/l2/cafeFlow/painelCozinha.defs" {
    export const painelCozinhaPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "painelCozinha";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 56;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "painelCozinha";
                readonly pageName: "Painel da cozinha";
                readonly actor: "cozinha";
                readonly purpose: "Visualizar a fila de pedidos e atualizar status de preparo e entrega.";
                readonly capabilities: readonly ["atualizarStatusCozinha"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderStatusWorkflow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "posRapido";
                    readonly trigger: "Pedidos enviados para preparo";
                    readonly description: "Pedidos confirmados no POS entram na fila da cozinha.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Fila de pedidos";
                    readonly mode: "list";
                    readonly organisms: readonly [{
                        readonly organismName: "ListaDePedidosCozinha";
                        readonly purpose: "Exibir pedidos recebidos para preparo com status atual e horário.";
                        readonly userActions: readonly ["selecionarPedido", "iniciarPreparo", "finalizarPreparo", "cancelarPedido"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.orderId", "Order.status", "Order.createdAt", "Order.shiftId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["orderStatusTransition"];
                    }];
                }, {
                    readonly sectionName: "Detalhe e atualização de status";
                    readonly mode: "detail";
                    readonly organisms: readonly [{
                        readonly organismName: "AtualizarStatusPedido";
                        readonly purpose: "Atualizar status do pedido selecionado conforme o fluxo de preparo.";
                        readonly userActions: readonly ["iniciarPreparo", "finalizarPreparo", "cancelarPedido"];
                        readonly requiredEntities: readonly ["Order", "OrderStatusHistory"];
                        readonly readsFields: readonly ["Order.orderId", "Order.status", "Order.updatedAt"];
                        readonly writesFields: readonly ["Order.status", "Order.updatedAt", "OrderStatusHistory.fromStatus", "OrderStatusHistory.toStatus", "OrderStatusHistory.changedAt", "OrderStatusHistory.changedBy"];
                        readonly rulesApplied: readonly ["orderStatusTransition"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listarPedidosCozinha";
                readonly purpose: "Carregar pedidos recebidos para a fila da cozinha.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "shiftId";
                    readonly type: "Shift";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "createdAt";
                    readonly type: "date";
                }, {
                    readonly name: "shiftId";
                    readonly type: "Shift";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["orders"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarPedidosCozinha"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "atualizarStatusPedido";
                readonly purpose: "Atualizar status do pedido conforme preparo e entrega.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                    readonly required: true;
                }, {
                    readonly name: "novoStatus";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly ["Order", "OrderStatusHistory"];
                readonly readsTables: readonly ["orders"];
                readonly writesTables: readonly ["orders", "order_status_history", "daily_sales_metrics", "top_selling_items_metrics"];
                readonly usecaseRefs: readonly ["atualizarStatusPedido"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["orderStatusTransition"];
            }];
        };
    };
    export default painelCozinhaPagePlan;
}
declare module "_102043_/l2/cafeFlow/posRapido.defs" {
    export const posRapidoPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "posRapido";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 55;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "posRapido";
                readonly pageName: "POS rápido";
                readonly actor: "atendente";
                readonly purpose: "Registrar pedidos rapidamente no POS, revisar itens e confirmar envio para a cozinha.";
                readonly capabilities: readonly ["registrarPedido"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly ["posOrderCaptureWorkflow"];
                    readonly entityLifecycles: readonly ["orderStatusWorkflow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "painelCozinha";
                    readonly trigger: "Pedido enviado para a cozinha";
                    readonly description: "Após confirmação e envio do pedido para preparo.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Pedidos do dia";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "Lista de pedidos do dia";
                        readonly purpose: "Consultar rapidamente pedidos recentes e seus status atuais.";
                        readonly userActions: readonly ["filtrarPorStatus", "filtrarPorPeriodo", "visualizarResumo"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["orderId", "status", "createdAt", "updatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Captura rápida";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "Editor rápido de itens";
                        readonly purpose: "Adicionar e ajustar itens do pedido e observações antes da confirmação.";
                        readonly userActions: readonly ["adicionarItem", "alterarQuantidade", "removerItem", "adicionarObservacao"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Revisão e envio";
                    readonly mode: "confirm";
                    readonly organisms: readonly [{
                        readonly organismName: "Resumo e envio para cozinha";
                        readonly purpose: "Revisar o pedido e confirmar o envio para preparo.";
                        readonly userActions: readonly ["confirmarEEnviar", "voltarParaEditar"];
                        readonly requiredEntities: readonly ["Order", "OrderStatusHistory"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["orderRequiresItem", "orderStatusTransition"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listarPedidos";
                readonly purpose: "Listar pedidos do dia para consulta rápida no POS.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "dateFrom";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "dateTo";
                    readonly type: "date";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "createdAt";
                    readonly type: "date";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["orders", "order_status_history"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarPedidos"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "criarPedido";
                readonly purpose: "Criar um pedido com itens e enviar para a cozinha com status recebido.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "orderItems";
                    readonly type: "OrderItem[]";
                    readonly required: true;
                }, {
                    readonly name: "observacao";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "createdAt";
                    readonly type: "date";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["cardapioEntity"];
                readonly writesEntities: readonly ["Order", "OrderStatusHistory"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["orders", "order_status_history", "daily_sales_metrics", "top_selling_items_metrics"];
                readonly usecaseRefs: readonly ["criarPedido"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["orderRequiresItem"];
            }];
        };
    };
    export default posRapidoPagePlan;
}
declare module "_102043_/l2/cafeFlow/plugins/llmSalesAssistant.defs" {
    export const llmSalesAssistantPluginConnectionPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginConnection";
        readonly artifactId: "llmSalesAssistant";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 16;
            readonly planId: "plan-plugins";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "llmSalesAssistant";
                readonly provider: "Llm Sales Assistant";
                readonly priority: "soon";
                readonly reason: "Necessário para executar o assistente IA de vendas previsto para a fase soon.";
                readonly events: readonly [];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly ["Resumo diário de vendas", "Itens mais vendidos (últimos 7 dias)", "Dados de estoque e promoções ativas (se aplicável)"];
                readonly outputData: readonly ["Resumo de vendas", "Sugestões de promoção", "Insights de desempenho"];
                readonly webhooks: readonly [];
                readonly risks: readonly ["Dependência de decisão do cliente sobre uso de IA e proxy de LLM."];
                readonly questions: readonly ["Qual provedor/endpoint do proxy de LLM deve ser usado e quais limites de uso estão previstos?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102043_/l2/plugins/llmSalesAssistant/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102043_/l2/cafeFlow/plugins/llmSalesAssistant.defs.ts";
            };
        };
    };
    export default llmSalesAssistantPluginConnectionPlan;
}
declare module "_102043_/l2/cafeFlow/web/contracts/cardapioEstoque.defs" {
    export const definition: ({
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: string[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    } | {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: string[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    })[];
    export const pipeline: readonly [{
        readonly id: "cardapioEstoque__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102043_/l2/cafeFlow/web/contracts/cardapioEstoque.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/contracts/cardapioEstoque.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/contracts/dashboardGerente.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: any[];
    }[];
    export const pipeline: readonly [{
        readonly id: "dashboardGerente__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102043_/l2/cafeFlow/web/contracts/dashboardGerente.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/contracts/dashboardGerente.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/contracts/fechamentoTurno.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: string[];
        writesTables: string[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "fechamentoTurno__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102043_/l2/cafeFlow/web/contracts/fechamentoTurno.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/contracts/fechamentoTurno.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/contracts/painelCozinha.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: string[];
        writesTables: string[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "painelCozinha__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102043_/l2/cafeFlow/web/contracts/painelCozinha.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/contracts/painelCozinha.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/contracts/posRapido.defs" {
    export const definition: ({
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: string[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: any[];
    } | {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: string[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    })[];
    export const pipeline: readonly [{
        readonly id: "posRapido__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102043_/l2/cafeFlow/web/contracts/posRapido.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/contracts/posRapido.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/desktop/page11/cardapioEstoque.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: string[];
        };
        pluginRefs: any[];
        mdmRefs: string[];
        pageInputs: any[];
        navigationRefs: {
            direction: string;
            pageId: string;
            trigger: string;
        }[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "cardapioEstoque__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102043_/l2/cafeFlow/web/desktop/page11/cardapioEstoque.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/desktop/page11/cardapioEstoque.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l2/cafeFlow/web/shared/cardapioEstoque.ts", "_102043_/l2/cafeFlow/web/contracts/cardapioEstoque.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly tone: "Moderno e minimalista";
            readonly layout: "Interface rápida com foco em POS e painéis operacionais";
            readonly palette: readonly ["#C85A2A", "#F2C57C", "#F6F1EB", "#3B2F2F", "#2E7D32"];
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/telemetry" {
    export interface ClientTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    class TelemetryQueue {
        private queue;
        private userId;
        private errorCounts;
        private errorEventsPushed;
        constructor();
        /**
         * Error-specific push: dedupes repeats (same message/source) bumping a
         * repeatCount instead of flooding, skips browser-extension noise, caps the
         * session volume, and never throws (an error handler must not error).
         */
        private pushError;
        private errorFlushTimer;
        /** Coalesce error bursts: wait 1s before the beacon so repeats dedupe into the queued event. */
        private scheduleErrorFlush;
        setUserId(id: string): void;
        push(event: ClientTelemetryEvent): void;
        flush(): ClientTelemetryEvent[];
        measureAsync<T>(label: string, fn: () => Promise<T>): Promise<T>;
        private sendBeacon;
    }
    export const telemetryQueue: TelemetryQueue;
}
declare module "_102029_/l2/bffClient" {
    import type { MasterFrontendInteractionMode, MasterFrontendNormalizedError } from "_102029_/l2/contracts/bootstrap";
    import { type ClientTelemetryEvent } from "_102029_/l2/telemetry";
    export type { ClientTelemetryEvent };
    export interface BffClientOptions {
        mode?: MasterFrontendInteractionMode;
        timeoutMs?: number;
        signal?: AbortSignal;
    }
    export interface BffClientResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: MasterFrontendNormalizedError | null;
        telemetryReceived?: number;
    }
    export interface BffClientRequest {
        routine: string;
        params: unknown;
        meta: {
            source: 'http' | 'test';
            userId: string;
            telemetry: ClientTelemetryEvent[];
        };
    }
    export type BffDirectResult<TData = unknown> = BffClientResponse<TData> | {
        response: BffClientResponse<TData>;
        statusCode?: number;
    };
    export interface BffDirectTransport {
        execBff<TData = unknown>(request: BffClientRequest, options?: BffClientOptions): Promise<BffDirectResult<TData>>;
    }
    global {
        interface Window {
            collabBffTransport?: BffDirectTransport;
            collabBffTransportModule?: string;
        }
    }
    export function setUserId(id: string): void;
    export function pushTelemetry(event: ClientTelemetryEvent): void;
    export function execBff<TData = unknown>(routine: string, params: unknown, options?: BffClientOptions): Promise<BffClientResponse<TData>>;
}
declare module "_102029_/l2/interactionRuntime" {
    import type { MasterFrontendInteractionMode, MasterFrontendInteractionState, MasterFrontendNormalizedError } from "_102029_/l2/contracts/bootstrap";
    type InteractionListener = (state: MasterFrontendInteractionState) => void;
    interface BlockingActionOptions {
        mode?: MasterFrontendInteractionMode;
        timeoutMs?: number;
        clearContentWhileBusy?: boolean;
        busyLabel?: string;
        retry?: () => Promise<unknown> | unknown;
        errorTitle?: string;
    }
    interface PendingNavigationLoad {
        consumed: boolean;
        promise: Promise<void>;
        resolve: () => void;
        reject: (error: unknown) => void;
        signal?: AbortSignal;
    }
    export function getInteractionState(): MasterFrontendInteractionState;
    export function subscribeToInteractionState(listener: InteractionListener): () => void;
    export function clearBlockingError(): void;
    export function normalizeInteractionError(error: unknown): MasterFrontendNormalizedError;
    export function retryBlockingError(): Promise<void>;
    export function beginExpectedNavigationLoad(signal?: AbortSignal): Promise<void>;
    export function consumeExpectedNavigationLoad(): PendingNavigationLoad;
    export function bindExpectedNavigationLoad(pending: PendingNavigationLoad | null, promise: Promise<unknown>): void;
    export function runBlockingUiAction<T>(action: (signal: AbortSignal) => Promise<T>, options?: BlockingActionOptions): Promise<T | undefined>;
}
declare module "_102043_/l2/cafeFlow/web/shared/cardapioEstoque" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { CardapioEstoqueListarItensCardapioInput, CardapioEstoqueListarItensCardapioOutputItem, CardapioEstoqueListarCategoriasCardapioInput, CardapioEstoqueListarCategoriasCardapioOutputItem, CardapioEstoqueCriarOuAtualizarItemCardapioInput, CardapioEstoqueListarItensEstoqueInput, CardapioEstoqueListarItensEstoqueOutputItem, CardapioEstoqueCriarOuAtualizarItemEstoqueInput, CardapioEstoqueRegistrarMovimentacaoEstoqueInput, CardapioEstoqueListarMovimentacoesEstoqueInput, CardapioEstoqueListarMovimentacoesEstoqueOutputItem, CardapioEstoqueListarAlertasEstoqueBaixoInput, CardapioEstoqueListarAlertasEstoqueBaixoOutputItem } from "_102043_/l2/cafeFlow/web/contracts/cardapioEstoque";
    const message_en: {
        brand: string;
        pageTitle: string;
        loaded: string;
        couldNotLoad: string;
        loadingListarItensCardapio: string;
        loadingListarCategoriasCardapio: string;
        loadingListarItensEstoque: string;
        loadingListarMovimentacoesEstoque: string;
        loadingListarAlertasEstoqueBaixo: string;
        criarOuAtualizarItemCardapioLabel: string;
        criarOuAtualizarItemCardapioLoading: string;
        couldNotCriarOuAtualizarItemCardapio: string;
        criarOuAtualizarItemEstoqueLabel: string;
        criarOuAtualizarItemEstoqueLoading: string;
        couldNotCriarOuAtualizarItemEstoque: string;
        registrarMovimentacaoEstoqueLabel: string;
        registrarMovimentacaoEstoqueLoading: string;
        couldNotRegistrarMovimentacaoEstoque: string;
        navigateToDashboardGerente: string;
    };
    type MessageType = typeof message_en;
    export class CardapioEstoqueBase extends CollabLitElement {
        private readonly _stateKeys;
        itensCardapio: CardapioEstoqueListarItensCardapioOutputItem[];
        categoriasCardapio: CardapioEstoqueListarCategoriasCardapioOutputItem[];
        itensEstoque: CardapioEstoqueListarItensEstoqueOutputItem[];
        movimentacoesEstoque: CardapioEstoqueListarMovimentacoesEstoqueOutputItem[];
        alertasEstoqueBaixo: CardapioEstoqueListarAlertasEstoqueBaixoOutputItem[];
        criarOuAtualizarItemCardapioState: 'idle' | 'loading' | 'success' | 'error';
        criarOuAtualizarItemEstoqueState: 'idle' | 'loading' | 'success' | 'error';
        registrarMovimentacaoEstoqueState: 'idle' | 'loading' | 'success' | 'error';
        status: string;
        menuItemId: string | undefined;
        nome: string;
        preco: number;
        categoriaId: string;
        ativo: boolean;
        stockItemId: string | undefined;
        unidadeMedidaId: string;
        quantidadeMinima: number;
        movementType: string;
        quantity: number;
        reason: string | undefined;
        occurredAt: string;
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(params?: unknown, options?: BffClientOptions): Promise<void>;
        loadListarItensCardapio(params?: CardapioEstoqueListarItensCardapioInput, options?: BffClientOptions): Promise<void>;
        loadListarCategoriasCardapio(params?: CardapioEstoqueListarCategoriasCardapioInput, options?: BffClientOptions): Promise<void>;
        loadListarItensEstoque(params?: CardapioEstoqueListarItensEstoqueInput, options?: BffClientOptions): Promise<void>;
        loadListarMovimentacoesEstoque(params?: CardapioEstoqueListarMovimentacoesEstoqueInput, options?: BffClientOptions): Promise<void>;
        loadListarAlertasEstoqueBaixo(params?: CardapioEstoqueListarAlertasEstoqueBaixoInput, options?: BffClientOptions): Promise<void>;
        criarOuAtualizarItemCardapio(params: CardapioEstoqueCriarOuAtualizarItemCardapioInput, signal?: AbortSignal): Promise<void>;
        handleCriarOuAtualizarItemCardapioClick(): void;
        criarOuAtualizarItemEstoque(params: CardapioEstoqueCriarOuAtualizarItemEstoqueInput, signal?: AbortSignal): Promise<void>;
        handleCriarOuAtualizarItemEstoqueClick(): void;
        registrarMovimentacaoEstoque(params: CardapioEstoqueRegistrarMovimentacaoEstoqueInput, signal?: AbortSignal): Promise<void>;
        handleRegistrarMovimentacaoEstoqueClick(): void;
        handleNavigateToDashboardGerenteClick(params?: Record<string, unknown>): void;
    }
}
declare module "_102043_/l2/cafeFlow/web/desktop/page11/cardapioEstoque" {
    import { CardapioEstoqueBase } from "_102043_/l2/cafeFlow/web/shared/cardapioEstoque";
    export class CardapioEstoqueDesktopPage11CardapioEstoquePage extends CardapioEstoqueBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102043_/l2/cafeFlow/web/desktop/page11/dashboardGerente.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: ({
            name: string;
            type: string;
            required: boolean;
            sources: string[];
            description: string;
            entityRef?: undefined;
            fieldRef?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            sources: string[];
            description: string;
            entityRef: string;
            fieldRef: string;
        })[];
        navigationRefs: {
            direction: string;
            pageId: string;
            trigger: string;
        }[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "dashboardGerente__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102043_/l2/cafeFlow/web/desktop/page11/dashboardGerente.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/desktop/page11/dashboardGerente.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l2/cafeFlow/web/shared/dashboardGerente.ts", "_102043_/l2/cafeFlow/web/contracts/dashboardGerente.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly tone: "Moderno e minimalista";
            readonly layout: "Interface rápida com foco em POS e painéis operacionais";
            readonly palette: readonly ["#C85A2A", "#F2C57C", "#F6F1EB", "#3B2F2F", "#2E7D32"];
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/shared/dashboardGerente" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { DashboardGerenteConsultarDashboardGerenteInput, DashboardGerenteConsultarDashboardGerenteOutput, DashboardGerenteListarAlertasEstoqueBaixoInput, DashboardGerenteListarAlertasEstoqueBaixoOutputItem } from "_102043_/l2/cafeFlow/web/contracts/dashboardGerente";
    const message_en: {
        brand: string;
        pageTitle: string;
        loaded: string;
        couldNotLoad: string;
        loadingConsultarDashboardGerente: string;
        loadingListarAlertasEstoqueBaixo: string;
    };
    type MessageType = typeof message_en;
    export class DashboardGerenteDashboardGerenteBase extends CollabLitElement {
        private readonly _stateKeys;
        totalRevenue: DashboardGerenteConsultarDashboardGerenteOutput['totalRevenue'] | undefined;
        orderCount: DashboardGerenteConsultarDashboardGerenteOutput['orderCount'] | undefined;
        averageTicket: DashboardGerenteConsultarDashboardGerenteOutput['averageTicket'] | undefined;
        itemsSold: DashboardGerenteConsultarDashboardGerenteOutput['itemsSold'] | undefined;
        serieVendasPorTurno: DashboardGerenteConsultarDashboardGerenteOutput['serieVendasPorTurno'] | undefined;
        rankingItensMaisVendidos: DashboardGerenteConsultarDashboardGerenteOutput['rankingItensMaisVendidos'] | undefined;
        alertasEstoqueBaixo: DashboardGerenteListarAlertasEstoqueBaixoOutputItem[];
        status: string;
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(params?: unknown, options?: BffClientOptions): Promise<void>;
        loadConsultarDashboardGerente(params?: DashboardGerenteConsultarDashboardGerenteInput, options?: BffClientOptions): Promise<void>;
        loadListarAlertasEstoqueBaixo(params?: DashboardGerenteListarAlertasEstoqueBaixoInput, options?: BffClientOptions): Promise<void>;
    }
}
declare module "_102043_/l2/cafeFlow/web/desktop/page11/dashboardGerente" {
    import { DashboardGerenteDashboardGerenteBase } from "_102043_/l2/cafeFlow/web/shared/dashboardGerente";
    export class DashboardGerenteDesktopPage11DashboardGerentePage extends DashboardGerenteDashboardGerenteBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102043_/l2/cafeFlow/web/desktop/page11/fechamentoTurno.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: string[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: string[];
        pageInputs: any[];
        navigationRefs: {
            direction: string;
            pageId: string;
            trigger: string;
            description: string;
        }[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "fechamentoTurno__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102043_/l2/cafeFlow/web/desktop/page11/fechamentoTurno.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/desktop/page11/fechamentoTurno.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l2/cafeFlow/web/shared/fechamentoTurno.ts", "_102043_/l2/cafeFlow/web/contracts/fechamentoTurno.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly tone: "Moderno e minimalista";
            readonly layout: "Interface rápida com foco em POS e painéis operacionais";
            readonly palette: readonly ["#C85A2A", "#F2C57C", "#F6F1EB", "#3B2F2F", "#2E7D32"];
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/shared/fechamentoTurno" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { FechamentoTurnoListarTurnosInput, FechamentoTurnoListarTurnosOutputItem, FechamentoTurnoListarPedidosInput, FechamentoTurnoListarPedidosOutputItem, FechamentoTurnoFecharTurnoInput, FechamentoTurnoObterRelatorioTurnoInput, FechamentoTurnoObterRelatorioTurnoOutput } from "_102043_/l2/cafeFlow/web/contracts/fechamentoTurno";
    const message_en: {
        brand: string;
        pageTitle: string;
        loaded: string;
        couldNotLoad: string;
        loadingListarTurnos: string;
        loadingListarPedidos: string;
        loadingObterRelatorioTurno: string;
        fecharTurnoLabel: string;
        fecharTurnoLoading: string;
        couldNotFecharTurno: string;
        navigateToDashboardGerente: string;
    };
    type MessageType = typeof message_en;
    export class FechamentoTurnoFechamentoTurnoBase extends CollabLitElement {
        private readonly _stateKeys;
        turnos: FechamentoTurnoListarTurnosOutputItem[];
        pedidos: FechamentoTurnoListarPedidosOutputItem[];
        shiftReportId: FechamentoTurnoObterRelatorioTurnoOutput['shiftReportId'] | undefined;
        shiftId: FechamentoTurnoObterRelatorioTurnoOutput['shiftId'] | undefined;
        totalSalesAmount: FechamentoTurnoObterRelatorioTurnoOutput['totalSalesAmount'] | undefined;
        totalOrders: FechamentoTurnoObterRelatorioTurnoOutput['totalOrders'] | undefined;
        totalItems: FechamentoTurnoObterRelatorioTurnoOutput['totalItems'] | undefined;
        notes: FechamentoTurnoObterRelatorioTurnoOutput['notes'] | undefined;
        createdAt: FechamentoTurnoObterRelatorioTurnoOutput['createdAt'] | undefined;
        updatedAt: FechamentoTurnoObterRelatorioTurnoOutput['updatedAt'] | undefined;
        fecharTurnoState: 'idle' | 'loading' | 'success' | 'error';
        status: string;
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(params?: unknown, options?: BffClientOptions): Promise<void>;
        loadListarTurnos(params?: FechamentoTurnoListarTurnosInput, options?: BffClientOptions): Promise<void>;
        loadListarPedidos(params?: FechamentoTurnoListarPedidosInput, options?: BffClientOptions): Promise<void>;
        loadObterRelatorioTurno(params?: FechamentoTurnoObterRelatorioTurnoInput, options?: BffClientOptions): Promise<void>;
        fecharTurno(params: FechamentoTurnoFecharTurnoInput, signal?: AbortSignal): Promise<void>;
        handleFecharTurnoClick(): void;
        handleNavigateToDashboardGerenteClick(params?: Record<string, unknown>): void;
    }
}
declare module "_102043_/l2/cafeFlow/web/desktop/page11/fechamentoTurno" {
    import { FechamentoTurnoFechamentoTurnoBase } from "_102043_/l2/cafeFlow/web/shared/fechamentoTurno";
    export class FechamentoTurnoDesktopPage11FechamentoTurnoPage extends FechamentoTurnoFechamentoTurnoBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102043_/l2/cafeFlow/web/desktop/page11/painelCozinha.defs" {
    export const definition: {
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "painelCozinha__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102043_/l2/cafeFlow/web/desktop/page11/painelCozinha.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/desktop/page11/painelCozinha.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l2/cafeFlow/web/shared/painelCozinha.ts", "_102043_/l2/cafeFlow/web/contracts/painelCozinha.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly tone: "Moderno e minimalista";
            readonly layout: "Interface rápida com foco em POS e painéis operacionais";
            readonly palette: readonly ["#C85A2A", "#F2C57C", "#F6F1EB", "#3B2F2F", "#2E7D32"];
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/shared/painelCozinha" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { PainelCozinhaListarPedidosCozinhaInput, PainelCozinhaListarPedidosCozinhaOutput, PainelCozinhaAtualizarStatusPedidoInput } from "_102043_/l2/cafeFlow/web/contracts/painelCozinha";
    const message_en: {
        brand: string;
        pageTitle: string;
        loaded: string;
        couldNotLoad: string;
        loadingListarPedidosCozinha: string;
        atualizarStatusPedidoLabel: string;
        atualizarStatusPedidoLoading: string;
        couldNotAtualizarStatusPedido: string;
    };
    type MessageType = typeof message_en;
    export class PainelCozinhaPainelCozinhaBase extends CollabLitElement {
        private readonly _stateKeys;
        pedidosCozinha: PainelCozinhaListarPedidosCozinhaOutput;
        atualizarStatusPedidoState: 'idle' | 'loading' | 'success' | 'error';
        status: string;
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(params?: unknown, options?: BffClientOptions): Promise<void>;
        loadListarPedidosCozinha(params?: PainelCozinhaListarPedidosCozinhaInput, options?: BffClientOptions): Promise<void>;
        atualizarStatusPedido(params: PainelCozinhaAtualizarStatusPedidoInput, signal?: AbortSignal): Promise<void>;
        handleAtualizarStatusPedidoClick(): void;
    }
}
declare module "_102043_/l2/cafeFlow/web/desktop/page11/painelCozinha" {
    import { PainelCozinhaPainelCozinhaBase } from "_102043_/l2/cafeFlow/web/shared/painelCozinha";
    export class PainelCozinhaDesktopPage11PainelCozinhaPage extends PainelCozinhaPainelCozinhaBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102043_/l2/cafeFlow/web/desktop/page11/posRapido.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: string[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: {
            direction: string;
            pageId: string;
            trigger: string;
            description: string;
        }[];
        sections: ({
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
            }[];
        } | {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
            }[];
        })[];
    };
    export const pipeline: readonly [{
        readonly id: "posRapido__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102043_/l2/cafeFlow/web/desktop/page11/posRapido.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/desktop/page11/posRapido.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l2/cafeFlow/web/shared/posRapido.ts", "_102043_/l2/cafeFlow/web/contracts/posRapido.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly tone: "Moderno e minimalista";
            readonly layout: "Interface rápida com foco em POS e painéis operacionais";
            readonly palette: readonly ["#C85A2A", "#F2C57C", "#F6F1EB", "#3B2F2F", "#2E7D32"];
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/shared/posRapido" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { BffClientOptions } from "_102029_/l2/bffClient";
    import type { PosRapidoListarPedidosInput, PosRapidoListarPedidosOutputItem, PosRapidoCriarPedidoInput } from "_102043_/l2/cafeFlow/web/contracts/posRapido";
    const message_en: {
        brand: string;
        pageTitle: string;
        loaded: string;
        couldNotLoad: string;
        loadingListarPedidos: string;
        criarPedidoLabel: string;
        criarPedidoLoading: string;
        couldNotCriarPedido: string;
        navigateToPainelCozinha: string;
    };
    type MessageType = typeof message_en;
    export class PosRapidoBase extends CollabLitElement {
        private readonly _stateKeys;
        status: string;
        pedidos: PosRapidoListarPedidosOutputItem[];
        criarPedidoState: 'idle' | 'loading' | 'success' | 'error';
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(params?: unknown, options?: BffClientOptions): Promise<void>;
        loadListarPedidos(params?: PosRapidoListarPedidosInput, options?: BffClientOptions): Promise<void>;
        criarPedido(params: PosRapidoCriarPedidoInput, signal?: AbortSignal): Promise<void>;
        handleCriarPedidoClick(): void;
        handleNavigateToPainelCozinhaClick(params?: Record<string, unknown>): void;
    }
}
declare module "_102043_/l2/cafeFlow/web/desktop/page11/posRapido" {
    import { PosRapidoBase } from "_102043_/l2/cafeFlow/web/shared/posRapido";
    export class PosRapidoDesktopPage11PosRapidoPage extends PosRapidoBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102043_/l2/cafeFlow/web/shared/cardapioEstoque.defs" {
    export const definition: {
        bffCommands: ({
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: string[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        } | {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: any[];
            readsTables: string[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        })[];
        navigationRefs: {
            direction: string;
            pageId: string;
            trigger: string;
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "cardapioEstoque__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102043_/l2/cafeFlow/web/shared/cardapioEstoque.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/shared/cardapioEstoque.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l2/cafeFlow/web/contracts/cardapioEstoque.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["menuItemRequiresCategory", "lowStockThresholdRule"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/shared/dashboardGerente.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: any[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: any[];
        }[];
        navigationRefs: {
            direction: string;
            pageId: string;
            trigger: string;
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "dashboardGerente__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102043_/l2/cafeFlow/web/shared/dashboardGerente.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/shared/dashboardGerente.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l2/cafeFlow/web/contracts/dashboardGerente.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/shared/fechamentoTurno.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: string[];
            writesTables: string[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: {
            direction: string;
            pageId: string;
            trigger: string;
            description: string;
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "fechamentoTurno__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102043_/l2/cafeFlow/web/shared/fechamentoTurno.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/shared/fechamentoTurno.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l2/cafeFlow/web/contracts/fechamentoTurno.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/shared/painelCozinha.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: string[];
            writesTables: string[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: {
            direction: string;
            pageId: string;
            trigger: string;
            description: string;
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "painelCozinha__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102043_/l2/cafeFlow/web/shared/painelCozinha.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/shared/painelCozinha.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l2/cafeFlow/web/contracts/painelCozinha.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["orderStatusTransition"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/shared/posRapido.defs" {
    export const definition: {
        bffCommands: ({
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: any[];
            readsTables: string[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: any[];
        } | {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: string[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        })[];
        navigationRefs: {
            direction: string;
            pageId: string;
            trigger: string;
            description: string;
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "posRapido__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102043_/l2/cafeFlow/web/shared/posRapido.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/shared/posRapido.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l2/cafeFlow/web/contracts/posRapido.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["orderRequiresItem"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/plugins/llmSalesAssistant/plugin.defs" {
    export const llmSalesAssistantPluginPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginDraft";
        readonly artifactId: "llmSalesAssistant";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 16;
            readonly planId: "plan-plugins";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "llmSalesAssistant";
                readonly provider: "Llm Sales Assistant";
                readonly priority: "soon";
                readonly reason: "Necessário para executar o assistente IA de vendas previsto para a fase soon.";
                readonly events: readonly [];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly ["Resumo diário de vendas", "Itens mais vendidos (últimos 7 dias)", "Dados de estoque e promoções ativas (se aplicável)"];
                readonly outputData: readonly ["Resumo de vendas", "Sugestões de promoção", "Insights de desempenho"];
                readonly webhooks: readonly [];
                readonly risks: readonly ["Dependência de decisão do cliente sobre uso de IA e proxy de LLM."];
                readonly questions: readonly ["Qual provedor/endpoint do proxy de LLM deve ser usado e quais limites de uso estão previstos?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102043_/l2/plugins/llmSalesAssistant/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102043_/l2/cafeFlow/plugins/llmSalesAssistant.defs.ts";
            };
        };
    };
    export default llmSalesAssistantPluginPlan;
}
declare module "_102043_/l4/workflows/lowStockAlertWorkflow.defs" {
    export const lowStockAlertWorkflowDef: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "workflow";
        readonly artifactId: "lowStockAlertWorkflow";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanWorkflowDefinition";
            readonly stepId: 29;
            readonly planId: "plan-validate-solution-coverage";
        };
        readonly data: {
            readonly workflowDefinition: {
                readonly workflowId: "lowStockAlertWorkflow";
                readonly title: "Workflow de alerta de estoque baixo";
                readonly purpose: "Monitorar movimentações de estoque e gerar alertas automáticos quando itens atingirem o limite mínimo configurado.";
                readonly executionMode: "automation";
                readonly createsTask: true;
                readonly taskConfig: {
                    readonly taskTitleTemplate: "Verificar alerta de estoque baixo para item {{stockItemId}}";
                    readonly assigneeRules: readonly ["gerente"];
                    readonly slaRules: readonly [];
                    readonly taskRoomRequired: false;
                };
                readonly actors: readonly ["gerente"];
                readonly states: readonly [{
                    readonly stateId: "monitoring";
                    readonly description: "Monitoramento contínuo das movimentações de estoque.";
                }, {
                    readonly stateId: "alertCreated";
                    readonly description: "Alerta de estoque baixo registrado e ativo.";
                }];
                readonly transitions: readonly [{
                    readonly from: "monitoring";
                    readonly to: "alertCreated";
                    readonly trigger: "registrarMovimentacaoEstoque";
                    readonly actor: "gerente";
                    readonly conditions: readonly ["lowStockThresholdRule"];
                    readonly actions: readonly ["create StockMovement with stockItemId, orderId, movementType, quantity, reason, occurredAt, createdAt, updatedAt", "create LowStockAlert with stockItemId, triggeredAt, currentQuantity, minimumQuantity, status=ativo, createdAt, updatedAt"];
                    readonly rulesApplied: readonly ["lowStockThresholdRule"];
                }];
                readonly requiredEntities: readonly ["StockMovement", "LowStockAlert"];
                readonly persistenceRefs: readonly ["stockMovement", "lowStockAlert", "lowStockMetrics"];
                readonly usecaseRefs: readonly ["registrarMovimentacaoEstoque", "listarMovimentacoesEstoque", "listarAlertasEstoqueBaixo"];
                readonly metricRefs: readonly ["lowStockMetrics"];
                readonly userActions: readonly [];
                readonly relatedPages: readonly ["cardapioEstoque", "dashboardGerente"];
                readonly relatedAgents: readonly [];
                readonly relatedPlugins: readonly [];
                readonly rulesApplied: readonly ["lowStockThresholdRule"];
                readonly implementationSuggestions: readonly [{
                    readonly suggestionId: "autoAlertOnMovement";
                    readonly title: "Disparar alerta automaticamente após movimentação que cruze o limite";
                    readonly priority: "now";
                    readonly description: "Disparar alerta automaticamente via registrarMovimentacaoEstoque quando a movimentação reduzir o estoque abaixo do mínimo.";
                    readonly tradeoff: "Pode aumentar o volume de alertas em períodos de alta rotatividade.";
                }, {
                    readonly suggestionId: "deduplicateAlerts";
                    readonly title: "Evitar duplicidade de alertas para o mesmo item enquanto não reabastecido";
                    readonly priority: "soon";
                    readonly description: "Antes de criar novo LowStockAlert ativo para o mesmo stockItemId, verificar se já existe alerta ativo e manter um único registro.";
                    readonly tradeoff: "Exige lógica adicional no caso de uso e potencialmente mais consultas.";
                }];
                readonly workflowScope: "singleModule";
                readonly moduleRefs: readonly ["cafeFlow"];
                readonly pageRefsByModule: readonly [];
                readonly entityRefsByModule: readonly [{
                    readonly moduleId: "cafeFlow";
                    readonly entity: "StockMovement";
                }, {
                    readonly moduleId: "cafeFlow";
                    readonly entity: "LowStockAlert";
                }];
                readonly writesArtifacts: readonly [{
                    readonly moduleId: "cafeFlow";
                    readonly artifactType: "workflow";
                    readonly artifactId: "lowStockAlertWorkflow";
                }];
            };
            readonly defsPlan: {
                readonly fileName: "workflows/lowStockAlertWorkflow.defs.ts";
                readonly exportName: "lowStockAlertWorkflowDef";
                readonly saveAsDefs: true;
            };
        };
    };
    export default lowStockAlertWorkflowDef;
}
declare module "_102043_/l4/workflows/orderStatusWorkflow.defs" {
    export const orderStatusWorkflowDef: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "workflow";
        readonly artifactId: "orderStatusWorkflow";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanWorkflowDefinition";
            readonly stepId: 29;
            readonly planId: "plan-validate-solution-coverage";
        };
        readonly data: {
            readonly workflowDefinition: {
                readonly workflowId: "orderStatusWorkflow";
                readonly title: "Workflow de status do pedido";
                readonly purpose: "Controlar o ciclo de vida de um pedido desde o recebimento até a entrega ou cancelamento, coordenando a cozinha e registrando histórico.";
                readonly executionMode: "entityLifecycle";
                readonly createsTask: true;
                readonly taskConfig: {
                    readonly taskTitleTemplate: "Pedido {{orderId}} em preparo";
                    readonly assigneeRules: readonly ["cozinhaQueue"];
                    readonly slaRules: readonly ["preparoDentroDe15Min"];
                    readonly taskRoomRequired: true;
                };
                readonly actors: readonly ["atendente", "cozinha"];
                readonly states: readonly [{
                    readonly stateId: "recebido";
                    readonly description: "Pedido registrado e aguardando início do preparo.";
                }, {
                    readonly stateId: "emPreparo";
                    readonly description: "Pedido em preparação pela cozinha.";
                }, {
                    readonly stateId: "pronto";
                    readonly description: "Pedido finalizado e aguardando entrega.";
                }, {
                    readonly stateId: "entregue";
                    readonly description: "Pedido entregue ao cliente.";
                }, {
                    readonly stateId: "cancelado";
                    readonly description: "Pedido cancelado antes da entrega.";
                }];
                readonly transitions: readonly [{
                    readonly from: "recebido";
                    readonly to: "emPreparo";
                    readonly trigger: "iniciarPreparo";
                    readonly actor: "cozinha";
                    readonly conditions: readonly ["orderStatusTransition"];
                    readonly actions: readonly ["Order.status=emPreparo", "Order.updatedAt=now", "OrderStatusHistory.fromStatus=Recebido", "OrderStatusHistory.toStatus=Em preparo", "OrderStatusHistory.changedAt=now", "OrderStatusHistory.changedBy=actorId", "OrderStatusHistory.createdAt=now", "OrderStatusHistory.updatedAt=now"];
                    readonly rulesApplied: readonly ["orderStatusTransition"];
                }, {
                    readonly from: "emPreparo";
                    readonly to: "pronto";
                    readonly trigger: "finalizarPreparo";
                    readonly actor: "cozinha";
                    readonly conditions: readonly ["orderStatusTransition"];
                    readonly actions: readonly ["Order.status=pronto", "Order.updatedAt=now", "OrderStatusHistory.fromStatus=Em preparo", "OrderStatusHistory.toStatus=Pronto", "OrderStatusHistory.changedAt=now", "OrderStatusHistory.changedBy=actorId", "OrderStatusHistory.createdAt=now", "OrderStatusHistory.updatedAt=now"];
                    readonly rulesApplied: readonly ["orderStatusTransition"];
                }, {
                    readonly from: "pronto";
                    readonly to: "entregue";
                    readonly trigger: "confirmarEntrega";
                    readonly actor: "atendente";
                    readonly conditions: readonly ["orderStatusTransition"];
                    readonly actions: readonly ["Order.status=entregue", "Order.updatedAt=now", "OrderStatusHistory.fromStatus=Pronto", "OrderStatusHistory.toStatus=Entregue", "OrderStatusHistory.changedAt=now", "OrderStatusHistory.changedBy=actorId", "OrderStatusHistory.createdAt=now", "OrderStatusHistory.updatedAt=now"];
                    readonly rulesApplied: readonly ["orderStatusTransition"];
                }, {
                    readonly from: "recebido";
                    readonly to: "cancelado";
                    readonly trigger: "cancelarPedido";
                    readonly actor: "atendente";
                    readonly conditions: readonly ["orderStatusTransition"];
                    readonly actions: readonly ["Order.status=cancelado", "Order.updatedAt=now", "OrderStatusHistory.fromStatus=Recebido", "OrderStatusHistory.toStatus=Cancelado", "OrderStatusHistory.changedAt=now", "OrderStatusHistory.changedBy=actorId", "OrderStatusHistory.createdAt=now", "OrderStatusHistory.updatedAt=now"];
                    readonly rulesApplied: readonly ["orderStatusTransition"];
                }, {
                    readonly from: "emPreparo";
                    readonly to: "cancelado";
                    readonly trigger: "cancelarPedido";
                    readonly actor: "cozinha";
                    readonly conditions: readonly ["orderStatusTransition"];
                    readonly actions: readonly ["Order.status=cancelado", "Order.updatedAt=now", "OrderStatusHistory.fromStatus=Em preparo", "OrderStatusHistory.toStatus=Cancelado", "OrderStatusHistory.changedAt=now", "OrderStatusHistory.changedBy=actorId", "OrderStatusHistory.createdAt=now", "OrderStatusHistory.updatedAt=now"];
                    readonly rulesApplied: readonly ["orderStatusTransition"];
                }, {
                    readonly from: "pronto";
                    readonly to: "cancelado";
                    readonly trigger: "cancelarPedido";
                    readonly actor: "atendente";
                    readonly conditions: readonly ["orderStatusTransition"];
                    readonly actions: readonly ["Order.status=cancelado", "Order.updatedAt=now", "OrderStatusHistory.fromStatus=Pronto", "OrderStatusHistory.toStatus=Cancelado", "OrderStatusHistory.changedAt=now", "OrderStatusHistory.changedBy=actorId", "OrderStatusHistory.createdAt=now", "OrderStatusHistory.updatedAt=now"];
                    readonly rulesApplied: readonly ["orderStatusTransition"];
                }];
                readonly requiredEntities: readonly ["Order", "OrderStatusHistory"];
                readonly persistenceRefs: readonly ["order", "orderStatusHistory", "dailySalesMetrics", "topSellingItemsMetrics"];
                readonly usecaseRefs: readonly ["criarPedido", "listarPedidos", "listarPedidosCozinha", "atualizarStatusPedido"];
                readonly metricRefs: readonly ["dailySalesMetrics", "topSellingItemsMetrics"];
                readonly userActions: readonly ["criarPedido", "iniciarPreparo", "finalizarPreparo", "confirmarEntrega", "cancelarPedido"];
                readonly relatedPages: readonly ["fechamentoTurno", "painelCozinha", "posRapido"];
                readonly relatedAgents: readonly [];
                readonly relatedPlugins: readonly [];
                readonly rulesApplied: readonly ["orderStatusTransition", "orderRequiresItem"];
                readonly implementationSuggestions: readonly [{
                    readonly suggestionId: "taskOnPreparo";
                    readonly title: "Criar tarefa para cozinha ao mudar para 'emPreparo'";
                    readonly priority: "now";
                    readonly description: "Criar tarefa vinculada ao pedido quando a transição para emPreparo ocorrer via atualizarStatusPedido, garantindo visibilidade na fila da cozinha.";
                    readonly tradeoff: "Aumenta volume de tarefas e requer limpeza automática após entrega ou cancelamento.";
                }, {
                    readonly suggestionId: "historyOnTransition";
                    readonly title: "Registrar histórico em OrderStatusHistory a cada transição válida";
                    readonly priority: "now";
                    readonly description: "Persistir um registro de histórico em cada mudança de status usando OrderStatusHistory para auditoria e métricas de tempo.";
                    readonly tradeoff: "Cresce o volume de registros e exige indexação eficiente.";
                }];
                readonly workflowScope: "singleModule";
                readonly moduleRefs: readonly ["cafeFlow"];
                readonly pageRefsByModule: readonly [];
                readonly entityRefsByModule: readonly [{
                    readonly moduleId: "cafeFlow";
                    readonly entity: "Order";
                }, {
                    readonly moduleId: "cafeFlow";
                    readonly entity: "OrderStatusHistory";
                }];
                readonly writesArtifacts: readonly [{
                    readonly moduleId: "cafeFlow";
                    readonly artifactType: "workflow";
                    readonly artifactId: "orderStatusWorkflow";
                }];
            };
            readonly defsPlan: {
                readonly fileName: "workflows/orderStatusWorkflow.defs.ts";
                readonly exportName: "orderStatusWorkflowDef";
                readonly saveAsDefs: true;
            };
        };
    };
    export default orderStatusWorkflowDef;
}
declare module "_102043_/l4/workflows/posOrderCaptureWorkflow.defs" {
    export const posOrderCaptureWorkflowDef: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "workflow";
        readonly artifactId: "posOrderCaptureWorkflow";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanWorkflowDefinition";
            readonly stepId: 29;
            readonly planId: "plan-validate-solution-coverage";
        };
        readonly data: {
            readonly workflowDefinition: {
                readonly workflowId: "posOrderCaptureWorkflow";
                readonly title: "Workflow de lançamento rápido de pedido no POS";
                readonly purpose: "Guiar o atendente no processo de captura rápida de itens, confirmação e envio para a cozinha diretamente na interface do POS.";
                readonly executionMode: "uiState";
                readonly createsTask: false;
                readonly taskConfig: {
                    readonly taskTitleTemplate: "N/A";
                    readonly assigneeRules: readonly [];
                    readonly slaRules: readonly [];
                    readonly taskRoomRequired: false;
                };
                readonly actors: readonly ["atendente"];
                readonly states: readonly [{
                    readonly stateId: "draftOrder";
                    readonly description: "Captura rápida de itens e ajustes no pedido ainda não confirmado.";
                }, {
                    readonly stateId: "reviewOrder";
                    readonly description: "Revisão final do pedido antes da confirmação.";
                }, {
                    readonly stateId: "sentToKitchen";
                    readonly description: "Pedido confirmado e enviado para preparo com status recebido.";
                }];
                readonly transitions: readonly [{
                    readonly from: "draftOrder";
                    readonly to: "draftOrder";
                    readonly trigger: "addOrUpdateItem";
                    readonly actor: "atendente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["OrderItem.menuItemId", "OrderItem.quantity", "OrderItem.unitPrice", "OrderItem.totalPrice", "OrderItem.updatedAt"];
                    readonly rulesApplied: readonly [];
                }, {
                    readonly from: "draftOrder";
                    readonly to: "reviewOrder";
                    readonly trigger: "reviewOrder";
                    readonly actor: "atendente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["Order.updatedAt"];
                    readonly rulesApplied: readonly [];
                }, {
                    readonly from: "reviewOrder";
                    readonly to: "draftOrder";
                    readonly trigger: "editItems";
                    readonly actor: "atendente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["Order.updatedAt"];
                    readonly rulesApplied: readonly [];
                }, {
                    readonly from: "reviewOrder";
                    readonly to: "sentToKitchen";
                    readonly trigger: "confirmAndSend";
                    readonly actor: "atendente";
                    readonly conditions: readonly ["orderRequiresItem"];
                    readonly actions: readonly ["Order.status=recebido", "Order.createdAt", "Order.updatedAt"];
                    readonly rulesApplied: readonly ["orderRequiresItem"];
                }];
                readonly requiredEntities: readonly ["Order", "OrderItem"];
                readonly persistenceRefs: readonly ["order"];
                readonly usecaseRefs: readonly ["criarPedido"];
                readonly metricRefs: readonly [];
                readonly userActions: readonly ["addOrUpdateItem", "reviewOrder", "editItems", "confirmAndSend"];
                readonly relatedPages: readonly ["posRapido"];
                readonly relatedAgents: readonly [];
                readonly relatedPlugins: readonly [];
                readonly rulesApplied: readonly ["orderRequiresItem"];
                readonly implementationSuggestions: readonly [{
                    readonly suggestionId: "fastAddItems";
                    readonly title: "Manter estado local de itens antes de persistir o pedido completo";
                    readonly priority: "now";
                    readonly description: "Use um estado local no POS para adicionar/remover itens rapidamente e apenas persistir no confirmar.";
                    readonly tradeoff: "Exige sincronização cuidadosa ao confirmar para evitar divergências.";
                }, {
                    readonly suggestionId: "oneTapSend";
                    readonly title: "Botão único de enviar para cozinha que dispara o orderStatusWorkflow";
                    readonly priority: "now";
                    readonly description: "Ofereça uma ação única no POS que confirma e inicia o preparo sem navegação extra.";
                    readonly tradeoff: "Menos confirmação intermediária pode aumentar erros de envio.";
                }, {
                    readonly suggestionId: "noTaskNeeded";
                    readonly title: "Sem criação de tarefa para captura rápida no POS";
                    readonly priority: "now";
                    readonly description: "A captura rápida é uma interação síncrona do POS; a criação de tarefa adicionaria fricção sem ganho operacional.";
                    readonly tradeoff: "Sem tarefas, não há fila assíncrona para retomar pedidos abandonados.";
                }];
                readonly workflowScope: "singleModule";
                readonly moduleRefs: readonly ["cafeFlow"];
                readonly pageRefsByModule: readonly [];
                readonly entityRefsByModule: readonly [{
                    readonly moduleId: "cafeFlow";
                    readonly entity: "Order";
                }, {
                    readonly moduleId: "cafeFlow";
                    readonly entity: "OrderItem";
                }];
                readonly writesArtifacts: readonly [{
                    readonly moduleId: "cafeFlow";
                    readonly artifactType: "workflow";
                    readonly artifactId: "posOrderCaptureWorkflow";
                }];
            };
            readonly defsPlan: {
                readonly fileName: "workflows/posOrderCaptureWorkflow.defs.ts";
                readonly exportName: "posOrderCaptureWorkflowDef";
                readonly saveAsDefs: true;
            };
        };
    };
    export default posOrderCaptureWorkflowDef;
}
declare module "_102043_/l4/workflows/salesSummaryWorkflow.defs" {
    export const salesSummaryWorkflowDef: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "workflow";
        readonly artifactId: "salesSummaryWorkflow";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanWorkflowDefinition";
            readonly stepId: 57;
            readonly planId: "";
        };
        readonly data: {
            readonly workflowDefinition: {
                readonly workflowId: "salesSummaryWorkflow";
                readonly title: "Workflow de solicitação de resumo de vendas";
                readonly purpose: "Coordenar a solicitação do gerente, processamento assíncrono pelo assistente de IA e entrega do resumo de vendas.";
                readonly executionMode: "taskWorkflow";
                readonly createsTask: true;
                readonly taskConfig: {
                    readonly taskTitleTemplate: "Resumo de vendas solicitado para o turno {{shiftReportId}}";
                    readonly assigneeRules: readonly ["gerente"];
                    readonly slaRules: readonly ["responderEm24h"];
                    readonly taskRoomRequired: false;
                };
                readonly actors: readonly ["gerente"];
                readonly states: readonly [{
                    readonly stateId: "requested";
                    readonly description: "Solicitação registrada e pronta para processamento.";
                }, {
                    readonly stateId: "processing";
                    readonly description: "Resumo sendo processado de forma assíncrona.";
                }, {
                    readonly stateId: "completed";
                    readonly description: "Resumo pronto para consulta.";
                }, {
                    readonly stateId: "failed";
                    readonly description: "Falha ao processar o resumo.";
                }];
                readonly transitions: readonly [{
                    readonly from: "requested";
                    readonly to: "processing";
                    readonly trigger: "startProcessing";
                    readonly actor: "gerente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["set SalesSummaryRequest.updatedAt = now()"];
                    readonly rulesApplied: readonly ["salesSummaryUsesLast7Days"];
                }, {
                    readonly from: "processing";
                    readonly to: "completed";
                    readonly trigger: "finalizeSummary";
                    readonly actor: "gerente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["set SalesSummaryRequest.updatedAt = now()"];
                    readonly rulesApplied: readonly ["salesSummaryUsesLast7Days"];
                }, {
                    readonly from: "processing";
                    readonly to: "failed";
                    readonly trigger: "markFailed";
                    readonly actor: "gerente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["set SalesSummaryRequest.updatedAt = now()"];
                    readonly rulesApplied: readonly [];
                }];
                readonly requiredEntities: readonly ["SalesSummaryRequest"];
                readonly persistenceRefs: readonly ["salesSummaryRequest"];
                readonly usecaseRefs: readonly ["solicitarResumoVendasDia", "listarSolicitacoesResumoVendas"];
                readonly metricRefs: readonly [];
                readonly userActions: readonly ["solicitarResumoVendas", "acompanharStatusResumo"];
                readonly relatedPages: readonly [];
                readonly relatedAgents: readonly [];
                readonly relatedPlugins: readonly [];
                readonly rulesApplied: readonly ["salesSummaryUsesLast7Days"];
                readonly implementationSuggestions: readonly [{
                    readonly suggestionId: "asyncProcessing";
                    readonly title: "Processar solicitação de forma assíncrona via plugin de LLM";
                    readonly priority: "soon";
                    readonly description: "Executar a geração do resumo em job assíncrono para evitar bloqueio da interface do gerente.";
                    readonly tradeoff: "Aumenta complexidade operacional e demanda orquestração de status.";
                }, {
                    readonly suggestionId: "notifyOnComplete";
                    readonly title: "Notificar gerente quando o resumo estiver pronto";
                    readonly priority: "soon";
                    readonly description: "Disparar notificação quando o processamento for concluído para reduzir polling.";
                    readonly tradeoff: "Requer canal de notificação e controle de preferências.";
                }];
                readonly workflowScope: "singleModule";
                readonly moduleRefs: readonly ["cafeFlow"];
                readonly pageRefsByModule: readonly [];
                readonly entityRefsByModule: readonly [{
                    readonly moduleId: "cafeFlow";
                    readonly entity: "SalesSummaryRequest";
                }];
                readonly writesArtifacts: readonly [{
                    readonly moduleId: "cafeFlow";
                    readonly artifactType: "workflow";
                    readonly artifactId: "salesSummaryWorkflow";
                }];
            };
            readonly defsPlan: {
                readonly fileName: "workflows/salesSummaryWorkflow.defs.ts";
                readonly exportName: "salesSummaryWorkflowDef";
                readonly saveAsDefs: true;
            };
        };
    };
    export default salesSummaryWorkflowDef;
}
declare module "_102043_/l4/workflows/shiftClosureWorkflow.defs" {
    export const shiftClosureWorkflowDef: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "workflow";
        readonly artifactId: "shiftClosureWorkflow";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanWorkflowDefinition";
            readonly stepId: 29;
            readonly planId: "plan-validate-solution-coverage";
        };
        readonly data: {
            readonly workflowDefinition: {
                readonly workflowId: "shiftClosureWorkflow";
                readonly title: "Workflow de fechamento de turno";
                readonly purpose: "Gerenciar o ciclo de vida do turno diário, garantindo que todos os pedidos estejam finalizados antes do fechamento e gerando o relatório consolidado.";
                readonly executionMode: "entityLifecycle";
                readonly createsTask: true;
                readonly taskConfig: {
                    readonly taskTitleTemplate: "Revisar fechamento do turno {{shiftId}}";
                    readonly assigneeRules: readonly ["gerente"];
                    readonly slaRules: readonly ["reviewWithin4h"];
                    readonly taskRoomRequired: true;
                };
                readonly actors: readonly ["gerente"];
                readonly states: readonly [{
                    readonly stateId: "aberto";
                    readonly description: "Turno aberto para operação diária.";
                }, {
                    readonly stateId: "emFechamento";
                    readonly description: "Turno em processo de conferência e validação para fechamento.";
                }, {
                    readonly stateId: "fechado";
                    readonly description: "Turno fechado e consolidado com relatório gerado.";
                }];
                readonly transitions: readonly [{
                    readonly from: "aberto";
                    readonly to: "emFechamento";
                    readonly trigger: "iniciarFechamento";
                    readonly actor: "gerente";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["setShift.status=emFechamento", "setShift.updatedAt=now"];
                    readonly rulesApplied: readonly [];
                }, {
                    readonly from: "emFechamento";
                    readonly to: "fechado";
                    readonly trigger: "confirmarFechamento";
                    readonly actor: "gerente";
                    readonly conditions: readonly ["shiftHasNoOpenOrders"];
                    readonly actions: readonly ["setShift.status=fechado", "setShift.closedAt=now", "setShift.updatedAt=now"];
                    readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
                }];
                readonly requiredEntities: readonly ["Shift", "ShiftReport"];
                readonly persistenceRefs: readonly ["shift", "shiftReport", "dailySalesMetrics"];
                readonly usecaseRefs: readonly ["abrirTurno", "fecharTurno", "listarTurnos", "obterRelatorioTurno"];
                readonly metricRefs: readonly ["dailySalesMetrics"];
                readonly userActions: readonly ["iniciarFechamento", "confirmarFechamento", "consultarRelatorioTurno"];
                readonly relatedPages: readonly ["fechamentoTurno"];
                readonly relatedAgents: readonly [];
                readonly relatedPlugins: readonly [];
                readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
                readonly implementationSuggestions: readonly [{
                    readonly suggestionId: "blockClosureOpenOrders";
                    readonly title: "Bloquear transição para 'fechado' se houver pedidos abertos";
                    readonly priority: "now";
                    readonly description: "Aplicar a regra shiftClosureRequiresNoOpenOrders no caso de uso fecharTurno para impedir fechamento com pedidos em aberto.";
                    readonly tradeoff: "Pode exigir uma etapa adicional de resolução de pendências, aumentando o tempo de fechamento.";
                }, {
                    readonly suggestionId: "generateReportOnClosure";
                    readonly title: "Gerar ShiftReport automaticamente ao concluir o fechamento";
                    readonly priority: "now";
                    readonly description: "No caso de uso fecharTurno, criar o ShiftReport e consolidar os totais do turno ao final da transição.";
                    readonly tradeoff: "Aumenta o tempo de execução do fechamento devido à consolidação.";
                }, {
                    readonly suggestionId: "taskReviewOnClosure";
                    readonly title: "Criar tarefa de revisão para o gerente ao iniciar 'emFechamento'";
                    readonly priority: "now";
                    readonly description: "Ao disparar iniciarFechamento, criar uma tarefa de revisão vinculada ao turno para conferência final.";
                    readonly tradeoff: "Introduz dependência de tarefas e pode atrasar o fechamento caso não seja cumprida.";
                }];
                readonly workflowScope: "singleModule";
                readonly moduleRefs: readonly ["cafeFlow"];
                readonly pageRefsByModule: readonly [];
                readonly entityRefsByModule: readonly [{
                    readonly moduleId: "cafeFlow";
                    readonly entity: "Shift";
                }, {
                    readonly moduleId: "cafeFlow";
                    readonly entity: "ShiftReport";
                }];
                readonly writesArtifacts: readonly [{
                    readonly moduleId: "cafeFlow";
                    readonly artifactType: "workflow";
                    readonly artifactId: "shiftClosureWorkflow";
                }];
            };
            readonly defsPlan: {
                readonly fileName: "workflows/shiftClosureWorkflow.defs.ts";
                readonly exportName: "shiftClosureWorkflowDef";
                readonly saveAsDefs: true;
            };
        };
    };
    export default shiftClosureWorkflowDef;
}
declare module "_102043_/l5/cafeFlow/journeys.defs" {
    export const userJourneysPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "userJourneys";
        readonly artifactId: "journeys";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUserJourneys";
            readonly stepId: 12;
            readonly planId: "plan-user-journeys";
        };
        readonly data: {
            readonly journeys: readonly [{
                readonly journeyId: "registrarPedidoPos";
                readonly title: "Registrar pedido no POS";
                readonly actor: "atendente";
                readonly capabilityIds: readonly ["registrarPedido"];
                readonly description: "O atendente registra rapidamente um pedido no POS, confirma itens e envia para a cozinha.";
                readonly steps: readonly [{
                    readonly intent: "Iniciar um novo pedido rapidamente";
                    readonly action: "Acessa a interface rápida de POS e abre um pedido em branco";
                    readonly entities: readonly ["Order"];
                    readonly pageHint: "posRapido";
                    readonly outcome: "Pedido criado em status recebido";
                }, {
                    readonly intent: "Adicionar itens e quantidades";
                    readonly action: "Seleciona itens do cardápio e ajusta quantidades";
                    readonly entities: readonly ["Order", "OrderItem", "MenuItem"];
                    readonly pageHint: "posRapido";
                    readonly outcome: "Itens adicionados ao pedido";
                }, {
                    readonly intent: "Revisar total e observações";
                    readonly action: "Confere itens e adiciona observações do cliente";
                    readonly entities: readonly ["Order", "OrderItem"];
                    readonly pageHint: "posRapido";
                    readonly outcome: "Pedido pronto para envio";
                }, {
                    readonly intent: "Enviar para a cozinha";
                    readonly action: "Confirma o pedido e dispara para o painel da cozinha";
                    readonly entities: readonly ["Order", "OrderStatusHistory"];
                    readonly pageHint: "posRapido";
                    readonly outcome: "Pedido visível na cozinha com status recebido";
                }, {
                    readonly intent: "Cancelar um pedido antes do preparo";
                    readonly action: "Seleciona o pedido e solicita cancelamento";
                    readonly entities: readonly ["Order", "OrderStatusHistory"];
                    readonly pageHint: "posRapido";
                    readonly outcome: "Pedido marcado como cancelado e removido do fluxo da cozinha";
                }];
            }, {
                readonly journeyId: "atualizarStatusCozinha";
                readonly title: "Atualizar status do pedido na cozinha";
                readonly actor: "cozinha";
                readonly capabilityIds: readonly ["atualizarStatusCozinha"];
                readonly description: "A equipe de cozinha acompanha os pedidos e atualiza o status conforme o preparo avança.";
                readonly steps: readonly [{
                    readonly intent: "Ver fila de pedidos recebidos";
                    readonly action: "Abre o painel de status da cozinha";
                    readonly entities: readonly ["Order"];
                    readonly pageHint: "painelCozinha";
                    readonly outcome: "Lista de pedidos recebidos visível";
                }, {
                    readonly intent: "Iniciar preparo do pedido";
                    readonly action: "Seleciona um pedido e muda status para em preparo";
                    readonly entities: readonly ["Order", "OrderStatusHistory"];
                    readonly pageHint: "painelCozinha";
                    readonly outcome: "Pedido passa para emPreparo";
                }, {
                    readonly intent: "Marcar pedido como pronto";
                    readonly action: "Atualiza o pedido para pronto quando finaliza";
                    readonly entities: readonly ["Order", "OrderStatusHistory"];
                    readonly pageHint: "painelCozinha";
                    readonly outcome: "Pedido fica disponível para entrega";
                }, {
                    readonly intent: "Entregar pedido ao cliente";
                    readonly action: "Confirma a entrega quando o pedido é retirado";
                    readonly entities: readonly ["Order", "OrderStatusHistory"];
                    readonly pageHint: "painelCozinha";
                    readonly outcome: "Pedido marcado como entregue";
                }, {
                    readonly intent: "Sinalizar cancelamento informado pelo atendimento";
                    readonly action: "Atualiza o pedido para cancelado quando necessário";
                    readonly entities: readonly ["Order", "OrderStatusHistory"];
                    readonly pageHint: "painelCozinha";
                    readonly outcome: "Pedido removido do fluxo de preparo";
                }];
            }, {
                readonly journeyId: "gerenciarCardapio";
                readonly title: "Gerenciar itens do cardápio";
                readonly actor: "gerente";
                readonly capabilityIds: readonly ["gerenciarCardapio"];
                readonly description: "O gerente cria e ajusta itens do cardápio com categorias e disponibilidade.";
                readonly steps: readonly [{
                    readonly intent: "Acessar gestão de cardápio";
                    readonly action: "Entra no módulo de gerenciamento de cardápio e estoque";
                    readonly entities: readonly ["MenuItem", "MenuCategory"];
                    readonly pageHint: "cardapioEstoque";
                    readonly outcome: "Lista de itens do cardápio exibida";
                }, {
                    readonly intent: "Criar um novo item";
                    readonly action: "Clica em adicionar item, define nome, preço e categoria";
                    readonly entities: readonly ["MenuItem", "MenuCategory"];
                    readonly pageHint: "cardapioEstoque";
                    readonly outcome: "Item criado e disponível no POS";
                }, {
                    readonly intent: "Editar um item existente";
                    readonly action: "Seleciona um item e ajusta preço ou descrição";
                    readonly entities: readonly ["MenuItem"];
                    readonly pageHint: "cardapioEstoque";
                    readonly outcome: "Item atualizado no cardápio";
                }, {
                    readonly intent: "Desativar item temporariamente";
                    readonly action: "Marca o item como indisponível";
                    readonly entities: readonly ["MenuItem"];
                    readonly pageHint: "cardapioEstoque";
                    readonly outcome: "Item oculto no POS e cozinha";
                }, {
                    readonly intent: "Bloqueio por falta de categoria";
                    readonly action: "Tenta salvar item sem categoria e corrige";
                    readonly entities: readonly ["MenuItem", "MenuCategory"];
                    readonly pageHint: "cardapioEstoque";
                    readonly outcome: "Item salvo somente após definir categoria";
                }];
            }, {
                readonly journeyId: "gerenciarEstoque";
                readonly title: "Gerenciar estoque e alertas";
                readonly actor: "gerente";
                readonly capabilityIds: readonly ["gerenciarEstoque"];
                readonly description: "O gerente controla níveis de estoque e reage a alertas de baixo estoque.";
                readonly steps: readonly [{
                    readonly intent: "Visualizar estoque atual";
                    readonly action: "Acessa o painel de cardápio e estoque e filtra por estoque";
                    readonly entities: readonly ["StockItem"];
                    readonly pageHint: "cardapioEstoque";
                    readonly outcome: "Lista de itens com quantidades exibida";
                }, {
                    readonly intent: "Registrar entrada ou saída";
                    readonly action: "Seleciona um item e registra movimentação de estoque";
                    readonly entities: readonly ["StockItem", "StockMovement", "UnitOfMeasure"];
                    readonly pageHint: "cardapioEstoque";
                    readonly outcome: "Quantidade atualizada";
                }, {
                    readonly intent: "Ajustar estoque por contagem";
                    readonly action: "Corrige quantidade após contagem física";
                    readonly entities: readonly ["StockItem", "StockMovement"];
                    readonly pageHint: "cardapioEstoque";
                    readonly outcome: "Estoque reconciliado";
                }, {
                    readonly intent: "Tratar alerta de estoque baixo";
                    readonly action: "Abre alerta e define reposição ou marca indisponível";
                    readonly entities: readonly ["LowStockAlert", "StockItem"];
                    readonly pageHint: "cardapioEstoque";
                    readonly outcome: "Alerta resolvido e item ajustado";
                }];
            }, {
                readonly journeyId: "fecharTurnoDiario";
                readonly title: "Fechar turno diário";
                readonly actor: "gerente";
                readonly capabilityIds: readonly ["fecharTurno"];
                readonly description: "O gerente fecha o turno após garantir que não há pedidos abertos e gera relatório.";
                readonly steps: readonly [{
                    readonly intent: "Iniciar fechamento do turno";
                    readonly action: "Acessa o relatório de fechamento de turno";
                    readonly entities: readonly ["Shift"];
                    readonly pageHint: "fechamentoTurno";
                    readonly outcome: "Turno em status emFechamento";
                }, {
                    readonly intent: "Validar pedidos finalizados";
                    readonly action: "Confere lista de pedidos do turno";
                    readonly entities: readonly ["Order", "Shift"];
                    readonly pageHint: "fechamentoTurno";
                    readonly outcome: "Pedidos verificados para fechamento";
                }, {
                    readonly intent: "Bloqueio por pedidos abertos";
                    readonly action: "Tenta fechar e recebe aviso de pedidos não finalizados";
                    readonly entities: readonly ["Order", "Shift"];
                    readonly pageHint: "fechamentoTurno";
                    readonly outcome: "Fechamento impedido até finalizar pedidos";
                }, {
                    readonly intent: "Confirmar fechamento";
                    readonly action: "Finaliza o turno e gera relatório";
                    readonly entities: readonly ["Shift", "ShiftReport"];
                    readonly pageHint: "fechamentoTurno";
                    readonly outcome: "Turno fechado e relatório disponível";
                }];
            }, {
                readonly journeyId: "consultarDashboardGerente";
                readonly title: "Consultar dashboard do gerente";
                readonly actor: "gerente";
                readonly capabilityIds: readonly ["consultarDashboard"];
                readonly description: "O gerente acompanha métricas operacionais e de vendas em um dashboard.";
                readonly steps: readonly [{
                    readonly intent: "Abrir visão geral do dia";
                    readonly action: "Acessa o dashboard administrativo de métricas";
                    readonly entities: readonly ["Shift", "Order"];
                    readonly pageHint: "dashboardGerente";
                    readonly outcome: "Métricas do dia carregadas";
                }, {
                    readonly intent: "Analisar itens mais vendidos";
                    readonly action: "Aplica filtro de itens mais vendidos";
                    readonly entities: readonly ["MenuItem", "OrderItem"];
                    readonly pageHint: "dashboardGerente";
                    readonly outcome: "Ranking de itens exibido";
                }, {
                    readonly intent: "Monitorar estoque baixo";
                    readonly action: "Consulta o painel de alertas de estoque";
                    readonly entities: readonly ["LowStockAlert", "StockItem"];
                    readonly pageHint: "dashboardGerente";
                    readonly outcome: "Alertas visíveis para ação";
                }];
            }];
        };
    };
    export default userJourneysPlan;
}
declare module "_102043_/l5/cafeFlow/module.defs" {
    export const modulePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "module";
        readonly artifactId: "cafeFlow";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentFinalizeSolutionPlan";
            readonly stepId: 11;
            readonly planId: "plan-finalize-solution-plan";
        };
        readonly data: {
            readonly module: {
                readonly moduleName: "cafeFlow";
                readonly purpose: "Agilizar o atendimento de pedidos, coordenação de cozinha e controle simples de estoque para cafeterias e lanchonetes pequenas.";
                readonly businessDomain: "Food service para cafeterias e lanchonetes pequenas";
                readonly languages: readonly ["pt-BR", "en"];
                readonly visualStyle: {
                    readonly tone: "Moderno e minimalista";
                    readonly layout: "Alta legibilidade e uso rápido em POS e cozinha";
                    readonly palette: readonly ["#1F2937", "#F9FAFB", "#F59E0B", "#10B981"];
                };
            };
            readonly actors: readonly [{
                readonly actorId: "atendente";
                readonly title: "Atendente";
                readonly description: "Registra pedidos no POS e acompanha status do pedido.";
            }, {
                readonly actorId: "cozinha";
                readonly title: "Cozinha";
                readonly description: "Atualiza o status de preparo dos pedidos e acompanha fila.";
            }, {
                readonly actorId: "gerente";
                readonly title: "Gerente";
                readonly description: "Gerencia cardápio, estoque, turnos e acompanha métricas e relatórios.";
            }];
            readonly capabilities: readonly [{
                readonly capabilityId: "registrarPedido";
                readonly title: "Registrar pedido no POS";
                readonly description: "Lançar pedido para mesa ou takeout com itens do cardápio.";
                readonly actor: "atendente";
                readonly priority: "now";
            }, {
                readonly capabilityId: "atualizarStatusCozinha";
                readonly title: "Atualizar status de cozinha";
                readonly description: "Mover pedido por estados de preparo até pronto/entregue.";
                readonly actor: "cozinha";
                readonly priority: "now";
            }, {
                readonly capabilityId: "gerenciarCardapio";
                readonly title: "Gerenciar cardápio";
                readonly description: "Criar e atualizar itens do cardápio, categorias, preços e ingredientes.";
                readonly actor: "gerente";
                readonly priority: "now";
            }, {
                readonly capabilityId: "gerenciarEstoque";
                readonly title: "Gerenciar estoque";
                readonly description: "Controlar itens de estoque e sinalizar baixo estoque.";
                readonly actor: "gerente";
                readonly priority: "now";
            }, {
                readonly capabilityId: "fecharTurno";
                readonly title: "Fechar turno diário";
                readonly description: "Consolidar vendas e gerar relatório de fechamento do turno.";
                readonly actor: "gerente";
                readonly priority: "now";
            }, {
                readonly capabilityId: "consultarDashboard";
                readonly title: "Consultar dashboard";
                readonly description: "Ver vendas de hoje, itens mais vendidos e estoque baixo.";
                readonly actor: "gerente";
                readonly priority: "now";
            }, {
                readonly capabilityId: "usarAssistenteIA";
                readonly title: "Usar assistente IA";
                readonly description: "Gerar resumo de vendas do dia e sugestões de itens para promoção com base nos últimos 7 dias.";
                readonly actor: "gerente";
                readonly priority: "soon";
            }];
            readonly ontology: {
                readonly entities: {
                    readonly MenuItem: {
                        readonly title: "Item do Cardápio";
                        readonly description: "Produto vendido no POS com preço, categoria e vínculo de ingredientes.";
                        readonly ownership: "mdmOwned";
                    };
                    readonly MenuCategory: {
                        readonly title: "Categoria de Cardápio";
                        readonly description: "Agrupamento de itens do cardápio para organização e filtros.";
                        readonly ownership: "mdmOwned";
                    };
                    readonly StockItem: {
                        readonly title: "Item de Estoque";
                        readonly description: "Insumo controlado com unidade e nível mínimo.";
                        readonly ownership: "mdmOwned";
                    };
                    readonly UnitOfMeasure: {
                        readonly title: "Unidade de Medida";
                        readonly description: "Unidade usada nos itens de estoque e receitas.";
                        readonly ownership: "mdmOwned";
                    };
                    readonly ShiftConfig: {
                        readonly title: "Configuração de Turno";
                        readonly description: "Parâmetros e horários de turnos usados no fechamento diário.";
                        readonly ownership: "mdmOwned";
                    };
                    readonly Order: {
                        readonly title: "Pedido";
                        readonly description: "Compromisso de venda para mesa ou takeout com itens e status.";
                        readonly ownership: "moduleOwned";
                    };
                    readonly OrderItem: {
                        readonly title: "Item do Pedido";
                        readonly description: "Linha do pedido com item do cardápio e quantidade.";
                        readonly ownership: "moduleOwned";
                    };
                    readonly OrderStatusHistory: {
                        readonly title: "Histórico de Status do Pedido";
                        readonly description: "Registro de transições de status para rastreio de cozinha.";
                        readonly ownership: "moduleOwned";
                    };
                    readonly Shift: {
                        readonly title: "Turno Diário";
                        readonly description: "Período operacional com abertura e fechamento.";
                        readonly ownership: "moduleOwned";
                    };
                    readonly ShiftReport: {
                        readonly title: "Relatório de Fechamento de Turno";
                        readonly description: "Consolidação de vendas e indicadores do turno.";
                        readonly ownership: "moduleOwned";
                    };
                    readonly StockMovement: {
                        readonly title: "Movimentação de Estoque";
                        readonly description: "Entrada, saída e ajuste de estoque vinculado a itens e pedidos.";
                        readonly ownership: "moduleOwned";
                    };
                    readonly LowStockAlert: {
                        readonly title: "Alerta de Estoque Baixo";
                        readonly description: "Sinalização de itens abaixo do nível mínimo.";
                        readonly ownership: "moduleOwned";
                    };
                    readonly SalesSummaryRequest: {
                        readonly title: "Solicitação de Resumo de Vendas";
                        readonly description: "Pedido de geração de resumo e recomendações via IA.";
                        readonly ownership: "moduleOwned";
                    };
                };
            };
            readonly relationships: readonly [{
                readonly relationshipId: "menuItemBelongsToCategory";
                readonly fromEntity: "MenuItem";
                readonly toEntity: "MenuCategory";
                readonly type: "manyToOne";
                readonly description: "Item do cardápio pertence a uma categoria.";
            }, {
                readonly relationshipId: "menuItemUsesStockItem";
                readonly fromEntity: "MenuItem";
                readonly toEntity: "StockItem";
                readonly type: "manyToMany";
                readonly description: "Item do cardápio referencia ingredientes em estoque.";
            }, {
                readonly relationshipId: "orderHasItems";
                readonly fromEntity: "Order";
                readonly toEntity: "OrderItem";
                readonly type: "oneToMany";
                readonly description: "Pedido contém itens de pedido.";
            }, {
                readonly relationshipId: "orderItemReferencesMenuItem";
                readonly fromEntity: "OrderItem";
                readonly toEntity: "MenuItem";
                readonly type: "manyToOne";
                readonly description: "Item do pedido referencia item do cardápio.";
            }, {
                readonly relationshipId: "orderHasStatusHistory";
                readonly fromEntity: "Order";
                readonly toEntity: "OrderStatusHistory";
                readonly type: "oneToMany";
                readonly description: "Pedido possui histórico de status.";
            }, {
                readonly relationshipId: "stockMovementForStockItem";
                readonly fromEntity: "StockMovement";
                readonly toEntity: "StockItem";
                readonly type: "manyToOne";
                readonly description: "Movimentação associada a um item de estoque.";
            }, {
                readonly relationshipId: "stockMovementLinkedToOrder";
                readonly fromEntity: "StockMovement";
                readonly toEntity: "Order";
                readonly type: "manyToOne";
                readonly description: "Saídas de estoque podem ser vinculadas a pedidos.";
            }, {
                readonly relationshipId: "shiftHasOrders";
                readonly fromEntity: "Shift";
                readonly toEntity: "Order";
                readonly type: "oneToMany";
                readonly description: "Pedidos são registrados dentro de um turno.";
            }, {
                readonly relationshipId: "shiftHasReport";
                readonly fromEntity: "Shift";
                readonly toEntity: "ShiftReport";
                readonly type: "oneToOne";
                readonly description: "Relatório consolidado por turno.";
            }, {
                readonly relationshipId: "alertForStockItem";
                readonly fromEntity: "LowStockAlert";
                readonly toEntity: "StockItem";
                readonly type: "manyToOne";
                readonly description: "Alerta aponta o item de estoque em ruptura.";
            }, {
                readonly relationshipId: "salesSummaryUsesMetrics";
                readonly fromEntity: "SalesSummaryRequest";
                readonly toEntity: "ShiftReport";
                readonly type: "manyToOne";
                readonly description: "Solicitação de resumo referencia consolidações de vendas.";
            }, {
                readonly relationshipId: "stockItemUsesUnitOfMeasure";
                readonly fromEntity: "StockItem";
                readonly toEntity: "UnitOfMeasure";
                readonly type: "manyToOne";
                readonly description: "Item de estoque usa unidade de medida padronizada.";
            }, {
                readonly relationshipId: "shiftUsesConfig";
                readonly fromEntity: "Shift";
                readonly toEntity: "ShiftConfig";
                readonly type: "manyToOne";
                readonly description: "Turno utiliza configurações de horário e parâmetros operacionais.";
            }];
        };
    };
    export default modulePlan;
}
declare module "_102043_/l5/cafeFlow/process.defs" {
    export const cafeFlowProcess: {
        readonly schemaVersion: "2026-06-08";
        readonly moduleName: "cafeFlow";
        readonly runs: readonly [{
            readonly runId: "newSolution";
            readonly kind: "newSolution";
            readonly startedAt: "2026-06-13T12:56:48.046Z";
            readonly initialPrompt: "Gere um app profissional chamado CafeFlow para cafeterias e lanchonetes pequenas.\nEntidades principais: Item do Cardápio (categoria, preço, ingredientes em estoque), Pedido (mesa ou takeout, itens, status), Turno Diário, Item de Estoque.\nTelas chave: Dashboard (vendas de hoje, itens mais vendidos, estoque baixo), Interface rápida de POS (lançamento de pedido + status cozinha), Gerenciamento de cardápio e estoque, Relatório de fechamento de turno.\nFuncionalidade LLM: Assistente IA que gera \"resumo de vendas do dia\" ou sugere \"quais itens promover com base nos últimos 7 dias\".\nFoco: Atendimento rápido de pedidos, coordenação de cozinha e controle simples de estoque para food service.\nlinguagem: en, pt-br";
            readonly userLanguage: "pt-BR";
            readonly decisions: readonly [{
                readonly decisionId: "addMissingRelationships";
                readonly title: "Adicionar relacionamentos faltantes de MDM";
                readonly decision: "Incluídos relacionamentos StockItem→UnitOfMeasure e Shift→ShiftConfig.";
                readonly reason: "Correção dos erros missing_relationship identificados na revisão do blueprint.";
                readonly affectedArtifacts: readonly ["stockItemMdm", "shiftConfigMdm"];
                readonly revisedBy: "agentPlanMDM";
                readonly revisedAt: "2026-06-13T12:56:48.046Z";
                readonly revisedScope: {
                    readonly mdmDomains: readonly [{
                        readonly domainId: "menu";
                        readonly masterEntities: readonly ["MenuItem", "MenuCategory"];
                    }, {
                        readonly domainId: "stock";
                        readonly masterEntities: readonly ["StockItem", "UnitOfMeasure"];
                    }, {
                        readonly domainId: "shiftConfig";
                        readonly masterEntities: readonly ["ShiftConfig"];
                    }];
                };
            }, {
                readonly decisionId: "addMenuUsecaseEntity";
                readonly title: "Adicionar entidade de caso de uso para cardápio";
                readonly decision: "Incluída menuUsecaseEntity para cobrir comandos de escrita do cardápio.";
                readonly reason: "Correção do erro missing_layer3_usecase para a capacidade gerenciarCardapio apontado na revisão.";
                readonly affectedArtifacts: readonly ["menuUsecaseEntity"];
            }, {
                readonly decisionId: "linkOrderToStockMovement";
                readonly title: "Vincular criação de pedido a movimentação de estoque";
                readonly decision: "createOrder passou a afetar StockMovement e aplicar lowStockThresholdRule.";
                readonly reason: "Correção do aviso de falta de vínculo entre pedido e consumo de estoque na revisão.";
                readonly affectedArtifacts: readonly ["orderUsecaseEntity"];
            }, {
                readonly decisionId: "addSalesSummaryUsecaseEntity";
                readonly title: "Adicionar entidade de caso de uso para resumo de vendas";
                readonly decision: "Incluída salesSummaryUsecaseEntity para a solicitação de resumo via IA.";
                readonly reason: "Correção do aviso missing_layer3_usecase para requestSalesSummary na revisão.";
                readonly affectedArtifacts: readonly ["salesSummaryUsecaseEntity"];
            }];
            readonly deferredItems: readonly [];
            readonly openDetails: readonly [{
                readonly title: "Impressão de comandas";
                readonly description: "O sistema deve suportar impressão térmica de comandas para a cozinha ou apenas exibição em tela?";
            }, {
                readonly title: "Multi-dispositivo e sincronização";
                readonly description: "O POS deve permitir múltiplos tablets simultâneos com sincronização em tempo real dos pedidos?";
            }, {
                readonly title: "Provedor e modelo de LLM";
                readonly description: "Qual provedor/modelo de IA será utilizado para o assistente de resumo de vendas e sugestões promocionais?";
            }];
            readonly healthReport: {
                readonly summary: {
                    readonly passed: true;
                    readonly errorCount: 0;
                    readonly warningCount: 1;
                };
                readonly issues: readonly [{
                    readonly severity: "warning";
                    readonly code: "usecase.consumer.missing";
                    readonly message: "usecase obterPedido has no consumer (no page BFF command, workflow or agent references it)";
                    readonly path: "usecase.obterPedido";
                    readonly evidence: readonly [];
                }];
                readonly checklistResults: any;
                readonly readyToSaveDefs: true;
                readonly deterministicOnly: true;
                readonly refreshedAt: "2026-06-13T12:56:48.157Z";
                readonly refreshedBy: "agentNewSolutionFinal (T-016 deterministic re-validation)";
            };
            readonly nextSteps: readonly [{
                readonly id: "horizontalModule:notifications";
                readonly kind: "horizontalModule";
                readonly title: "notifications";
                readonly description: "Alertas de estoque baixo e avisos operacionais precisam de comunicação ao gerente conforme workflow de alerta.";
                readonly moduleId: "notifications";
                readonly status: "dismissed";
            }, {
                readonly id: "plugin:llmSalesAssistant";
                readonly kind: "plugin";
                readonly title: "llmSalesAssistant";
                readonly description: "Necessário para executar o assistente IA de vendas previsto para a fase soon.";
                readonly pluginId: "llmSalesAssistant";
                readonly status: "dismissed";
            }];
            readonly finishedAt: "2026-06-13T14:49:58.312Z";
        }];
    };
    export default cafeFlowProcess;
}
declare module "_102043_/l5/cafeFlow/rules.defs" {
    export const rulesPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "rules";
        readonly artifactId: "cafeFlowRules";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentFinalizeSolutionPlan";
            readonly stepId: 11;
            readonly planId: "plan-finalize-solution-plan";
        };
        readonly data: {
            readonly moduleName: "cafeFlow";
            readonly rules: readonly [{
                readonly ruleId: "orderStatusTransition";
                readonly title: "Transições válidas de status do pedido";
                readonly description: "Pedidos seguem o fluxo Recebido → Em preparo → Pronto → Entregue, podendo cancelar antes de Entregue.";
                readonly appliesTo: readonly ["Order", "OrderStatusHistory"];
                readonly layer: "layer_1";
            }, {
                readonly ruleId: "orderRequiresItem";
                readonly title: "Pedido deve ter itens";
                readonly description: "Um pedido só pode ser confirmado se houver ao menos um item.";
                readonly appliesTo: readonly ["Order", "OrderItem"];
                readonly layer: "layer_1";
            }, {
                readonly ruleId: "shiftClosureRequiresNoOpenOrders";
                readonly title: "Fechamento de turno exige pedidos finalizados";
                readonly description: "Não permitir fechar turno com pedidos em Recebido ou Em preparo.";
                readonly appliesTo: readonly ["Shift", "Order"];
                readonly layer: "layer_3";
            }, {
                readonly ruleId: "lowStockThresholdRule";
                readonly title: "Regra de estoque baixo";
                readonly description: "Gerar alerta quando nível de estoque ficar abaixo do mínimo definido.";
                readonly appliesTo: readonly ["StockItem", "LowStockAlert", "StockMovement"];
                readonly layer: "layer_3";
            }, {
                readonly ruleId: "salesSummaryUsesLast7Days";
                readonly title: "Resumo de vendas usa últimos 7 dias";
                readonly description: "Resumo e sugestões devem considerar métricas dos últimos 7 dias.";
                readonly appliesTo: readonly ["SalesSummaryRequest"];
                readonly layer: "layer_3";
            }, {
                readonly ruleId: "menuItemRequiresCategory";
                readonly title: "Item do cardápio deve ter categoria";
                readonly description: "Todo item do cardápio deve estar associado a uma categoria ativa.";
                readonly appliesTo: readonly ["MenuItem", "MenuCategory"];
                readonly layer: "layer_1";
            }];
        };
    };
    export default rulesPlan;
}
declare module "_102043_/l5/cafeFlow/uiConsolidation.defs" {
    export const uiConsolidationPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "uiConsolidation";
        readonly artifactId: "uiConsolidation";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUiConsolidation";
            readonly stepId: 28;
            readonly planId: "plan-ui-consolidation";
        };
        readonly data: {
            readonly sharedComponents: readonly [{
                readonly componentId: "lowStockAlertsList";
                readonly title: "Lista de alertas de estoque baixo";
                readonly kind: "organism";
                readonly pages: readonly ["cardapioEstoque", "dashboardGerente"];
                readonly replacesOrganisms: readonly ["cardapioEstoque.AlertasEstoqueBaixo", "dashboardGerente.ListaAlertasEstoqueBaixo"];
                readonly responsibilities: "Exibir alertas ativos de estoque baixo com possibilidade de filtrar e ver detalhes.";
            }];
            readonly namingFixes: readonly [{
                readonly pageId: "cardapioEstoque";
                readonly organismName: "FiltroEListaItensCardapio";
                readonly suggestedName: "filtroEListaItensCardapio";
                readonly reason: "Padronizar para camelCase.";
            }, {
                readonly pageId: "cardapioEstoque";
                readonly organismName: "CadastroEdicaoItemCardapio";
                readonly suggestedName: "cadastroEdicaoItemCardapio";
                readonly reason: "Padronizar para camelCase.";
            }, {
                readonly pageId: "cardapioEstoque";
                readonly organismName: "ListaCategoriasCardapio";
                readonly suggestedName: "listaCategoriasCardapio";
                readonly reason: "Padronizar para camelCase.";
            }, {
                readonly pageId: "cardapioEstoque";
                readonly organismName: "FiltroEListaItensEstoque";
                readonly suggestedName: "filtroEListaItensEstoque";
                readonly reason: "Padronizar para camelCase.";
            }, {
                readonly pageId: "cardapioEstoque";
                readonly organismName: "CadastroEdicaoItemEstoque";
                readonly suggestedName: "cadastroEdicaoItemEstoque";
                readonly reason: "Padronizar para camelCase.";
            }, {
                readonly pageId: "cardapioEstoque";
                readonly organismName: "RegistroMovimentacaoEstoque";
                readonly suggestedName: "registroMovimentacaoEstoque";
                readonly reason: "Padronizar para camelCase.";
            }, {
                readonly pageId: "cardapioEstoque";
                readonly organismName: "HistoricoMovimentacoesEstoque";
                readonly suggestedName: "historicoMovimentacoesEstoque";
                readonly reason: "Padronizar para camelCase.";
            }, {
                readonly pageId: "cardapioEstoque";
                readonly organismName: "AlertasEstoqueBaixo";
                readonly suggestedName: "alertasEstoqueBaixo";
                readonly reason: "Padronizar para camelCase.";
            }, {
                readonly pageId: "dashboardGerente";
                readonly organismName: "ResumoVendasDiarias";
                readonly suggestedName: "resumoVendasDiarias";
                readonly reason: "Padronizar para camelCase.";
            }, {
                readonly pageId: "dashboardGerente";
                readonly organismName: "GraficoVendasPorTurno";
                readonly suggestedName: "graficoVendasPorTurno";
                readonly reason: "Padronizar para camelCase.";
            }, {
                readonly pageId: "dashboardGerente";
                readonly organismName: "RankingItensMaisVendidos";
                readonly suggestedName: "rankingItensMaisVendidos";
                readonly reason: "Padronizar para camelCase.";
            }, {
                readonly pageId: "dashboardGerente";
                readonly organismName: "ListaAlertasEstoqueBaixo";
                readonly suggestedName: "listaAlertasEstoqueBaixo";
                readonly reason: "Padronizar para camelCase.";
            }, {
                readonly pageId: "fechamentoTurno";
                readonly organismName: "Seletor de turno";
                readonly suggestedName: "seletorTurno";
                readonly reason: "Remover espaços e padronizar para camelCase.";
            }, {
                readonly pageId: "fechamentoTurno";
                readonly organismName: "Lista de pedidos do turno";
                readonly suggestedName: "listaPedidosTurno";
                readonly reason: "Remover espaços e padronizar para camelCase.";
            }, {
                readonly pageId: "fechamentoTurno";
                readonly organismName: "Resumo de fechamento";
                readonly suggestedName: "resumoFechamento";
                readonly reason: "Remover espaços e padronizar para camelCase.";
            }, {
                readonly pageId: "fechamentoTurno";
                readonly organismName: "Confirmar fechamento";
                readonly suggestedName: "confirmarFechamento";
                readonly reason: "Remover espaços e padronizar para camelCase.";
            }, {
                readonly pageId: "painelCozinha";
                readonly organismName: "ListaDePedidosCozinha";
                readonly suggestedName: "listaPedidosCozinha";
                readonly reason: "Padronizar para camelCase.";
            }, {
                readonly pageId: "painelCozinha";
                readonly organismName: "AtualizarStatusPedido";
                readonly suggestedName: "atualizarStatusPedido";
                readonly reason: "Padronizar para camelCase.";
            }, {
                readonly pageId: "posRapido";
                readonly organismName: "Lista de pedidos do dia";
                readonly suggestedName: "listaPedidosDia";
                readonly reason: "Remover espaços e padronizar para camelCase.";
            }, {
                readonly pageId: "posRapido";
                readonly organismName: "Editor rápido de itens";
                readonly suggestedName: "editorRapidoItens";
                readonly reason: "Remover espaços e padronizar para camelCase.";
            }, {
                readonly pageId: "posRapido";
                readonly organismName: "Resumo e envio para cozinha";
                readonly suggestedName: "resumoEnvioCozinha";
                readonly reason: "Remover espaços e padronizar para camelCase.";
            }];
            readonly notes: readonly ["Consolidar os alertas de estoque baixo em um único organismo compartilhado entre cardápio/estoque e dashboard.", "Demais organismos mantidos por diferenças de contexto e entidades."];
        };
    };
    export default uiConsolidationPlan;
}
declare module "_102043_/l5/cafeFlow/ontology/LowStockAlert.defs" {
    export const LowStockAlertEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "LowStockAlert";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 40;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "LowStockAlert";
                readonly title: "Alerta de Estoque Baixo";
                readonly description: "Sinalização de itens abaixo do nível mínimo.";
                readonly ownership: "moduleOwned";
                readonly kind: "event";
                readonly fields: readonly [{
                    readonly fieldId: "lowStockAlertId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do alerta de estoque baixo.";
                }, {
                    readonly fieldId: "stockItemId";
                    readonly type: "StockItem";
                    readonly required: true;
                    readonly description: "Item de estoque associado ao alerta.";
                }, {
                    readonly fieldId: "triggeredAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora em que o alerta foi gerado.";
                }, {
                    readonly fieldId: "currentQuantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade atual do item quando o alerta foi gerado.";
                }, {
                    readonly fieldId: "minimumQuantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade mínima configurada para o item.";
                }, {
                    readonly fieldId: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Situação atual do alerta.";
                    readonly enum: readonly ["ativo", "resolvido", "ignorado"];
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly statusEnum: readonly ["ativo", "resolvido", "ignorado"];
                readonly lifecycleStates: readonly ["ativo", "resolvido", "ignorado"];
                readonly rulesApplied: readonly ["lowStockThresholdRule"];
            };
        };
    };
    export default LowStockAlertEntityDefinition;
}
declare module "_102043_/l5/cafeFlow/ontology/MenuCategory.defs" {
    export const MenuCategoryEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "MenuCategory";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 39;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "MenuCategory";
                readonly title: "Categoria de Cardápio";
                readonly description: "Agrupamento de itens do cardápio para organização e filtros.";
                readonly ownership: "mdmOwned";
                readonly fields: readonly [{
                    readonly fieldId: "menuCategoryId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único da categoria de cardápio.";
                }, {
                    readonly fieldId: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Nome da categoria exibido no cardápio e filtros.";
                }, {
                    readonly fieldId: "description";
                    readonly type: "text";
                    readonly required: false;
                    readonly description: "Descrição opcional da categoria.";
                }, {
                    readonly fieldId: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Estado da categoria para uso no cardápio.";
                    readonly enum: readonly ["ativa", "inativa"];
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly statusEnum: readonly ["ativa", "inativa"];
                readonly rulesApplied: readonly ["menuItemRequiresCategory"];
            };
        };
    };
    export default MenuCategoryEntityDefinition;
}
declare module "_102043_/l5/cafeFlow/ontology/MenuItem.defs" {
    export const MenuItemEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "MenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "incomplete";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 38;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "MenuItem";
                readonly title: "Item do Cardápio";
                readonly description: "Produto vendido no POS com preço, categoria e vínculo de ingredientes.";
                readonly ownership: "mdmOwned";
                readonly kind: "master";
                readonly fields: readonly [{
                    readonly fieldId: "menuItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do item do cardápio.";
                }, {
                    readonly fieldId: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Nome do item do cardápio.";
                }, {
                    readonly fieldId: "description";
                    readonly type: "text";
                    readonly required: false;
                    readonly description: "Descrição do item do cardápio.";
                }, {
                    readonly fieldId: "price";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Preço de venda do item do cardápio.";
                }, {
                    readonly fieldId: "menuCategoryId";
                    readonly type: "MenuCategory";
                    readonly required: true;
                    readonly description: "Categoria à qual o item do cardápio pertence.";
                }, {
                    readonly fieldId: "isActive";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly description: "Indica se o item do cardápio está ativo para venda.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do item do cardápio.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do item do cardápio.";
                }];
                readonly rulesApplied: readonly ["menuItemRequiresCategory"];
            };
            readonly pendingQuestions: readonly ["Como devemos modelar o relacionamento many-to-many entre MenuItem e StockItem: existe uma entidade de junção (por exemplo, MenuItemStockItem) ou devemos usar um campo multi-valor (array) de referências? Caso exista a entidade de junção, qual é o entityId correto?", "Existe algum status/lifecycle específico para MenuItem além de isActive (por exemplo, rascunho/ativo/inativo)?"];
        };
    };
    export default MenuItemEntityDefinition;
}
declare module "_102043_/l5/cafeFlow/ontology/Order.defs" {
    export const OrderEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 42;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "Order";
                readonly title: "Pedido";
                readonly description: "Compromisso de venda para mesa ou takeout com itens e status.";
                readonly ownership: "moduleOwned";
                readonly fields: readonly [{
                    readonly fieldId: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do pedido.";
                }, {
                    readonly fieldId: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status atual do pedido.";
                    readonly enum: readonly ["recebido", "emPreparo", "pronto", "entregue", "cancelado"];
                }, {
                    readonly fieldId: "shiftId";
                    readonly type: "Shift";
                    readonly required: true;
                    readonly description: "Turno em que o pedido foi registrado.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do pedido.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do pedido.";
                }];
                readonly statusEnum: readonly ["recebido", "emPreparo", "pronto", "entregue", "cancelado"];
                readonly rulesApplied: readonly ["orderStatusTransition", "orderRequiresItem", "shiftClosureRequiresNoOpenOrders"];
            };
        };
    };
    export default OrderEntityDefinition;
}
declare module "_102043_/l5/cafeFlow/ontology/OrderItem.defs" {
    export const OrderItemEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "OrderItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 39;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "OrderItem";
                readonly title: "Item do Pedido";
                readonly description: "Linha do pedido com item do cardápio e quantidade.";
                readonly ownership: "moduleOwned";
                readonly fields: readonly [{
                    readonly fieldId: "orderItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do item do pedido.";
                }, {
                    readonly fieldId: "orderId";
                    readonly type: "Order";
                    readonly required: true;
                    readonly description: "Referência ao pedido ao qual este item pertence.";
                }, {
                    readonly fieldId: "menuItemId";
                    readonly type: "MenuItem";
                    readonly required: true;
                    readonly description: "Referência ao item do cardápio solicitado.";
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade solicitada do item do cardápio.";
                }, {
                    readonly fieldId: "unitPrice";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Preço unitário do item no momento do pedido.";
                }, {
                    readonly fieldId: "totalPrice";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Preço total do item (unitPrice x quantity).";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do item do pedido.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do item do pedido.";
                }];
                readonly rulesApplied: readonly ["orderRequiresItem"];
            };
        };
    };
    export default OrderItemEntityDefinition;
}
declare module "_102043_/l5/cafeFlow/ontology/OrderStatusHistory.defs" {
    export const OrderStatusHistoryEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "OrderStatusHistory";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 40;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "OrderStatusHistory";
                readonly title: "Histórico de Status do Pedido";
                readonly description: "Registro de transições de status para rastreio de cozinha.";
                readonly ownership: "moduleOwned";
                readonly fields: readonly [{
                    readonly fieldId: "orderStatusHistoryId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do histórico de status do pedido.";
                }, {
                    readonly fieldId: "orderId";
                    readonly type: "Order";
                    readonly required: true;
                    readonly description: "Referência ao pedido relacionado a este registro de status.";
                }, {
                    readonly fieldId: "fromStatus";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status anterior do pedido antes da transição.";
                    readonly enum: readonly ["Recebido", "Em preparo", "Pronto", "Entregue", "Cancelado"];
                }, {
                    readonly fieldId: "toStatus";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Novo status do pedido após a transição.";
                    readonly enum: readonly ["Recebido", "Em preparo", "Pronto", "Entregue", "Cancelado"];
                }, {
                    readonly fieldId: "changedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora em que a transição de status ocorreu.";
                }, {
                    readonly fieldId: "changedBy";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Identificador ou nome do colaborador que efetuou a mudança de status.";
                }, {
                    readonly fieldId: "note";
                    readonly type: "text";
                    readonly required: false;
                    readonly description: "Observação sobre a mudança de status, se aplicável.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly rulesApplied: readonly ["orderStatusTransition"];
            };
        };
    };
    export default OrderStatusHistoryEntityDefinition;
}
declare module "_102043_/l5/cafeFlow/ontology/SalesSummaryRequest.defs" {
    export const SalesSummaryRequestEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "SalesSummaryRequest";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 42;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "SalesSummaryRequest";
                readonly title: "Solicitação de Resumo de Vendas";
                readonly description: "Pedido de geração de resumo e recomendações via IA.";
                readonly ownership: "moduleOwned";
                readonly fields: readonly [{
                    readonly fieldId: "salesSummaryRequestId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único da solicitação de resumo de vendas.";
                }, {
                    readonly fieldId: "shiftReportId";
                    readonly type: "ShiftReport";
                    readonly required: true;
                    readonly description: "Referência à consolidação de vendas usada na solicitação.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação da solicitação.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização da solicitação.";
                }];
                readonly rulesApplied: readonly ["salesSummaryUsesLast7Days"];
            };
        };
    };
    export default SalesSummaryRequestEntityDefinition;
}
declare module "_102043_/l5/cafeFlow/ontology/Shift.defs" {
    export const ShiftEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "Shift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 41;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "Shift";
                readonly title: "Turno Diário";
                readonly description: "Período operacional com abertura e fechamento.";
                readonly ownership: "moduleOwned";
                readonly fields: readonly [{
                    readonly fieldId: "shiftId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do turno.";
                }, {
                    readonly fieldId: "shiftConfigId";
                    readonly type: "ShiftConfig";
                    readonly required: true;
                    readonly description: "Configuração de turno aplicada ao período operacional.";
                }, {
                    readonly fieldId: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status atual do turno.";
                    readonly enum: readonly ["aberto", "emFechamento", "fechado"];
                }, {
                    readonly fieldId: "openedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de abertura do turno.";
                }, {
                    readonly fieldId: "closedAt";
                    readonly type: "datetime";
                    readonly required: false;
                    readonly description: "Data e hora de fechamento do turno.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly statusEnum: readonly ["aberto", "emFechamento", "fechado"];
                readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
            };
        };
    };
    export default ShiftEntityDefinition;
}
declare module "_102043_/l5/cafeFlow/ontology/ShiftConfig.defs" {
    export const ShiftConfigEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "ShiftConfig";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 42;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "ShiftConfig";
                readonly title: "Configuração de Turno";
                readonly description: "Parâmetros e horários de turnos usados no fechamento diário.";
                readonly ownership: "mdmOwned";
                readonly fields: readonly [{
                    readonly fieldId: "shiftConfigId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único da configuração de turno.";
                }, {
                    readonly fieldId: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Nome da configuração de turno.";
                }, {
                    readonly fieldId: "startTime";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Horário de início do turno (HH:mm).";
                }, {
                    readonly fieldId: "endTime";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Horário de término do turno (HH:mm).";
                }, {
                    readonly fieldId: "gracePeriodMinutes";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Minutos de tolerância para abertura/fechamento do turno.";
                }, {
                    readonly fieldId: "breakMinutes";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Duração do intervalo padrão do turno em minutos.";
                }, {
                    readonly fieldId: "isActive";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly description: "Indica se a configuração está ativa para uso.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
            };
        };
    };
    export default ShiftConfigEntityDefinition;
}
declare module "_102043_/l5/cafeFlow/ontology/ShiftReport.defs" {
    export const ShiftReportEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "ShiftReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 38;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "ShiftReport";
                readonly title: "Relatório de Fechamento de Turno";
                readonly description: "Consolidação de vendas e indicadores do turno.";
                readonly ownership: "moduleOwned";
                readonly fields: readonly [{
                    readonly fieldId: "shiftReportId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do relatório de fechamento de turno.";
                }, {
                    readonly fieldId: "shiftId";
                    readonly type: "Shift";
                    readonly required: true;
                    readonly description: "Referência ao turno consolidado por este relatório.";
                }, {
                    readonly fieldId: "totalSalesAmount";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Total de vendas consolidadas no turno.";
                }, {
                    readonly fieldId: "totalOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade total de pedidos no turno.";
                }, {
                    readonly fieldId: "totalItems";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Quantidade total de itens vendidos no turno.";
                }, {
                    readonly fieldId: "notes";
                    readonly type: "text";
                    readonly required: false;
                    readonly description: "Observações adicionais do fechamento do turno.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do relatório.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do relatório.";
                }];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default ShiftReportEntityDefinition;
}
declare module "_102043_/l5/cafeFlow/ontology/StockItem.defs" {
    export const StockItemEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "StockItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 40;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "StockItem";
                readonly title: "Item de Estoque";
                readonly description: "Insumo controlado com unidade e nível mínimo.";
                readonly ownership: "mdmOwned";
                readonly fields: readonly [{
                    readonly fieldId: "stockItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do item de estoque.";
                }, {
                    readonly fieldId: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Nome do insumo em estoque.";
                }, {
                    readonly fieldId: "description";
                    readonly type: "text";
                    readonly required: false;
                    readonly description: "Descrição detalhada do insumo.";
                }, {
                    readonly fieldId: "unitOfMeasureId";
                    readonly type: "UnitOfMeasure";
                    readonly required: true;
                    readonly description: "Unidade de medida padronizada usada para o item.";
                }, {
                    readonly fieldId: "currentQuantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade atual disponível em estoque.";
                }, {
                    readonly fieldId: "minimumQuantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Nível mínimo de estoque para disparo de alerta.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly rulesApplied: readonly ["lowStockThresholdRule"];
            };
        };
    };
    export default StockItemEntityDefinition;
}
declare module "_102043_/l5/cafeFlow/ontology/StockMovement.defs" {
    export const StockMovementEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "StockMovement";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 39;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "StockMovement";
                readonly title: "Movimentação de Estoque";
                readonly description: "Entrada, saída e ajuste de estoque vinculado a itens e pedidos.";
                readonly ownership: "moduleOwned";
                readonly fields: readonly [{
                    readonly fieldId: "stockMovementId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único da movimentação de estoque.";
                }, {
                    readonly fieldId: "stockItemId";
                    readonly type: "StockItem";
                    readonly required: true;
                    readonly description: "Item de estoque associado à movimentação.";
                }, {
                    readonly fieldId: "orderId";
                    readonly type: "Order";
                    readonly required: false;
                    readonly description: "Pedido vinculado à saída de estoque, quando aplicável.";
                }, {
                    readonly fieldId: "movementType";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Tipo de movimentação realizada.";
                    readonly enum: readonly ["entrada", "saida", "ajuste"];
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade movimentada do item de estoque.";
                }, {
                    readonly fieldId: "reason";
                    readonly type: "text";
                    readonly required: false;
                    readonly description: "Motivo ou observação da movimentação, especialmente para ajustes.";
                }, {
                    readonly fieldId: "occurredAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora em que a movimentação ocorreu.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly rulesApplied: readonly ["lowStockThresholdRule"];
            };
        };
    };
    export default StockMovementEntityDefinition;
}
declare module "_102043_/l5/cafeFlow/ontology/UnitOfMeasure.defs" {
    export const UnitOfMeasureEntityDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "ontologyEntity";
        readonly artifactId: "UnitOfMeasure";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanEntityDefinition";
            readonly stepId: 41;
            readonly planId: "";
        };
        readonly data: {
            readonly entityDefinition: {
                readonly entityId: "UnitOfMeasure";
                readonly title: "Unidade de Medida";
                readonly description: "Unidade usada nos itens de estoque e receitas.";
                readonly ownership: "mdmOwned";
                readonly fields: readonly [{
                    readonly fieldId: "unitOfMeasureId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único da unidade de medida.";
                }, {
                    readonly fieldId: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Nome da unidade de medida.";
                }, {
                    readonly fieldId: "symbol";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Símbolo ou abreviação da unidade de medida.";
                }, {
                    readonly fieldId: "description";
                    readonly type: "text";
                    readonly required: false;
                    readonly description: "Descrição complementar da unidade de medida.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly rulesApplied: readonly [];
            };
        };
    };
    export default UnitOfMeasureEntityDefinition;
}
declare module "_102043_/l5/notifications/module.defs" {
    export const notificationsModulePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "horizontalModule";
        readonly artifactId: "notifications";
        readonly moduleName: "notifications";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanHorizontals";
            readonly stepId: 15;
            readonly planId: "plan-horizontals";
        };
        readonly data: {
            readonly kind: "horizontal";
            readonly moduleId: "notifications";
            readonly horizontalModuleId: "notifications";
            readonly plannedByModule: "cafeFlow";
            readonly referencesExisting: false;
            readonly module: {
                readonly horizontalModuleId: "notifications";
                readonly priority: "soon";
                readonly reason: "Alertas de estoque baixo e avisos operacionais precisam de comunicação ao gerente conforme workflow de alerta.";
                readonly reusedOntologyRefs: readonly [];
                readonly consumedByArtifacts: readonly ["lowStockAlertWorkflow"];
                readonly decidedPriority: "soon";
            };
        };
    };
    export default notificationsModulePlan;
}
