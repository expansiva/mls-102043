declare module "_102043_/l1/cafeFlow/layer_1_external/dailySalesMetrics.defs" {
    export const dailySalesMetricsTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "dailySalesMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 49;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "dailySalesMetrics";
                readonly tableName: "daily_sales_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Vendas diárias";
                readonly purpose: "Acompanhar faturamento, quantidade de pedidos e ticket médio por turno e dia para tomada de decisão do gerente.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "time";
                readonly columns: readonly [{
                    readonly name: "time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp de referência da métrica.";
                }, {
                    readonly name: "shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Turno em que o pedido foi realizado.";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do pedido no momento da métrica.";
                }, {
                    readonly name: "order_item_id";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "FK para item de pedido relacionado.";
                }, {
                    readonly name: "order_status_history_id";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "FK para histórico de status do pedido relacionado.";
                }, {
                    readonly name: "shift_report_id";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "FK para relatório de fechamento do turno.";
                }, {
                    readonly name: "shift_config_id";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "FK para configuração de turno utilizada.";
                }, {
                    readonly name: "total_revenue";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Receita total dos pedidos.";
                }, {
                    readonly name: "order_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de pedidos.";
                }, {
                    readonly name: "average_ticket";
                    readonly type: "numeric";
                    readonly nullable: true;
                    readonly description: "Ticket médio por pedido.";
                }, {
                    readonly name: "items_sold";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade total de itens vendidos.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "shiftId";
                    readonly column: "shift_id";
                    readonly type: "uuid";
                    readonly description: "Turno em que o pedido foi realizado.";
                }, {
                    readonly dimensionId: "orderStatus";
                    readonly column: "status";
                    readonly type: "string";
                    readonly description: "Status do pedido no momento da métrica.";
                }, {
                    readonly dimensionId: "orderItemId";
                    readonly column: "order_item_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship orderHasItems (Order -> OrderItem).";
                }, {
                    readonly dimensionId: "orderStatusHistoryId";
                    readonly column: "order_status_history_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship orderHasStatusHistory (Order -> OrderStatusHistory).";
                }, {
                    readonly dimensionId: "shiftReportId";
                    readonly column: "shift_report_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship shiftHasReport (Shift -> ShiftReport).";
                }, {
                    readonly dimensionId: "shiftConfigId";
                    readonly column: "shift_config_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship shiftUsesConfig (Shift -> ShiftConfig).";
                }];
                readonly measures: readonly [{
                    readonly measureId: "totalRevenue";
                    readonly column: "total_revenue";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Receita total dos pedidos.";
                }, {
                    readonly measureId: "orderCount";
                    readonly column: "order_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade de pedidos.";
                }, {
                    readonly measureId: "averageTicket";
                    readonly column: "average_ticket";
                    readonly aggregation: "avg";
                    readonly unit: "BRL";
                    readonly description: "Ticket médio por pedido.";
                }, {
                    readonly measureId: "itemsSold";
                    readonly column: "items_sold";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade total de itens vendidos.";
                }];
                readonly sourceWriteEvents: readonly ["orderCreated", "orderStatusUpdated", "shiftClosed"];
                readonly hypertable: {
                    readonly timeColumn: "time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_daily_sales_metrics_time";
                        readonly columns: readonly ["time"];
                        readonly purpose: "Consulta temporal por janela de agregação.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_shift_id_time";
                        readonly columns: readonly ["shift_id", "time"];
                        readonly purpose: "Filtro por turno e período.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_status_time";
                        readonly columns: readonly ["status", "time"];
                        readonly purpose: "Filtro por status e período.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_order_item_id";
                        readonly columns: readonly ["order_item_id"];
                        readonly purpose: "Lookup por item do pedido.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_order_status_history_id";
                        readonly columns: readonly ["order_status_history_id"];
                        readonly purpose: "Lookup por histórico de status.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_shift_report_id";
                        readonly columns: readonly ["shift_report_id"];
                        readonly purpose: "Lookup por relatório de turno.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_shift_config_id";
                        readonly columns: readonly ["shift_config_id"];
                        readonly purpose: "Lookup por configuração de turno.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["registrarPedido", "atualizarStatusCozinha", "fecharTurno"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["orderStatusTransition", "orderRequiresItem", "shiftClosureRequiresNoOpenOrders"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/dailySalesMetrics.defs.ts";
                readonly exportName: "dailySalesMetricsTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default dailySalesMetricsTableDefinition;
    export const pipeline: readonly [{
        readonly id: "dailySalesMetrics__layer_1_external";
        readonly type: "layer_1_external";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_1_external/dailySalesMetrics.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_1_external/dailySalesMetrics.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/dailySalesMetrics" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const dailySalesMetricsTableDef: TableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/lowStockAlert.defs" {
    export const lowStockAlertTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "lowStockAlert";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 48;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "lowStockAlert";
                readonly tableName: "low_stock_alerts";
                readonly moduleId: "cafeFlow";
                readonly title: "Alertas de Estoque Baixo";
                readonly purpose: "Persistir alertas de estoque baixo para acompanhamento do gerente.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "LowStockAlert";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "low_stock_alert_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do alerta de estoque baixo.";
                }, {
                    readonly name: "stock_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Item de estoque associado ao alerta.";
                }, {
                    readonly name: "triggered_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora em que o alerta foi gerado.";
                }, {
                    readonly name: "current_quantity";
                    readonly type: "number";
                    readonly nullable: false;
                    readonly description: "Quantidade atual do item quando o alerta foi gerado.";
                }, {
                    readonly name: "minimum_quantity";
                    readonly type: "number";
                    readonly nullable: false;
                    readonly description: "Quantidade mínima configurada para o item.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Situação atual do alerta.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly primaryKey: readonly ["low_stock_alert_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "stock_item_id";
                    readonly targetEntity: "StockItem";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Item de estoque é entidade MDM referenciada pelo alerta.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_low_stock_alerts_stock_item_id";
                    readonly columns: readonly ["stock_item_id"];
                    readonly unique: false;
                    readonly reason: "Lookup rápido por item de estoque.";
                }, {
                    readonly indexName: "idx_low_stock_alerts_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Filtragem por situação do alerta.";
                }, {
                    readonly indexName: "idx_low_stock_alerts_triggered_at";
                    readonly columns: readonly ["triggered_at"];
                    readonly unique: false;
                    readonly reason: "Ordenação e filtros por data do alerta.";
                }, {
                    readonly indexName: "idx_low_stock_alerts_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly unique: false;
                    readonly reason: "Filtros por período no dashboard.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["lowStockMetricTable"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["lowStockThresholdRule"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/lowStockAlert.defs.ts";
                readonly exportName: "lowStockAlertTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default lowStockAlertTableDefinition;
    export const pipeline: readonly [{
        readonly id: "lowStockAlert__layer_1_external";
        readonly type: "layer_1_external";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_1_external/lowStockAlert.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_1_external/lowStockAlert.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/lowStockAlert" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const lowStockAlertTableDef: TableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/lowStockMetrics.defs" {
    export const lowStockMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "lowStockMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 51;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "lowStockMetrics";
                readonly tableName: "low_stock_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Estoque baixo";
                readonly purpose: "Monitorar a frequência e evolução de alertas de estoque baixo para evitar rupturas.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "time";
                readonly columns: readonly [{
                    readonly name: "time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Momento de referência da métrica de estoque baixo.";
                }, {
                    readonly name: "stock_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Item de estoque com alerta ou movimentação.";
                }, {
                    readonly name: "unit_of_measure_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Unidade de medida do item.";
                }, {
                    readonly name: "alert_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly description: "Número de alertas de estoque baixo.";
                }, {
                    readonly name: "current_quantity";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly description: "Quantidade atual em estoque no momento da métrica.";
                }, {
                    readonly name: "threshold_value";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly description: "Valor limite configurado para disparo do alerta.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "stockItemId";
                    readonly column: "stock_item_id";
                    readonly type: "uuid";
                    readonly description: "Item de estoque com alerta ou movimentação.";
                }, {
                    readonly dimensionId: "unitOfMeasureId";
                    readonly column: "unit_of_measure_id";
                    readonly type: "uuid";
                    readonly description: "Unidade de medida do item.";
                }];
                readonly measures: readonly [{
                    readonly measureId: "alertCount";
                    readonly column: "alert_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Número de alertas de estoque baixo.";
                }, {
                    readonly measureId: "currentQuantity";
                    readonly column: "current_quantity";
                    readonly aggregation: "last";
                    readonly unit: "unit";
                    readonly description: "Quantidade atual em estoque no momento da métrica.";
                }, {
                    readonly measureId: "thresholdValue";
                    readonly column: "threshold_value";
                    readonly aggregation: "last";
                    readonly unit: "unit";
                    readonly description: "Valor limite configurado para disparo do alerta.";
                }];
                readonly sourceWriteEvents: readonly ["lowStockAlertCreated", "stockMovementCreated"];
                readonly hypertable: {
                    readonly timeColumn: "time";
                    readonly chunkTimeInterval: "1 day";
                    readonly retentionPolicy: "6 months";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_low_stock_metrics_time";
                        readonly columns: readonly ["time"];
                        readonly purpose: "Suporte a consultas por janela temporal.";
                    }, {
                        readonly indexName: "idx_low_stock_metrics_stock_item_time";
                        readonly columns: readonly ["stock_item_id", "time"];
                        readonly purpose: "Consultas por item de estoque ao longo do tempo.";
                    }, {
                        readonly indexName: "idx_low_stock_metrics_uom_time";
                        readonly columns: readonly ["unit_of_measure_id", "time"];
                        readonly purpose: "Consultas por unidade de medida ao longo do tempo.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["lowStockThresholdRule"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/lowStockMetrics.defs.ts";
                readonly exportName: "lowStockMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default lowStockMetricsMetricTableDefinition;
    export const pipeline: readonly [{
        readonly id: "lowStockMetrics__layer_1_external";
        readonly type: "layer_1_external";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_1_external/lowStockMetrics.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_1_external/lowStockMetrics.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/lowStockMetrics" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const lowStockMetricsTableDef: TableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/mock" {
    import type { SeedDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const seedDefinitions: SeedDefinition[];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/order.defs" {
    export const orderTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 47;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "order";
                readonly tableName: "orders";
                readonly moduleId: "cafeFlow";
                readonly title: "Pedidos";
                readonly purpose: "Persistir pedidos do POS com itens para operação e status atual.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "Order";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do pedido.";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status atual do pedido.";
                }, {
                    readonly name: "shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Turno em que o pedido foi registrado.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do pedido.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do pedido.";
                }];
                readonly primaryKey: readonly ["order_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "shift_id";
                    readonly targetEntity: "Shift";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Pedido pertence a um turno.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_orders_status";
                    readonly columns: readonly ["status"];
                    readonly reason: "Filtro rápido por status no painel da cozinha e workflow.";
                }, {
                    readonly indexName: "idx_orders_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly reason: "Listagens por data para POS e dashboard.";
                }, {
                    readonly indexName: "idx_orders_shift_id";
                    readonly columns: readonly ["shift_id"];
                    readonly reason: "Consulta por turno para fechamento e operações.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly reason: "Itens do pedido e dados agregados do OrderItem armazenados como JSON.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["orderRequiresItem", "orderStatusTransition", "shiftClosureRequiresNoOpenOrders"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/order.defs.ts";
                readonly exportName: "orderTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default orderTableDefinition;
    export const pipeline: readonly [{
        readonly id: "order__layer_1_external";
        readonly type: "layer_1_external";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_1_external/order.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_1_external/order.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/order" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const orderTableDef: TableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/orderStatusHistory.defs" {
    export const orderStatusHistoryTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "orderStatusHistory";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 48;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "orderStatusHistory";
                readonly tableName: "order_status_history";
                readonly moduleId: "cafeFlow";
                readonly title: "Histórico de Status do Pedido";
                readonly purpose: "Registrar transições de status do pedido para auditoria e acompanhamento de cozinha.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "OrderStatusHistory";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "order_status_history_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do histórico de status do pedido.";
                }, {
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência ao pedido relacionado a este registro de status.";
                }, {
                    readonly name: "from_status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Status anterior do pedido antes da transição.";
                }, {
                    readonly name: "to_status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Novo status do pedido após a transição.";
                }, {
                    readonly name: "changed_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora em que a transição de status ocorreu.";
                }, {
                    readonly name: "changed_by";
                    readonly type: "string";
                    readonly nullable: true;
                    readonly description: "Identificador ou nome do colaborador que efetuou a mudança de status.";
                }, {
                    readonly name: "note";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Observação sobre a mudança de status, se aplicável.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly primaryKey: readonly ["order_status_history_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "order_id";
                    readonly targetEntity: "Order";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Histórico vinculado ao pedido para rastreio de transições.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_order_status_history_order_id_changed_at";
                    readonly columns: readonly ["order_id", "changed_at"];
                    readonly unique: false;
                    readonly reason: "Consulta do histórico por pedido e linha do tempo no painel e workflow.";
                }, {
                    readonly indexName: "idx_order_status_history_changed_at";
                    readonly columns: readonly ["changed_at"];
                    readonly unique: false;
                    readonly reason: "Ordenação e filtros por período para auditoria.";
                }, {
                    readonly indexName: "idx_order_status_history_to_status";
                    readonly columns: readonly ["to_status"];
                    readonly unique: false;
                    readonly reason: "Filtrar transições por status no painel de cozinha.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["orderStatusTransitions"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["orderStatusTransition"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/orderStatusHistory.defs.ts";
                readonly exportName: "orderStatusHistoryTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default orderStatusHistoryTableDefinition;
    export const pipeline: readonly [{
        readonly id: "orderStatusHistory__layer_1_external";
        readonly type: "layer_1_external";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_1_external/orderStatusHistory.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_1_external/orderStatusHistory.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/orderStatusHistory" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const orderStatusHistoryTableDef: TableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/shift" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const shiftTableDef: TableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/salesSummaryRequest" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const salesSummaryRequestTableDef: TableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/shiftReport" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const shiftReportTableDef: TableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const topSellingItemsMetricsTableDef: TableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/stockMovement" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const stockMovementTableDef: TableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/persistence" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const tableDefinitions: TableDefinition[];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/salesSummaryRequest.defs" {
    export const salesSummaryRequestTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "salesSummaryRequest";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 49;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "salesSummaryRequest";
                readonly tableName: "sales_summary_requests";
                readonly moduleId: "cafeFlow";
                readonly title: "Solicitações de Resumo de Vendas";
                readonly purpose: "Rastrear solicitações de resumo de vendas para o assistente IA.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "SalesSummaryRequest";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "sales_summary_request_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da solicitação de resumo de vendas.";
                }, {
                    readonly name: "shift_report_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência à consolidação de vendas usada na solicitação.";
                }, {
                    readonly name: "request_status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly default: "pending";
                    readonly description: "Status da solicitação de resumo de vendas.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação da solicitação.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização da solicitação.";
                }];
                readonly primaryKey: readonly ["sales_summary_request_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "shift_report_id";
                    readonly targetEntity: "ShiftReport";
                    readonly targetOwnership: "existingModuleOwned";
                    readonly reason: "Solicitação depende da consolidação de vendas.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "ix_sales_summary_requests_shift_report_id";
                    readonly columns: readonly ["shift_report_id"];
                    readonly reason: "Busca por solicitações vinculadas ao relatório de turno.";
                }, {
                    readonly indexName: "ix_sales_summary_requests_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly reason: "Filtro por período para geração e auditoria.";
                }, {
                    readonly indexName: "ix_sales_summary_requests_status";
                    readonly columns: readonly ["request_status"];
                    readonly reason: "Filtrar solicitações pendentes ou concluídas.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["salesSummaryUsesLast7Days"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/salesSummaryRequest.defs.ts";
                readonly exportName: "salesSummaryRequestTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default salesSummaryRequestTableDefinition;
    export const pipeline: readonly [{
        readonly id: "salesSummaryRequest__layer_1_external";
        readonly type: "layer_1_external";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_1_external/salesSummaryRequest.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_1_external/salesSummaryRequest.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/shift.defs" {
    export const shiftTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "shift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 49;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "shift";
                readonly tableName: "shifts";
                readonly moduleId: "cafeFlow";
                readonly title: "Turnos";
                readonly purpose: "Controlar abertura e fechamento de turnos diários.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "Shift";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do turno.";
                }, {
                    readonly name: "shift_config_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Configuração de turno aplicada ao período operacional.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Status atual do turno.";
                }, {
                    readonly name: "opened_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de abertura do turno.";
                }, {
                    readonly name: "closed_at";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly description: "Data e hora de fechamento do turno.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly primaryKey: readonly ["shift_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "shift_config_id";
                    readonly targetEntity: "ShiftConfig";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Configuração de turno é entidade mestre MDM.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_shifts_status";
                    readonly columns: readonly ["status"];
                    readonly reason: "Filtrar turnos por status em dashboard e workflow.";
                }, {
                    readonly indexName: "idx_shifts_opened_at";
                    readonly columns: readonly ["opened_at"];
                    readonly reason: "Filtro por data para relatórios e dashboard.";
                }, {
                    readonly indexName: "idx_shifts_shift_config_id";
                    readonly columns: readonly ["shift_config_id"];
                    readonly reason: "Lookup por configuração de turno aplicada.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["dailySalesMetricTable"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/shift.defs.ts";
                readonly exportName: "shiftTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default shiftTableDefinition;
    export const pipeline: readonly [{
        readonly id: "shift__layer_1_external";
        readonly type: "layer_1_external";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_1_external/shift.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_1_external/shift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/shiftReport.defs" {
    export const shiftReportTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "shiftReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 50;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "shiftReport";
                readonly tableName: "shift_reports";
                readonly moduleId: "cafeFlow";
                readonly title: "Relatórios de Fechamento de Turno";
                readonly purpose: "Armazenar resumo do fechamento do turno para consulta gerencial.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "ShiftReport";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "shift_report_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do relatório de fechamento de turno.";
                }, {
                    readonly name: "shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência ao turno consolidado por este relatório.";
                }, {
                    readonly name: "report_status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly default: "gerado";
                    readonly description: "Status do relatório de fechamento do turno.";
                }, {
                    readonly name: "total_sales_amount";
                    readonly type: "money";
                    readonly nullable: false;
                    readonly description: "Total de vendas consolidadas no turno.";
                }, {
                    readonly name: "total_orders";
                    readonly type: "number";
                    readonly nullable: false;
                    readonly description: "Quantidade total de pedidos no turno.";
                }, {
                    readonly name: "total_items";
                    readonly type: "number";
                    readonly nullable: true;
                    readonly description: "Quantidade total de itens vendidos no turno.";
                }, {
                    readonly name: "shift_opened_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de abertura do turno reportado.";
                }, {
                    readonly name: "shift_closed_at";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly description: "Data e hora de fechamento do turno reportado.";
                }, {
                    readonly name: "notes";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Observações adicionais do fechamento do turno.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do relatório.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do relatório.";
                }];
                readonly primaryKey: readonly ["shift_report_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "shift_id";
                    readonly targetEntity: "Shift";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Relatório consolida um turno específico.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_shift_reports_shift_id_unique";
                    readonly columns: readonly ["shift_id"];
                    readonly unique: true;
                    readonly reason: "Garante um relatório por turno e lookup rápido pelo turno.";
                }, {
                    readonly indexName: "idx_shift_reports_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly unique: false;
                    readonly reason: "Filtro por período de criação em consultas gerenciais.";
                }, {
                    readonly indexName: "idx_shift_reports_shift_closed_at";
                    readonly columns: readonly ["shift_closed_at"];
                    readonly unique: false;
                    readonly reason: "Filtro por data de fechamento do turno no dashboard.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "ShiftReportDetails";
                    readonly reason: "Armazenar quebras consolidadas (formas de pagamento, categorias, descontos) sem necessidade de colunas próprias.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["dailySalesMetricTable"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/shiftReport.defs.ts";
                readonly exportName: "shiftReportTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default shiftReportTableDefinition;
    export const pipeline: readonly [{
        readonly id: "shiftReport__layer_1_external";
        readonly type: "layer_1_external";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_1_external/shiftReport.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_1_external/shiftReport.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/stockMovement.defs" {
    export const stockMovementTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "stockMovement";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 51;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "stockMovement";
                readonly tableName: "stock_movements";
                readonly moduleId: "cafeFlow";
                readonly title: "Movimentações de Estoque";
                readonly purpose: "Registrar entradas e saídas de estoque ligadas à operação diária.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "StockMovement";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "stock_movement_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da movimentação de estoque.";
                }, {
                    readonly name: "stock_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Item de estoque associado à movimentação.";
                }, {
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Pedido vinculado à saída de estoque, quando aplicável.";
                }, {
                    readonly name: "movement_type";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Tipo de movimentação realizada.";
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                    readonly nullable: false;
                    readonly description: "Quantidade movimentada do item de estoque.";
                }, {
                    readonly name: "reason";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Motivo ou observação da movimentação, especialmente para ajustes.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly default: "active";
                    readonly description: "Status do registro de movimentação.";
                }, {
                    readonly name: "occurred_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora em que a movimentação ocorreu.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly primaryKey: readonly ["stock_movement_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "stock_item_id";
                    readonly targetEntity: "StockItem";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Movimentação vinculada a item de estoque master.";
                }, {
                    readonly fieldName: "order_id";
                    readonly targetEntity: "Order";
                    readonly targetOwnership: "existingModuleOwned";
                    readonly reason: "Saídas podem estar vinculadas a pedidos existentes no módulo.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_stock_movements_stock_item_id";
                    readonly columns: readonly ["stock_item_id"];
                    readonly unique: false;
                    readonly reason: "Consulta por item de estoque para alertas e gestão.";
                }, {
                    readonly indexName: "idx_stock_movements_order_id";
                    readonly columns: readonly ["order_id"];
                    readonly unique: false;
                    readonly reason: "Rastrear movimentações relacionadas a pedidos.";
                }, {
                    readonly indexName: "idx_stock_movements_occurred_at";
                    readonly columns: readonly ["occurred_at"];
                    readonly unique: false;
                    readonly reason: "Filtros por período no dashboard e auditoria.";
                }, {
                    readonly indexName: "idx_stock_movements_movement_type";
                    readonly columns: readonly ["movement_type"];
                    readonly unique: false;
                    readonly reason: "Filtragem por tipo de movimentação.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["lowStockMetricTable", "dailySalesMetricTable", "topSellingItemsMetricTable"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["lowStockThresholdRule"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/stockMovement.defs.ts";
                readonly exportName: "stockMovementTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default stockMovementTableDefinition;
    export const pipeline: readonly [{
        readonly id: "stockMovement__layer_1_external";
        readonly type: "layer_1_external";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_1_external/stockMovement.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_1_external/stockMovement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.defs" {
    export const topSellingItemsMetricsTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "topSellingItemsMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 50;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "topSellingItemsMetrics";
                readonly tableName: "top_selling_items_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Itens mais vendidos";
                readonly purpose: "Identificar os produtos com maior saída e receita para otimização de cardápio e compras.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "time";
                readonly columns: readonly [{
                    readonly name: "time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp da métrica agregada.";
                }, {
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Pedido de origem do item";
                }, {
                    readonly name: "menu_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Item do cardápio vendido";
                }, {
                    readonly name: "menu_category_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Categoria do item no cardápio";
                }, {
                    readonly name: "shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Turno em que o item foi vendido";
                }, {
                    readonly name: "stock_item_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship menuItemUsesStockItem (MenuItem -> StockItem)";
                }, {
                    readonly name: "order_item_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship orderHasItems (Order -> OrderItem)";
                }, {
                    readonly name: "order_status_history_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship orderHasStatusHistory (Order -> OrderStatusHistory)";
                }, {
                    readonly name: "shift_report_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship shiftHasReport (Shift -> ShiftReport)";
                }, {
                    readonly name: "shift_config_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship shiftUsesConfig (Shift -> ShiftConfig)";
                }, {
                    readonly name: "quantity_sold";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade vendida do item";
                }, {
                    readonly name: "item_revenue";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Receita gerada pelo item";
                }, {
                    readonly name: "order_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Número de pedidos contendo o item";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "orderId";
                    readonly column: "order_id";
                    readonly type: "uuid";
                    readonly description: "Pedido de origem do item";
                }, {
                    readonly dimensionId: "menuItemId";
                    readonly column: "menu_item_id";
                    readonly type: "uuid";
                    readonly description: "Item do cardápio vendido";
                }, {
                    readonly dimensionId: "menuCategoryId";
                    readonly column: "menu_category_id";
                    readonly type: "uuid";
                    readonly description: "Categoria do item no cardápio";
                }, {
                    readonly dimensionId: "shiftId";
                    readonly column: "shift_id";
                    readonly type: "uuid";
                    readonly description: "Turno em que o item foi vendido";
                }, {
                    readonly dimensionId: "stockItemId";
                    readonly column: "stock_item_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship menuItemUsesStockItem (MenuItem -> StockItem)";
                }, {
                    readonly dimensionId: "orderItemId";
                    readonly column: "order_item_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship orderHasItems (Order -> OrderItem)";
                }, {
                    readonly dimensionId: "orderStatusHistoryId";
                    readonly column: "order_status_history_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship orderHasStatusHistory (Order -> OrderStatusHistory)";
                }, {
                    readonly dimensionId: "shiftReportId";
                    readonly column: "shift_report_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship shiftHasReport (Shift -> ShiftReport)";
                }, {
                    readonly dimensionId: "shiftConfigId";
                    readonly column: "shift_config_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship shiftUsesConfig (Shift -> ShiftConfig)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "quantitySold";
                    readonly column: "quantity_sold";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade vendida do item";
                }, {
                    readonly measureId: "itemRevenue";
                    readonly column: "item_revenue";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Receita gerada pelo item";
                }, {
                    readonly measureId: "orderCount";
                    readonly column: "order_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Número de pedidos contendo o item";
                }];
                readonly sourceWriteEvents: readonly ["orderCreated", "orderStatusUpdated"];
                readonly hypertable: {
                    readonly timeColumn: "time";
                    readonly chunkTimeInterval: "1 day";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_top_selling_items_metrics_time";
                        readonly columns: readonly ["time"];
                        readonly purpose: "Ordenação e retenção por tempo.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_time_menu_item";
                        readonly columns: readonly ["time", "menu_item_id"];
                        readonly purpose: "Ranking de itens por período.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_time_menu_category";
                        readonly columns: readonly ["time", "menu_category_id"];
                        readonly purpose: "Análise por categoria ao longo do tempo.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_time_shift";
                        readonly columns: readonly ["time", "shift_id"];
                        readonly purpose: "Comparação de vendas por turno.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_time_order";
                        readonly columns: readonly ["time", "order_id"];
                        readonly purpose: "Rastreio por pedido.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_stock_item";
                        readonly columns: readonly ["stock_item_id"];
                        readonly purpose: "Análise de consumo por insumo.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_order_item";
                        readonly columns: readonly ["order_item_id"];
                        readonly purpose: "Rastreio por item de pedido.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_order_status_history";
                        readonly columns: readonly ["order_status_history_id"];
                        readonly purpose: "Conciliação com transições de status.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_shift_report";
                        readonly columns: readonly ["shift_report_id"];
                        readonly purpose: "Vincular ao relatório de turno.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_shift_config";
                        readonly columns: readonly ["shift_config_id"];
                        readonly purpose: "Análise por configuração de turno.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["registrarPedido", "atualizarStatusCozinha", "fecharTurno"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["orderStatusTransition", "orderRequiresItem", "menuItemRequiresCategory"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/topSellingItemsMetrics.defs.ts";
                readonly exportName: "topSellingItemsMetricsTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default topSellingItemsMetricsTableDefinition;
    export const pipeline: readonly [{
        readonly id: "topSellingItemsMetrics__layer_1_external";
        readonly type: "layer_1_external";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_1.md", "_102034_.d.ts"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerLayer1";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.defs" {
    export const definition: ({
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: string[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    } | {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: string[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    })[];
    export const pipeline: readonly [{
        readonly id: "cardapioEstoque__layer_2_controllers";
        readonly type: "layer_2_controllers";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_3_usecases/listarItensCardapio.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/listarCategoriasCardapio.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/criarOuAtualizarItemCardapio.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/listarItensEstoque.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/criarOuAtualizarItemEstoque.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/registrarMovimentacaoEstoque.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/listarMovimentacoesEstoque.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/listarAlertasEstoqueBaixo.d.ts", "_102043_/l2/cafeFlow/web/contracts/cardapioEstoque.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["menuItemRequiresCategory", "lowStockThresholdRule"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IDataRuntime } from '_102034_/l1/server/layer_1_external/data/runtime';
    export type CardapioRecord = {
        menuItemId: string;
        name: string;
        description?: string | null;
        price: number;
        menuCategoryId: string;
        isActive: boolean;
        createdAt: string;
        updatedAt: string;
    };
    export interface CreateCardapioInput {
        name: string;
        description?: string | null;
        price: number;
        menuCategoryId: string;
        isActive: boolean;
    }
    export interface UpdateCardapioInput {
        menuItemId: string;
        patch: Partial<Pick<CardapioRecord, 'name' | 'description' | 'price' | 'menuCategoryId' | 'isActive'>>;
    }
    export interface ListCardapioFilter {
        menuCategoryId?: string;
        isActive?: boolean;
    }
    export interface ICardapioEntity {
        create(ctx: RequestContext, input: CreateCardapioInput, runtime?: IDataRuntime): Promise<CardapioRecord>;
        update(ctx: RequestContext, input: UpdateCardapioInput, runtime?: IDataRuntime): Promise<CardapioRecord>;
        getById(ctx: RequestContext, menuItemId: string, runtime?: IDataRuntime): Promise<CardapioRecord>;
        list(ctx: RequestContext, filter?: ListCardapioFilter, runtime?: IDataRuntime): Promise<CardapioRecord[]>;
    }
    export const CardapioEntity: ICardapioEntity;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarItensCardapio" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type CardapioRecord } from "_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity";
    export interface ListarItensCardapioInput {
    }
    export interface ListarItensCardapioOutput {
        itensCardapio: CardapioRecord[];
    }
    export function listarItensCardapio(ctx: RequestContext, _input: ListarItensCardapioInput): Promise<ListarItensCardapioOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarCategoriasCardapio" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    type MenuCategory = never;
    export interface ListarCategoriasCardapioInput {
    }
    export interface ListarCategoriasCardapioOutput {
        categorias: MenuCategory[];
    }
    export function listarCategoriasCardapio(ctx: RequestContext, input: ListarCategoriasCardapioInput): Promise<ListarCategoriasCardapioOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarOuAtualizarItemCardapio" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type CardapioRecord } from "_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity";
    export interface CriarOuAtualizarItemCardapioInput {
        cardapioEntity: CardapioRecord;
    }
    export interface CriarOuAtualizarItemCardapioOutput {
        cardapioEntity: CardapioRecord;
    }
    export function criarOuAtualizarItemCardapio(ctx: RequestContext, input: CriarOuAtualizarItemCardapioInput): Promise<CriarOuAtualizarItemCardapioOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IDataRuntime } from '_102034_/l1/server/layer_1_external/data/runtime';
    export type StockMovementType = 'entrada' | 'saida' | 'ajuste';
    export interface StockMovementRecord {
        stock_movement_id: string;
        stock_item_id: string;
        order_id?: string | null;
        movement_type: StockMovementType;
        quantity: number;
        reason?: string | null;
        occurred_at: string;
        created_at: string;
        updated_at: string;
    }
    export interface CreateEstoqueInput {
        stockItemId: string;
        orderId?: string | null;
        movementType: StockMovementType;
        quantity: number;
        reason?: string | null;
        occurredAt: string;
    }
    export interface UpdateEstoqueInput {
        stockMovementId: string;
        stockItemId?: string;
        orderId?: string | null;
        movementType?: StockMovementType;
        quantity?: number;
        reason?: string | null;
        occurredAt?: string;
    }
    export interface ListEstoqueFilter {
        stockItemId?: string;
        orderId?: string;
        movementType?: StockMovementType;
    }
    export interface IEstoqueEntity {
        create(ctx: RequestContext, input: CreateEstoqueInput, runtime?: IDataRuntime): Promise<StockMovementRecord>;
        update(ctx: RequestContext, input: UpdateEstoqueInput, runtime?: IDataRuntime): Promise<StockMovementRecord>;
        getById(ctx: RequestContext, stockMovementId: string, runtime?: IDataRuntime): Promise<StockMovementRecord>;
        list(ctx: RequestContext, filter?: ListEstoqueFilter, runtime?: IDataRuntime): Promise<StockMovementRecord[]>;
    }
    export const EstoqueEntity: IEstoqueEntity;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarItensEstoque" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type StockMovementRecord } from "_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity";
    export interface ListarItensEstoqueInput {
    }
    export interface ListarItensEstoqueOutput {
        itensEstoque: StockMovementRecord[];
    }
    export function listarItensEstoque(ctx: RequestContext, _input: ListarItensEstoqueInput): Promise<ListarItensEstoqueOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarOuAtualizarItemEstoque" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type CreateEstoqueInput, type UpdateEstoqueInput, type StockMovementRecord } from "_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity";
    export interface CriarOuAtualizarItemEstoqueInput {
        estoqueEntity: CreateEstoqueInput | UpdateEstoqueInput;
    }
    export interface CriarOuAtualizarItemEstoqueOutput {
        estoqueEntity: StockMovementRecord;
    }
    export function criarOuAtualizarItemEstoque(ctx: RequestContext, input: CriarOuAtualizarItemEstoqueInput): Promise<CriarOuAtualizarItemEstoqueOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/metricasEntity" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IDataRuntime } from '_102034_/l1/server/layer_1_external/data/runtime';
    export type DailySalesMetricsRecord = Record<string, unknown>;
    export type TopSellingItemsMetricsRecord = Record<string, unknown>;
    export type LowStockMetricsRecord = Record<string, unknown>;
    export type MetricasMetricTableName = 'daily_sales_metrics' | 'top_selling_items_metrics' | 'low_stock_metrics';
    export type MetricasMetricRecord = DailySalesMetricsRecord | TopSellingItemsMetricsRecord | LowStockMetricsRecord;
    export interface MetricasGetByIdInput {
        tableName: MetricasMetricTableName;
        key: Record<string, unknown>;
    }
    export interface MetricasUpdateInput {
        tableName: MetricasMetricTableName;
        record: MetricasMetricRecord;
    }
    export interface IMetricasEntity {
        getById(ctx: RequestContext, input: MetricasGetByIdInput, runtime?: IDataRuntime): Promise<MetricasMetricRecord>;
        update(ctx: RequestContext, input: MetricasUpdateInput, runtime?: IDataRuntime): Promise<MetricasMetricRecord>;
    }
    export const MetricasEntity: IMetricasEntity;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/registrarMovimentacaoEstoque" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface RegistrarMovimentacaoEstoqueInput {
        stockItemId: string;
        movementType: string;
        quantity: number;
        unitOfMeasureId: string;
        movementDate?: Date;
        reason?: string;
    }
    export interface RegistrarMovimentacaoEstoqueOutput {
        stockItemId: string;
        quantity: number;
    }
    export function registrarMovimentacaoEstoque(ctx: RequestContext, input: RegistrarMovimentacaoEstoqueInput): Promise<RegistrarMovimentacaoEstoqueOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarMovimentacoesEstoque" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type StockMovementRecord } from "_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity";
    export interface ListarMovimentacoesEstoqueInput {
    }
    export interface ListarMovimentacoesEstoqueOutput {
        movimentacoes: StockMovementRecord[];
    }
    export function listarMovimentacoesEstoque(ctx: RequestContext, _input: ListarMovimentacoesEstoqueInput): Promise<ListarMovimentacoesEstoqueOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarAlertasEstoqueBaixo" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { StockMovementRecord } from "_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity";
    export interface ListarAlertasEstoqueBaixoInput {
    }
    export interface ListarAlertasEstoqueBaixoOutput {
        alertas: StockMovementRecord[];
    }
    export function listarAlertasEstoqueBaixo(_ctx: RequestContext, _input: ListarAlertasEstoqueBaixoInput): Promise<ListarAlertasEstoqueBaixoOutput>;
    export const implementation: {
        readonly functionName: "listarAlertasEstoqueBaixo";
        readonly inputTypeName: "ListarAlertasEstoqueBaixoInput";
        readonly outputTypeName: "ListarAlertasEstoqueBaixoOutput";
        readonly tsFileRef: "_102043_/l1/cafeFlow/layer_3_usecases/listarAlertasEstoqueBaixo.ts";
    };
}
declare module "_102043_/l2/cafeFlow/web/contracts/cardapioEstoque" {
    export interface CardapioEstoqueListarItensCardapioInput {
        categoriaId?: string;
        disponivel?: boolean;
    }
    export interface CardapioEstoqueListarItensCardapioOutputItem {
        menuItemId: string;
        nome: string;
        preco: number;
        categoriaId: string;
        ativo: boolean;
    }
    export type CardapioEstoqueListarItensCardapioOutput = CardapioEstoqueListarItensCardapioOutputItem[];
    export interface CardapioEstoqueListarCategoriasCardapioInput {
    }
    export interface CardapioEstoqueListarCategoriasCardapioOutputItem {
        categoriaId: string;
        nome: string;
        ativo: boolean;
    }
    export type CardapioEstoqueListarCategoriasCardapioOutput = CardapioEstoqueListarCategoriasCardapioOutputItem[];
    export interface CardapioEstoqueCriarOuAtualizarItemCardapioInput {
        menuItemId?: string;
        nome: string;
        preco: number;
        categoriaId: string;
        ativo: boolean;
    }
    export interface CardapioEstoqueCriarOuAtualizarItemCardapioOutput {
        menuItemId: string;
    }
    export interface CardapioEstoqueListarItensEstoqueInput {
        categoriaId?: string;
        status?: string;
    }
    export interface CardapioEstoqueListarItensEstoqueOutputItem {
        stockItemId: string;
        nome: string;
        quantidadeAtual: number;
        unidadeMedidaId: string;
        quantidadeMinima: number;
        status: string;
    }
    export type CardapioEstoqueListarItensEstoqueOutput = CardapioEstoqueListarItensEstoqueOutputItem[];
    export interface CardapioEstoqueCriarOuAtualizarItemEstoqueInput {
        stockItemId?: string;
        nome: string;
        unidadeMedidaId: string;
        quantidadeMinima: number;
        ativo: boolean;
    }
    export interface CardapioEstoqueCriarOuAtualizarItemEstoqueOutput {
        stockItemId: string;
    }
    export interface CardapioEstoqueRegistrarMovimentacaoEstoqueInput {
        stockItemId: string;
        movementType: string;
        quantity: number;
        reason?: string;
        occurredAt: string;
    }
    export interface CardapioEstoqueRegistrarMovimentacaoEstoqueOutput {
        stockMovementId: string;
    }
    export interface CardapioEstoqueListarMovimentacoesEstoqueInput {
        stockItemId?: string;
        dataInicio?: string;
        dataFim?: string;
    }
    export interface CardapioEstoqueListarMovimentacoesEstoqueOutputItem {
        stockMovementId: string;
        stockItemId: string;
        movementType: string;
        quantity: number;
        reason: string;
        occurredAt: string;
    }
    export type CardapioEstoqueListarMovimentacoesEstoqueOutput = CardapioEstoqueListarMovimentacoesEstoqueOutputItem[];
    export interface CardapioEstoqueListarAlertasEstoqueBaixoInput {
        status?: string;
    }
    export interface CardapioEstoqueListarAlertasEstoqueBaixoOutputItem {
        lowStockAlertId: string;
        stockItemId: string;
        triggeredAt: string;
        currentQuantity: number;
        minimumQuantity: number;
        status: string;
    }
    export type CardapioEstoqueListarAlertasEstoqueBaixoOutput = CardapioEstoqueListarAlertasEstoqueBaixoOutputItem[];
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const CafeFlowCardapioEstoqueListarItensCardapioHandler: BffHandler;
    export const CafeFlowCardapioEstoqueListarCategoriasCardapioHandler: BffHandler;
    export const CafeFlowCardapioEstoqueCriarOuAtualizarItemCardapioHandler: BffHandler;
    export const CafeFlowCardapioEstoqueListarItensEstoqueHandler: BffHandler;
    export const CafeFlowCardapioEstoqueCriarOuAtualizarItemEstoqueHandler: BffHandler;
    export const CafeFlowCardapioEstoqueRegistrarMovimentacaoEstoqueHandler: BffHandler;
    export const CafeFlowCardapioEstoqueListarMovimentacoesEstoqueHandler: BffHandler;
    export const CafeFlowCardapioEstoqueListarAlertasEstoqueBaixoHandler: BffHandler;
    export const cardapioEstoqueRouter: {
        readonly 'cafeFlow.cardapioEstoque.listarItensCardapio': {
            readonly handlerName: "CafeFlowCardapioEstoqueListarItensCardapioHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.js";
        };
        readonly 'cafeFlow.cardapioEstoque.listarCategoriasCardapio': {
            readonly handlerName: "CafeFlowCardapioEstoqueListarCategoriasCardapioHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.js";
        };
        readonly 'cafeFlow.cardapioEstoque.criarOuAtualizarItemCardapio': {
            readonly handlerName: "CafeFlowCardapioEstoqueCriarOuAtualizarItemCardapioHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.js";
        };
        readonly 'cafeFlow.cardapioEstoque.listarItensEstoque': {
            readonly handlerName: "CafeFlowCardapioEstoqueListarItensEstoqueHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.js";
        };
        readonly 'cafeFlow.cardapioEstoque.criarOuAtualizarItemEstoque': {
            readonly handlerName: "CafeFlowCardapioEstoqueCriarOuAtualizarItemEstoqueHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.js";
        };
        readonly 'cafeFlow.cardapioEstoque.registrarMovimentacaoEstoque': {
            readonly handlerName: "CafeFlowCardapioEstoqueRegistrarMovimentacaoEstoqueHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.js";
        };
        readonly 'cafeFlow.cardapioEstoque.listarMovimentacoesEstoque': {
            readonly handlerName: "CafeFlowCardapioEstoqueListarMovimentacoesEstoqueHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.js";
        };
        readonly 'cafeFlow.cardapioEstoque.listarAlertasEstoqueBaixo': {
            readonly handlerName: "CafeFlowCardapioEstoqueListarAlertasEstoqueBaixoHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/cardapioEstoque.js";
        };
    };
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/dashboardGerente.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: any[];
    }[];
    export const pipeline: readonly [{
        readonly id: "dashboardGerente__layer_2_controllers";
        readonly type: "layer_2_controllers";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_2_controllers/dashboardGerente.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_2_controllers/dashboardGerente.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_3_usecases/consultarDashboardGerente.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/listarAlertasEstoqueBaixo.d.ts", "_102043_/l2/cafeFlow/web/contracts/dashboardGerente.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/consultarDashboardGerente" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type DailySalesMetricsRecord, type TopSellingItemsMetricsRecord, type LowStockMetricsRecord } from "_102043_/l1/cafeFlow/layer_4_entities/metricasEntity";
    export interface ConsultarDashboardGerenteInput {
    }
    export interface ConsultarDashboardGerenteResult {
        metricas: {
            dailySalesMetrics: DailySalesMetricsRecord;
            topSellingItemsMetrics: TopSellingItemsMetricsRecord;
            lowStockMetrics: LowStockMetricsRecord;
        };
    }
    export function consultarDashboardGerente(ctx: RequestContext, _input: ConsultarDashboardGerenteInput): Promise<ConsultarDashboardGerenteResult>;
}
declare module "_102043_/l2/cafeFlow/web/contracts/dashboardGerente" {
    export interface DashboardGerenteConsultarDashboardGerenteInput {
        periodoInicio?: string;
        periodoFim?: string;
        turnoId?: string;
    }
    export interface DashboardGerenteConsultarDashboardGerenteOutput {
        totalRevenue: number;
        orderCount: number;
        averageTicket: number;
        itemsSold: number;
        serieVendasPorTurno: string;
        rankingItensMaisVendidos: string;
    }
    export interface DashboardGerenteListarAlertasEstoqueBaixoInput {
        statusAlerta?: string;
    }
    export interface DashboardGerenteListarAlertasEstoqueBaixoOutputItem {
        alertas: string;
    }
    export type DashboardGerenteListarAlertasEstoqueBaixoOutput = DashboardGerenteListarAlertasEstoqueBaixoOutputItem[];
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/dashboardGerente" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowDashboardGerenteConsultarDashboardGerenteHandler: BffHandler;
    export const cafeFlowDashboardGerenteListarAlertasEstoqueBaixoHandler: BffHandler;
    export const dashboardGerenteRoutes: {
        readonly 'cafeFlow.dashboardGerente.consultarDashboardGerente': {
            readonly handlerName: "cafeFlowDashboardGerenteConsultarDashboardGerenteHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/dashboardGerente.js";
        };
        readonly 'cafeFlow.dashboardGerente.listarAlertasEstoqueBaixo': {
            readonly handlerName: "cafeFlowDashboardGerenteListarAlertasEstoqueBaixoHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/dashboardGerente.js";
        };
    };
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/fechamentoTurno.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: string[];
        writesTables: string[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "fechamentoTurno__layer_2_controllers";
        readonly type: "layer_2_controllers";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_2_controllers/fechamentoTurno.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_2_controllers/fechamentoTurno.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_3_usecases/listarTurnos.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidos.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/fecharTurno.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/obterRelatorioTurno.d.ts", "_102043_/l2/cafeFlow/web/contracts/fechamentoTurno.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/turnoEntity" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IDataRuntime } from '_102034_/l1/server/layer_1_external/data/runtime';
    export type TurnoStatus = 'aberto' | 'emFechamento' | 'fechado';
    export interface TurnoRecord {
        shift_id: string;
        shift_config_id: string;
        status: TurnoStatus;
        opened_at: string;
        closed_at?: string | null;
        created_at: string;
        updated_at: string;
    }
    export interface CreateTurnoInput {
        shiftConfigId: string;
        status: TurnoStatus;
        openedAt: string;
        closedAt?: string | null;
    }
    export interface UpdateTurnoInput {
        shiftId: string;
        patch: {
            shiftConfigId?: string;
            status?: TurnoStatus;
            openedAt?: string;
            closedAt?: string | null;
        };
    }
    export interface ListTurnoFilter {
        shiftConfigId?: string;
        status?: TurnoStatus;
    }
    export interface ITurnoEntity {
        create(ctx: RequestContext, input: CreateTurnoInput, runtime?: IDataRuntime): Promise<TurnoRecord>;
        getById(ctx: RequestContext, shiftId: string, runtime?: IDataRuntime): Promise<TurnoRecord>;
        list(ctx: RequestContext, filter?: ListTurnoFilter, runtime?: IDataRuntime): Promise<TurnoRecord[]>;
        update(ctx: RequestContext, input: UpdateTurnoInput, runtime?: IDataRuntime): Promise<TurnoRecord>;
    }
    export const TurnoEntity: ITurnoEntity;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarTurnos" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type TurnoRecord } from "_102043_/l1/cafeFlow/layer_4_entities/turnoEntity";
    export interface ListarTurnosInput {
    }
    export interface ListarTurnosResult {
        turnos: TurnoRecord[];
    }
    export function listarTurnos(ctx: RequestContext, _input: ListarTurnosInput): Promise<ListarTurnosResult>;
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IDataRuntime } from '_102034_/l1/server/layer_1_external/data/runtime';
    export type PedidoStatus = 'recebido' | 'emPreparo' | 'pronto' | 'entregue' | 'cancelado';
    export interface PedidoRecord {
        order_id: string;
        status: PedidoStatus;
        shift_id: string;
        created_at: string;
        updated_at: string;
    }
    export interface PedidoStatusHistoryRecord {
        id: string;
        order_id: string;
        from_status?: PedidoStatus | null;
        to_status: PedidoStatus;
        created_at: string;
    }
    export interface CreatePedidoInput {
        status: PedidoStatus;
        shiftId: string;
    }
    export interface UpdatePedidoInput {
        orderId: string;
        status?: PedidoStatus;
        shiftId?: string;
    }
    export interface ListPedidoFilter {
        status?: PedidoStatus;
        shiftId?: string;
    }
    export interface IPedidoEntity {
        create(ctx: RequestContext, input: CreatePedidoInput, runtime?: IDataRuntime): Promise<PedidoRecord>;
        getById(ctx: RequestContext, orderId: string, runtime?: IDataRuntime): Promise<PedidoRecord>;
        update(ctx: RequestContext, input: UpdatePedidoInput, runtime?: IDataRuntime): Promise<PedidoRecord>;
        list(ctx: RequestContext, filter?: ListPedidoFilter, runtime?: IDataRuntime): Promise<PedidoRecord[]>;
    }
    export const PedidoEntity: IPedidoEntity;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidos" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type PedidoRecord } from "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity";
    export interface ListarPedidosInput {
    }
    export interface ListarPedidosOutput {
        pedidos: PedidoRecord[];
    }
    export function listarPedidos(ctx: RequestContext, _input: ListarPedidosInput): Promise<ListarPedidosOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/fecharTurno" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface FecharTurnoInput {
        turnoId: string;
    }
    export interface FecharTurnoOutput {
        turnoId: string;
        status: string;
    }
    export function fecharTurno(ctx: RequestContext, input: FecharTurnoInput): Promise<FecharTurnoOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/obterRelatorioTurno" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type TurnoRecord } from "_102043_/l1/cafeFlow/layer_4_entities/turnoEntity";
    export interface ObterRelatorioTurnoInput {
        turnoId: string;
    }
    export interface ObterRelatorioTurnoOutput {
        turno: TurnoRecord;
    }
    export function obterRelatorioTurno(ctx: RequestContext, input: ObterRelatorioTurnoInput): Promise<ObterRelatorioTurnoOutput>;
}
declare module "_102043_/l2/cafeFlow/web/contracts/fechamentoTurno" {
    export interface FechamentoTurnoListarTurnosInput {
        dataInicio?: string;
        dataFim?: string;
        status?: string;
    }
    export interface FechamentoTurnoListarTurnosOutputItem {
        shiftId: string;
        status: string;
        openedAt: string;
        closedAt: string;
        shiftConfigId: string;
    }
    export type FechamentoTurnoListarTurnosOutput = FechamentoTurnoListarTurnosOutputItem[];
    export interface FechamentoTurnoListarPedidosInput {
        shiftId: string;
        status?: string;
    }
    export interface FechamentoTurnoListarPedidosOutputItem {
        orderId: string;
        status: string;
        shiftId: string;
        createdAt: string;
        updatedAt: string;
    }
    export type FechamentoTurnoListarPedidosOutput = FechamentoTurnoListarPedidosOutputItem[];
    export interface FechamentoTurnoFecharTurnoInput {
        shiftId: string;
    }
    export interface FechamentoTurnoFecharTurnoOutput {
        shiftId: string;
        status: string;
        closedAt: string;
        shiftReportId: string;
    }
    export interface FechamentoTurnoObterRelatorioTurnoInput {
        shiftId: string;
    }
    export interface FechamentoTurnoObterRelatorioTurnoOutput {
        shiftReportId: string;
        shiftId: string;
        totalSalesAmount: string;
        totalOrders: number;
        totalItems: number;
        notes: string;
        createdAt: string;
        updatedAt: string;
    }
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/fechamentoTurno" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowFechamentoTurnoListarTurnosHandler: BffHandler;
    export const cafeFlowFechamentoTurnoListarPedidosHandler: BffHandler;
    export const cafeFlowFechamentoTurnoFecharTurnoHandler: BffHandler;
    export const cafeFlowFechamentoTurnoObterRelatorioTurnoHandler: BffHandler;
    export const fechamentoTurnoRouter: {
        'cafeFlow.fechamentoTurno.listarTurnos': {
            handlerName: string;
            importPath: string;
        };
        'cafeFlow.fechamentoTurno.listarPedidos': {
            handlerName: string;
            importPath: string;
        };
        'cafeFlow.fechamentoTurno.fecharTurno': {
            handlerName: string;
            importPath: string;
        };
        'cafeFlow.fechamentoTurno.obterRelatorioTurno': {
            handlerName: string;
            importPath: string;
        };
    };
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/painelCozinha.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: string[];
        writesTables: string[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "painelCozinha__layer_2_controllers";
        readonly type: "layer_2_controllers";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_2_controllers/painelCozinha.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_2_controllers/painelCozinha.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_3_usecases/listarPedidosCozinha.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/atualizarStatusPedido.d.ts", "_102043_/l2/cafeFlow/web/contracts/painelCozinha.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["orderStatusTransition"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidosCozinha" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type PedidoRecord } from "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity";
    export interface ListarPedidosCozinhaInput {
    }
    export interface ListarPedidosCozinhaOutput {
        pedidos: PedidoRecord[];
    }
    export function listarPedidosCozinha(ctx: RequestContext, _input: ListarPedidosCozinhaInput): Promise<ListarPedidosCozinhaOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/atualizarStatusPedido" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type PedidoRecord } from "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity";
    export interface AtualizarStatusPedidoInput {
        pedidoId: string;
        novoStatus: string;
    }
    export interface AtualizarStatusPedidoOutput {
        pedido: PedidoRecord;
    }
    export function atualizarStatusPedido(ctx: RequestContext, input: AtualizarStatusPedidoInput): Promise<AtualizarStatusPedidoOutput>;
}
declare module "_102043_/l2/cafeFlow/web/contracts/painelCozinha" {
    export interface PainelCozinhaListarPedidosCozinhaInput {
        status?: string;
        shiftId?: string;
    }
    export interface PainelCozinhaListarPedidosCozinhaOutputItem {
        orderId: string;
        status: string;
        createdAt: string;
        shiftId: string;
    }
    export type PainelCozinhaListarPedidosCozinhaOutput = PainelCozinhaListarPedidosCozinhaOutputItem[];
    export interface PainelCozinhaAtualizarStatusPedidoInput {
        orderId: string;
        novoStatus: string;
    }
    export interface PainelCozinhaAtualizarStatusPedidoOutput {
        orderId: string;
        status: string;
        updatedAt: string;
    }
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/painelCozinha" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowPainelCozinhaListarPedidosCozinhaHandler: BffHandler;
    export const cafeFlowPainelCozinhaAtualizarStatusPedidoHandler: BffHandler;
    export const painelCozinhaRouter: {
        readonly 'cafeFlow.painelCozinha.listarPedidosCozinha': {
            readonly handlerName: "cafeFlowPainelCozinhaListarPedidosCozinhaHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/painelCozinha.js";
        };
        readonly 'cafeFlow.painelCozinha.atualizarStatusPedido': {
            readonly handlerName: "cafeFlowPainelCozinhaAtualizarStatusPedidoHandler";
            readonly importPath: "/_102043_/l1/cafeFlow/layer_2_controllers/painelCozinha.js";
        };
    };
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/posRapido.defs" {
    export const definition: ({
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: string[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: any[];
    } | {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: string[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    })[];
    export const pipeline: readonly [{
        readonly id: "posRapido__layer_2_controllers";
        readonly type: "layer_2_controllers";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_2_controllers/posRapido.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_2_controllers/posRapido.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_3_usecases/listarPedidos.d.ts", "_102043_/l1/cafeFlow/layer_3_usecases/criarPedido.d.ts", "_102043_/l2/cafeFlow/web/contracts/posRapido.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_2.md"];
        readonly afterSaveBackEnd: "_102021_/l2/agentMaterializeSolution/registerBackEnd.ts?registerController";
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["orderRequiresItem"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarPedido" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type CardapioRecord } from "_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity";
    import { type CreatePedidoInput, type PedidoRecord } from "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity";
    export interface CriarPedidoInput {
        pedido: CreatePedidoInput;
        itens: CardapioRecord[];
    }
    export interface CriarPedidoOutput {
        pedido: PedidoRecord;
    }
    export function criarPedido(ctx: RequestContext, input: CriarPedidoInput): Promise<CriarPedidoOutput>;
}
declare module "_102043_/l2/cafeFlow/web/contracts/posRapido" {
    export interface PosRapidoListarPedidosInput {
        status?: string;
        dateFrom?: string;
        dateTo?: string;
    }
    export interface PosRapidoListarPedidosOutputItem {
        orderId: string;
        status: string;
        createdAt: string;
        updatedAt: string;
    }
    export type PosRapidoListarPedidosOutput = PosRapidoListarPedidosOutputItem[];
    export interface PosRapidoCriarPedidoInput {
        orderItems: string;
        observacao?: string;
    }
    export interface PosRapidoCriarPedidoOutput {
        orderId: string;
        status: string;
        createdAt: string;
        updatedAt: string;
    }
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/posRapido" {
    import { type BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowPosRapidoListarPedidosHandler: BffHandler;
    export const cafeFlowPosRapidoCriarPedidoHandler: BffHandler;
    export const posRapidoRoutes: {
        'cafeFlow.posRapido.listarPedidos': {
            handler: BffHandler;
            importPath: string;
        };
        'cafeFlow.posRapido.criarPedido': {
            handler: BffHandler;
            importPath: string;
        };
    };
}
declare module "_102043_/l1/cafeFlow/layer_2_controllers/router" {
    import type { BffHandler } from '_102034_/l1/server/layer_2_controllers/contracts';
    export function createCafeFlowRouter(): Map<string, BffHandler>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/abrirTurno.defs" {
    export const useCase: {
        readonly usecaseId: "abrirTurno";
        readonly title: "Abrir turno";
        readonly purpose: "Iniciar um turno diário.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["turnoEntity"];
        readonly outputEntities: readonly ["turnoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "ShiftConfig";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "shifts";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["metricasEntity", "turnoEntity"];
        readonly commands: readonly [{
            readonly commandId: "abrirTurno";
            readonly input: readonly [{
                readonly name: "turnoId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "turnoId";
                readonly type: "string";
            }];
        }];
        readonly pendingQuestions: readonly ["Quais campos obrigatórios do turnoEntity devem ser informados para abrir o turno (ex.: data, lojaId, gerenteId), além de um possível turnoId?"];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "abrirTurno__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/abrirTurno.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/abrirTurno.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/metricasEntity.d.ts", "_102043_/l1/cafeFlow/layer_4_entities/turnoEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/abrirTurno" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface AbrirTurnoInput {
        turnoId: string;
    }
    export interface AbrirTurnoOutput {
        turnoId: string;
    }
    export function abrirTurno(_ctx: RequestContext, _input: AbrirTurnoInput): Promise<AbrirTurnoOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/atualizarStatusPedido.defs" {
    export const useCase: {
        readonly usecaseId: "atualizarStatusPedido";
        readonly title: "Atualizar status do pedido";
        readonly purpose: "Atualizar status de preparo e entrega do pedido.";
        readonly actor: "cozinha";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["pedidoEntity"];
        readonly outputEntities: readonly ["pedidoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_status_history";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["orderStatusTransition"];
        readonly entityRefs: readonly ["metricasEntity", "pedidoEntity"];
        readonly commands: readonly [{
            readonly commandId: "atualizarStatusPedido";
            readonly input: readonly [{
                readonly name: "pedidoId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "novoStatus";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "pedido";
                readonly type: "pedidoEntity";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "atualizarStatusPedido__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/atualizarStatusPedido.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/atualizarStatusPedido.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/metricasEntity.d.ts", "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["orderStatusTransition"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/consultarDashboardGerente.defs" {
    export const useCase: {
        readonly usecaseId: "consultarDashboardGerente";
        readonly title: "Consultar dashboard do gerente";
        readonly purpose: "Consultar métricas de vendas, itens mais vendidos e estoque baixo.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["metricasEntity"];
        readonly outputEntities: readonly ["metricasEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["metricasEntity"];
        readonly commands: readonly [{
            readonly commandId: "consultarDashboardGerente";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "metricas";
                readonly type: "metricasEntity";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "consultarDashboardGerente__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/consultarDashboardGerente.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/consultarDashboardGerente.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/metricasEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarOuAtualizarItemCardapio.defs" {
    export const useCase: {
        readonly usecaseId: "criarOuAtualizarItemCardapio";
        readonly title: "Criar ou atualizar item do cardápio";
        readonly purpose: "Cadastrar ou editar item do cardápio.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["cardapioEntity"];
        readonly outputEntities: readonly ["cardapioEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "MenuCategory";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "MenuItem";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly ["menuItemRequiresCategory"];
        readonly entityRefs: readonly ["cardapioEntity"];
        readonly commands: readonly [{
            readonly commandId: "criarOuAtualizarItemCardapio";
            readonly input: readonly [{
                readonly name: "cardapioEntity";
                readonly type: "cardapioEntity";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "cardapioEntity";
                readonly type: "cardapioEntity";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "criarOuAtualizarItemCardapio__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/criarOuAtualizarItemCardapio.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/criarOuAtualizarItemCardapio.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["menuItemRequiresCategory"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarOuAtualizarItemEstoque.defs" {
    export const useCase: {
        readonly usecaseId: "criarOuAtualizarItemEstoque";
        readonly title: "Criar ou atualizar item de estoque";
        readonly purpose: "Cadastrar ou editar item de estoque.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["estoqueEntity"];
        readonly outputEntities: readonly ["estoqueEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "UnitOfMeasure";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "StockItem";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["estoqueEntity"];
        readonly commands: readonly [{
            readonly commandId: "criarOuAtualizarItemEstoque";
            readonly input: readonly [{
                readonly name: "estoqueEntity";
                readonly type: "estoqueEntity";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "estoqueEntity";
                readonly type: "estoqueEntity";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "criarOuAtualizarItemEstoque__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/criarOuAtualizarItemEstoque.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/criarOuAtualizarItemEstoque.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/criarPedido.defs" {
    export const useCase: {
        readonly usecaseId: "criarPedido";
        readonly title: "Criar pedido";
        readonly purpose: "Registrar um novo pedido no POS com itens.";
        readonly actor: "atendente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["pedidoEntity", "cardapioEntity"];
        readonly outputEntities: readonly ["pedidoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "MenuItem";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_status_history";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["orderRequiresItem"];
        readonly entityRefs: readonly ["cardapioEntity", "metricasEntity", "pedidoEntity"];
        readonly commands: readonly [{
            readonly commandId: "criarPedido";
            readonly input: readonly [{
                readonly name: "pedido";
                readonly type: "pedidoEntity";
                readonly required: true;
            }, {
                readonly name: "itens";
                readonly type: "cardapioEntity[]";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "pedido";
                readonly type: "pedidoEntity";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "criarPedido__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/criarPedido.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/criarPedido.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity.d.ts", "_102043_/l1/cafeFlow/layer_4_entities/metricasEntity.d.ts", "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["orderRequiresItem"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/fecharTurno.defs" {
    export const useCase: {
        readonly usecaseId: "fecharTurno";
        readonly title: "Fechar turno";
        readonly purpose: "Encerrar o turno e gerar relatório de fechamento.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["turnoEntity", "pedidoEntity"];
        readonly outputEntities: readonly ["turnoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "shifts";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "shifts";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "shift_reports";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
        readonly entityRefs: readonly ["metricasEntity", "pedidoEntity", "turnoEntity"];
        readonly commands: readonly [{
            readonly commandId: "fecharTurno";
            readonly input: readonly [{
                readonly name: "turnoId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "turnoId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "fecharTurno__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/fecharTurno.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/fecharTurno.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/metricasEntity.d.ts", "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity.d.ts", "_102043_/l1/cafeFlow/layer_4_entities/turnoEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarAlertasEstoqueBaixo.defs" {
    export const useCase: {
        readonly usecaseId: "listarAlertasEstoqueBaixo";
        readonly title: "Listar alertas de estoque baixo";
        readonly purpose: "Consultar alertas de estoque baixo.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["estoqueEntity"];
        readonly outputEntities: readonly ["estoqueEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "low_stock_alerts";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["estoqueEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarAlertasEstoqueBaixo";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "alertas";
                readonly type: "estoqueEntity[]";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "listarAlertasEstoqueBaixo__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarAlertasEstoqueBaixo.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarAlertasEstoqueBaixo.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarCategoriasCardapio.defs" {
    export const useCase: {
        readonly usecaseId: "listarCategoriasCardapio";
        readonly title: "Listar categorias do cardápio";
        readonly purpose: "Consultar categorias disponíveis para cardápio.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["cardapioEntity"];
        readonly outputEntities: readonly ["cardapioEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "MenuCategory";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["cardapioEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarCategoriasCardapio";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "categorias";
                readonly type: "MenuCategory[]";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "listarCategoriasCardapio__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarCategoriasCardapio.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarCategoriasCardapio.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarItensCardapio.defs" {
    export const useCase: {
        readonly usecaseId: "listarItensCardapio";
        readonly title: "Listar itens do cardápio";
        readonly purpose: "Consultar itens do cardápio e suas categorias.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["cardapioEntity"];
        readonly outputEntities: readonly ["cardapioEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "MenuItem";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "MenuCategory";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["cardapioEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarItensCardapio";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "itensCardapio";
                readonly type: "cardapioEntity[]";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "listarItensCardapio__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarItensCardapio.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarItensCardapio.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarItensEstoque.defs" {
    export const useCase: {
        readonly usecaseId: "listarItensEstoque";
        readonly title: "Listar itens de estoque";
        readonly purpose: "Consultar itens de estoque cadastrados.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["estoqueEntity"];
        readonly outputEntities: readonly ["estoqueEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "StockItem";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "UnitOfMeasure";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["estoqueEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarItensEstoque";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "itensEstoque";
                readonly type: "estoqueEntity[]";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "listarItensEstoque__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarItensEstoque.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarItensEstoque.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarMovimentacoesEstoque.defs" {
    export const useCase: {
        readonly usecaseId: "listarMovimentacoesEstoque";
        readonly title: "Listar movimentações de estoque";
        readonly purpose: "Consultar histórico de movimentações de estoque.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["estoqueEntity"];
        readonly outputEntities: readonly ["estoqueEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "stock_movements";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["estoqueEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarMovimentacoesEstoque";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "movimentacoes";
                readonly type: "estoqueEntity[]";
            }];
        }];
        readonly pendingQuestions: readonly ["Quais filtros de entrada são obrigatórios ou opcionais para listar movimentações (por exemplo, estoqueId, período, produto, depósito)?", "Quais campos devem compor cada item retornado em uma movimentação de estoque?"];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "listarMovimentacoesEstoque__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarMovimentacoesEstoque.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarMovimentacoesEstoque.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidos.defs" {
    export const useCase: {
        readonly usecaseId: "listarPedidos";
        readonly title: "Listar pedidos";
        readonly purpose: "Listar pedidos com status atual.";
        readonly actor: "atendente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["pedidoEntity"];
        readonly outputEntities: readonly ["pedidoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_status_history";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["pedidoEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarPedidos";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "pedidos";
                readonly type: "pedidoEntity[]";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "listarPedidos__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidos.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidos.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidosCozinha.defs" {
    export const useCase: {
        readonly usecaseId: "listarPedidosCozinha";
        readonly title: "Listar pedidos para cozinha";
        readonly purpose: "Exibir fila de pedidos para preparo.";
        readonly actor: "cozinha";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["pedidoEntity"];
        readonly outputEntities: readonly ["pedidoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["pedidoEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarPedidosCozinha";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "pedidos";
                readonly type: "pedidoEntity[]";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "listarPedidosCozinha__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidosCozinha.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarPedidosCozinha.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarSolicitacoesResumoVendas.defs" {
    export const useCase: {
        readonly usecaseId: "listarSolicitacoesResumoVendas";
        readonly title: "Listar solicitações de resumo de vendas";
        readonly purpose: "Consultar solicitações de resumo de vendas registradas.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["resumoVendasEntity"];
        readonly outputEntities: readonly ["resumoVendasEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "sales_summary_requests";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["resumoVendasEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarSolicitacoesResumoVendas";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "solicitacoes";
                readonly type: "resumoVendasEntity[]";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "listarSolicitacoesResumoVendas__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarSolicitacoesResumoVendas.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarSolicitacoesResumoVendas.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/resumoVendasEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/resumoVendasEntity" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IDataRuntime } from '_102034_/l1/server/layer_1_external/data/runtime';
    export interface ResumoVendasRecord {
        sales_summary_request_id: string;
        shift_report_id: string;
        created_at: string;
        updated_at: string;
    }
    export interface CreateResumoVendasInput {
        shiftReportId: string;
    }
    export interface ListResumoVendasFilter {
        shiftReportId?: string;
    }
    export interface IResumoVendasEntity {
        create(ctx: RequestContext, input: CreateResumoVendasInput, runtime?: IDataRuntime): Promise<ResumoVendasRecord>;
        getById(ctx: RequestContext, salesSummaryRequestId: string, runtime?: IDataRuntime): Promise<ResumoVendasRecord>;
        list(ctx: RequestContext, filter?: ListResumoVendasFilter, runtime?: IDataRuntime): Promise<ResumoVendasRecord[]>;
    }
    export const ResumoVendasEntity: IResumoVendasEntity;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarSolicitacoesResumoVendas" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type ResumoVendasRecord } from "_102043_/l1/cafeFlow/layer_4_entities/resumoVendasEntity";
    export interface ListarSolicitacoesResumoVendasInput {
    }
    export interface ListarSolicitacoesResumoVendasOutput {
        solicitacoes: ResumoVendasRecord[];
    }
    export function listarSolicitacoesResumoVendas(ctx: RequestContext, _input: ListarSolicitacoesResumoVendasInput): Promise<ListarSolicitacoesResumoVendasOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/listarTurnos.defs" {
    export const useCase: {
        readonly usecaseId: "listarTurnos";
        readonly title: "Listar turnos";
        readonly purpose: "Consultar turnos diários.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["turnoEntity"];
        readonly outputEntities: readonly ["turnoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "shifts";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["turnoEntity"];
        readonly commands: readonly [{
            readonly commandId: "listarTurnos";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "turnos";
                readonly type: "turnoEntity[]";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "listarTurnos__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarTurnos.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/listarTurnos.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/turnoEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/obterPedido.defs" {
    export const useCase: {
        readonly usecaseId: "obterPedido";
        readonly title: "Obter pedido";
        readonly purpose: "Consultar detalhes de um pedido.";
        readonly actor: "atendente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["pedidoEntity"];
        readonly outputEntities: readonly ["pedidoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_status_history";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["pedidoEntity"];
        readonly commands: readonly [{
            readonly commandId: "obterPedido";
            readonly input: readonly [{
                readonly name: "pedidoId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "pedido";
                readonly type: "pedidoEntity";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "obterPedido__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/obterPedido.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/obterPedido.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/obterPedido" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type PedidoRecord } from "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity";
    export interface ObterPedidoInput {
        pedidoId: string;
    }
    export interface ObterPedidoOutput {
        pedido: PedidoRecord;
    }
    export function obterPedido(ctx: RequestContext, input: ObterPedidoInput): Promise<ObterPedidoOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/obterRelatorioTurno.defs" {
    export const useCase: {
        readonly usecaseId: "obterRelatorioTurno";
        readonly title: "Obter relatório de turno";
        readonly purpose: "Consultar relatório de fechamento de um turno.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["turnoEntity"];
        readonly outputEntities: readonly ["turnoEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "shift_reports";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["turnoEntity"];
        readonly commands: readonly [{
            readonly commandId: "obterRelatorioTurno";
            readonly input: readonly [{
                readonly name: "turnoId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "turno";
                readonly type: "turnoEntity";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "obterRelatorioTurno__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/obterRelatorioTurno.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/obterRelatorioTurno.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/turnoEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/registrarMovimentacaoEstoque.defs" {
    export const useCase: {
        readonly usecaseId: "registrarMovimentacaoEstoque";
        readonly title: "Registrar movimentação de estoque";
        readonly purpose: "Registrar entrada ou saída de estoque e gerar alerta quando necessário.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["estoqueEntity"];
        readonly outputEntities: readonly ["estoqueEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "StockItem";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "UnitOfMeasure";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "stock_movements";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_alerts";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["lowStockThresholdRule"];
        readonly entityRefs: readonly ["estoqueEntity", "metricasEntity"];
        readonly commands: readonly [{
            readonly commandId: "registrarMovimentacaoEstoque";
            readonly input: readonly [{
                readonly name: "stockItemId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "movementType";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "quantity";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "unitOfMeasureId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "movementDate";
                readonly type: "date";
                readonly required: false;
            }, {
                readonly name: "reason";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "stockItemId";
                readonly type: "string";
            }, {
                readonly name: "quantity";
                readonly type: "number";
            }];
        }];
        readonly pendingQuestions: readonly ["Quais campos obrigatórios devem compor a movimentação (ex.: data, motivo)?", "O tipo de movimentação é um enum específico (ex.: ENTRADA/SAÍDA)? Se sim, qual o identificador do enum?", "A resposta deve incluir algum indicador/ID de alerta de estoque baixo ou apenas o estoque atualizado?"];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "registrarMovimentacaoEstoque__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/registrarMovimentacaoEstoque.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/registrarMovimentacaoEstoque.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity.d.ts", "_102043_/l1/cafeFlow/layer_4_entities/metricasEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["lowStockThresholdRule"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/solicitarResumoVendasDia.defs" {
    export const useCase: {
        readonly usecaseId: "solicitarResumoVendasDia";
        readonly title: "Solicitar resumo de vendas do dia";
        readonly purpose: "Registrar solicitação de resumo de vendas para o assistente IA.";
        readonly actor: "gerente";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["resumoVendasEntity"];
        readonly outputEntities: readonly ["resumoVendasEntity"];
        readonly readsTables: readonly [];
        readonly writesTables: readonly [{
            readonly tableName: "sales_summary_requests";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["salesSummaryUsesLast7Days"];
        readonly entityRefs: readonly ["resumoVendasEntity"];
        readonly commands: readonly [{
            readonly commandId: "solicitarResumoVendasDia";
            readonly input: readonly [{
                readonly name: "resumoVendas";
                readonly type: "resumoVendasEntity";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "resumoVendas";
                readonly type: "resumoVendasEntity";
            }];
        }];
    };
    export default useCase;
    export const pipeline: readonly [{
        readonly id: "solicitarResumoVendasDia__layer_3_usecases";
        readonly type: "layer_3_usecases";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_3_usecases/solicitarResumoVendasDia.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_3_usecases/solicitarResumoVendasDia.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_4_entities/resumoVendasEntity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_3.md"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["salesSummaryUsesLast7Days"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/solicitarResumoVendasDia" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import { type CreateResumoVendasInput, type ResumoVendasRecord } from "_102043_/l1/cafeFlow/layer_4_entities/resumoVendasEntity";
    export interface SolicitarResumoVendasDiaInput {
        resumoVendas: CreateResumoVendasInput;
    }
    export interface SolicitarResumoVendasDiaOutput {
        resumoVendas: ResumoVendasRecord;
    }
    export function solicitarResumoVendasDia(ctx: RequestContext, input: SolicitarResumoVendasDiaInput): Promise<SolicitarResumoVendasDiaOutput>;
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity.defs" {
    export const entity: {
        readonly entityId: "cardapioEntity";
        readonly title: "Entidade de caso de uso: Cardápio";
        readonly purpose: "Gerenciar itens e categorias do cardápio.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "menuItemId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do item do cardápio.";
        }, {
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
            readonly description: "Nome do item do cardápio.";
        }, {
            readonly fieldId: "description";
            readonly type: "text";
            readonly required: false;
            readonly description: "Descrição do item do cardápio.";
        }, {
            readonly fieldId: "price";
            readonly type: "money";
            readonly required: true;
            readonly description: "Preço de venda do item do cardápio.";
        }, {
            readonly fieldId: "menuCategoryId";
            readonly type: "MenuCategory";
            readonly required: true;
            readonly description: "Categoria à qual o item do cardápio pertence.";
        }, {
            readonly fieldId: "isActive";
            readonly type: "boolean";
            readonly required: true;
            readonly description: "Indica se o item do cardápio está ativo para venda.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do item do cardápio.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do item do cardápio.";
        }];
        readonly sourceTables: readonly [{
            readonly tableName: "MenuItem";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "MenuCategory";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "MenuItem";
            readonly domainId: "menu";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["Todo item do cardápio deve estar associado a uma categoria ativa (regra menuItemRequiresCategory).", "Apenas o ator gerente pode criar, editar ou inativar itens e categorias do cardápio.", "Itens inativados não devem aparecer no POS para novos pedidos."];
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "MenuCategory";
            readonly domainId: "menu";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["Todo item do cardápio deve estar associado a uma categoria ativa (regra menuItemRequiresCategory).", "Apenas o ator gerente pode criar, editar ou inativar itens e categorias do cardápio.", "Itens inativados não devem aparecer no POS para novos pedidos."];
        }];
        readonly allowedOperations: readonly ["create", "update", "read", "list"];
        readonly rulesApplied: readonly ["menuItemRequiresCategory"];
        readonly usecaseRefs: readonly ["criarPedido", "criarOuAtualizarItemCardapio", "listarItensCardapio", "listarCategoriasCardapio"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/CardapioEntity.ts";
            readonly className: "CardapioEntity";
            readonly contractName: "ICardapioEntity";
        };
    };
    export default entity;
    export const pipeline: readonly [{
        readonly id: "cardapioEntity__layer_4_entities";
        readonly type: "layer_4_entities";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_4_entities/cardapioEntity.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["menuItemRequiresCategory"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity.defs" {
    export const entity: {
        readonly entityId: "estoqueEntity";
        readonly title: "Entidade de caso de uso: Estoque";
        readonly purpose: "Controlar movimentações e alertas de estoque.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "stockMovementId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da movimentação de estoque.";
        }, {
            readonly fieldId: "stockItemId";
            readonly type: "StockItem";
            readonly required: true;
            readonly description: "Item de estoque associado à movimentação.";
        }, {
            readonly fieldId: "orderId";
            readonly type: "Order";
            readonly required: false;
            readonly description: "Pedido vinculado à saída de estoque, quando aplicável.";
        }, {
            readonly fieldId: "movementType";
            readonly type: "string";
            readonly required: true;
            readonly description: "Tipo de movimentação realizada.";
            readonly enum: readonly ["entrada", "saida", "ajuste"];
        }, {
            readonly fieldId: "quantity";
            readonly type: "number";
            readonly required: true;
            readonly description: "Quantidade movimentada do item de estoque.";
        }, {
            readonly fieldId: "reason";
            readonly type: "text";
            readonly required: false;
            readonly description: "Motivo ou observação da movimentação, especialmente para ajustes.";
        }, {
            readonly fieldId: "occurredAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora em que a movimentação ocorreu.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro.";
        }];
        readonly sourceTables: readonly [{
            readonly tableName: "stock_movements";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_alerts";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "StockItem";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "UnitOfMeasure";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "stockMovement";
            readonly tableName: "stock_movements";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/stockMovement.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "lowStockAlert";
            readonly tableName: "low_stock_alerts";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/lowStockAlert.defs.ts";
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "StockItem";
            readonly domainId: "stock";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["Gerar alerta quando nível de estoque ficar abaixo do mínimo definido (regra lowStockThresholdRule).", "Apenas o ator gerente pode cadastrar ou ajustar itens de estoque e unidades de medida.", "Unidades de medida não podem ser excluídas se estiverem vinculadas a itens de estoque."];
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "UnitOfMeasure";
            readonly domainId: "stock";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["Gerar alerta quando nível de estoque ficar abaixo do mínimo definido (regra lowStockThresholdRule).", "Apenas o ator gerente pode cadastrar ou ajustar itens de estoque e unidades de medida.", "Unidades de medida não podem ser excluídas se estiverem vinculadas a itens de estoque."];
        }];
        readonly allowedOperations: readonly ["create", "update", "read", "list"];
        readonly rulesApplied: readonly ["lowStockThresholdRule"];
        readonly usecaseRefs: readonly ["criarOuAtualizarItemEstoque", "listarItensEstoque", "registrarMovimentacaoEstoque", "listarMovimentacoesEstoque", "listarAlertasEstoqueBaixo"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/EstoqueEntity.ts";
            readonly className: "EstoqueEntity";
            readonly contractName: "IEstoqueEntity";
        };
    };
    export default entity;
    export const pipeline: readonly [{
        readonly id: "estoqueEntity__layer_4_entities";
        readonly type: "layer_4_entities";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_4_entities/estoqueEntity.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_1_external/stockMovement.d.ts", "_102043_/l1/cafeFlow/layer_1_external/lowStockAlert.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["lowStockThresholdRule"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/metricasEntity.defs" {
    export const entity: {
        readonly entityId: "metricasEntity";
        readonly title: "Entidade de caso de uso: Métricas";
        readonly purpose: "Ler métricas operacionais e atualizar métricas derivadas.";
        readonly layer: "layer_4_entities";
        readonly sourceTables: readonly [{
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "metricTable";
            readonly metricTableId: "dailySalesMetrics";
            readonly tableName: "daily_sales_metrics";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/dailySalesMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "topSellingItemsMetrics";
            readonly tableName: "top_selling_items_metrics";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "lowStockMetrics";
            readonly tableName: "low_stock_metrics";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/lowStockMetrics.defs.ts";
        }];
        readonly allowedOperations: readonly ["read", "update"];
        readonly rulesApplied: readonly [];
        readonly usecaseRefs: readonly ["criarPedido", "atualizarStatusPedido", "registrarMovimentacaoEstoque", "abrirTurno", "fecharTurno", "consultarDashboardGerente"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/MetricasEntity.ts";
            readonly className: "MetricasEntity";
            readonly contractName: "IMetricasEntity";
        };
    };
    export default entity;
    export const pipeline: readonly [{
        readonly id: "metricasEntity__layer_4_entities";
        readonly type: "layer_4_entities";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_4_entities/metricasEntity.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_4_entities/metricasEntity.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_1_external/dailySalesMetrics.d.ts", "_102043_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.d.ts", "_102043_/l1/cafeFlow/layer_1_external/lowStockMetrics.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity.defs" {
    export const entity: {
        readonly entityId: "pedidoEntity";
        readonly title: "Entidade de caso de uso: Pedido";
        readonly purpose: "Gerenciar pedidos e histórico de status.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "orderId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do pedido.";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Status atual do pedido.";
            readonly enum: readonly ["recebido", "emPreparo", "pronto", "entregue", "cancelado"];
        }, {
            readonly fieldId: "shiftId";
            readonly type: "Shift";
            readonly required: true;
            readonly description: "Turno em que o pedido foi registrado.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do pedido.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do pedido.";
        }];
        readonly statusEnum: readonly ["recebido", "emPreparo", "pronto", "entregue", "cancelado"];
        readonly sourceTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_status_history";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "order";
            readonly tableName: "orders";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/order.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "orderStatusHistory";
            readonly tableName: "order_status_history";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/orderStatusHistory.defs.ts";
        }];
        readonly allowedOperations: readonly ["create", "update", "read", "list"];
        readonly rulesApplied: readonly ["orderRequiresItem", "orderStatusTransition"];
        readonly usecaseRefs: readonly ["criarPedido", "listarPedidos", "obterPedido", "listarPedidosCozinha", "atualizarStatusPedido", "fecharTurno"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/PedidoEntity.ts";
            readonly className: "PedidoEntity";
            readonly contractName: "IPedidoEntity";
        };
    };
    export default entity;
    export const pipeline: readonly [{
        readonly id: "pedidoEntity__layer_4_entities";
        readonly type: "layer_4_entities";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_4_entities/pedidoEntity.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_1_external/order.d.ts", "_102043_/l1/cafeFlow/layer_1_external/orderStatusHistory.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["orderRequiresItem", "orderStatusTransition"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/resumoVendasEntity.defs" {
    export const entity: {
        readonly entityId: "resumoVendasEntity";
        readonly title: "Entidade de caso de uso: Resumo de vendas";
        readonly purpose: "Registrar solicitações de resumo de vendas do dia.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "salesSummaryRequestId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da solicitação de resumo de vendas.";
        }, {
            readonly fieldId: "shiftReportId";
            readonly type: "ShiftReport";
            readonly required: true;
            readonly description: "Referência à consolidação de vendas usada na solicitação.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação da solicitação.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização da solicitação.";
        }];
        readonly sourceTables: readonly [{
            readonly tableName: "sales_summary_requests";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "salesSummaryRequest";
            readonly tableName: "sales_summary_requests";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/salesSummaryRequest.defs.ts";
        }];
        readonly allowedOperations: readonly ["create", "read", "list"];
        readonly rulesApplied: readonly ["salesSummaryUsesLast7Days"];
        readonly usecaseRefs: readonly ["solicitarResumoVendasDia", "listarSolicitacoesResumoVendas"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/ResumoVendasEntity.ts";
            readonly className: "ResumoVendasEntity";
            readonly contractName: "IResumoVendasEntity";
        };
    };
    export default entity;
    export const pipeline: readonly [{
        readonly id: "resumoVendasEntity__layer_4_entities";
        readonly type: "layer_4_entities";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_4_entities/resumoVendasEntity.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_4_entities/resumoVendasEntity.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_1_external/salesSummaryRequest.d.ts", "_102043_/l1/cafeFlow/layer_1_external/shiftReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["salesSummaryUsesLast7Days"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l1/cafeFlow/layer_4_entities/turnoEntity.defs" {
    export const entity: {
        readonly entityId: "turnoEntity";
        readonly title: "Entidade de caso de uso: Turno";
        readonly purpose: "Gerenciar turnos diários e relatórios de fechamento.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "shiftId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do turno.";
        }, {
            readonly fieldId: "shiftConfigId";
            readonly type: "ShiftConfig";
            readonly required: true;
            readonly description: "Configuração de turno aplicada ao período operacional.";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Status atual do turno.";
            readonly enum: readonly ["aberto", "emFechamento", "fechado"];
        }, {
            readonly fieldId: "openedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de abertura do turno.";
        }, {
            readonly fieldId: "closedAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data e hora de fechamento do turno.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro.";
        }];
        readonly statusEnum: readonly ["aberto", "emFechamento", "fechado"];
        readonly sourceTables: readonly [{
            readonly tableName: "shifts";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "shift_reports";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "ShiftConfig";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "shift";
            readonly tableName: "shifts";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/shift.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "shiftReport";
            readonly tableName: "shift_reports";
            readonly fileRef: "_102043_/l1/cafeFlow/layer_1_external/shiftReport.defs.ts";
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "ShiftConfig";
            readonly domainId: "shiftConfig";
            readonly sourceOfTruth: "102034";
            readonly governanceRules: readonly ["Apenas o ator gerente pode alterar configurações de turno.", "Configurações de turno não podem ser removidas se houver turnos históricos vinculados."];
        }];
        readonly allowedOperations: readonly ["create", "update", "read", "list"];
        readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
        readonly usecaseRefs: readonly ["abrirTurno", "fecharTurno", "listarTurnos", "obterRelatorioTurno"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/TurnoEntity.ts";
            readonly className: "TurnoEntity";
            readonly contractName: "ITurnoEntity";
        };
    };
    export default entity;
    export const pipeline: readonly [{
        readonly id: "turnoEntity__layer_4_entities";
        readonly type: "layer_4_entities";
        readonly outputPath: "_102043_/l1/cafeFlow/layer_4_entities/turnoEntity.ts";
        readonly defPath: "_102043_/l1/cafeFlow/layer_4_entities/turnoEntity.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l1/cafeFlow/layer_1_external/shift.d.ts", "_102043_/l1/cafeFlow/layer_1_external/shiftReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/skills/layer_4.md", "_102034_.d.ts"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102043_/l2/cafeFlow/cardapioEstoque.defs" {
    export const cardapioEstoquePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "cardapioEstoque";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 57;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "cardapioEstoque";
                readonly pageName: "Cardápio e estoque";
                readonly actor: "gerente";
                readonly purpose: "Gerenciar itens do cardápio, categorias, estoque e alertas de baixo estoque.";
                readonly capabilities: readonly ["gerenciarCardapio", "gerenciarEstoque"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["lowStockAlertWorkflow"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["menu", "stock"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "dashboardGerente";
                    readonly trigger: "Ver métricas de vendas/estoque";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Gestão de cardápio";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "FiltroEListaItensCardapio";
                        readonly purpose: "Filtrar e visualizar itens do cardápio e suas categorias.";
                        readonly userActions: readonly ["filtrarItensCardapio", "selecionarItemCardapio"];
                        readonly requiredEntities: readonly ["MenuItem", "MenuCategory"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "CadastroEdicaoItemCardapio";
                        readonly purpose: "Criar ou atualizar item do cardápio associado a uma categoria.";
                        readonly userActions: readonly ["criarItemCardapio", "editarItemCardapio"];
                        readonly requiredEntities: readonly ["MenuItem", "MenuCategory"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["menuItemRequiresCategory"];
                    }, {
                        readonly organismName: "ListaCategoriasCardapio";
                        readonly purpose: "Exibir categorias disponíveis para seleção no item do cardápio.";
                        readonly userActions: readonly ["selecionarCategoriaCardapio"];
                        readonly requiredEntities: readonly ["MenuCategory"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Gestão de estoque";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "FiltroEListaItensEstoque";
                        readonly purpose: "Filtrar e visualizar itens de estoque com quantidades.";
                        readonly userActions: readonly ["filtrarItensEstoque", "selecionarItemEstoque"];
                        readonly requiredEntities: readonly ["StockItem", "UnitOfMeasure"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "CadastroEdicaoItemEstoque";
                        readonly purpose: "Criar ou atualizar item de estoque e unidade de medida.";
                        readonly userActions: readonly ["criarItemEstoque", "editarItemEstoque"];
                        readonly requiredEntities: readonly ["StockItem", "UnitOfMeasure"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "RegistroMovimentacaoEstoque";
                        readonly purpose: "Registrar entrada, saída ou ajuste de estoque.";
                        readonly userActions: readonly ["registrarEntradaEstoque", "registrarSaidaEstoque", "registrarAjusteEstoque"];
                        readonly requiredEntities: readonly ["StockMovement", "StockItem"];
                        readonly readsFields: readonly ["stockItemId", "movementType", "quantity", "reason", "occurredAt"];
                        readonly writesFields: readonly ["stockItemId", "movementType", "quantity", "reason", "occurredAt"];
                        readonly rulesApplied: readonly ["lowStockThresholdRule"];
                    }, {
                        readonly organismName: "HistoricoMovimentacoesEstoque";
                        readonly purpose: "Exibir histórico de movimentações por item e período.";
                        readonly userActions: readonly ["filtrarMovimentacoesEstoque", "inspecionarMovimentacao"];
                        readonly requiredEntities: readonly ["StockMovement"];
                        readonly readsFields: readonly ["stockMovementId", "stockItemId", "movementType", "quantity", "reason", "occurredAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "AlertasEstoqueBaixo";
                        readonly purpose: "Visualizar alertas de estoque baixo e status.";
                        readonly userActions: readonly ["filtrarAlertasEstoqueBaixo", "verDetalheAlerta"];
                        readonly requiredEntities: readonly ["LowStockAlert"];
                        readonly readsFields: readonly ["lowStockAlertId", "stockItemId", "triggeredAt", "currentQuantity", "minimumQuantity", "status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["lowStockThresholdRule"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listarItensCardapio";
                readonly purpose: "Exibir itens do cardápio";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "categoriaId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "disponivel";
                    readonly type: "boolean";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                }, {
                    readonly name: "nome";
                    readonly type: "string";
                }, {
                    readonly name: "preco";
                    readonly type: "number";
                }, {
                    readonly name: "categoriaId";
                    readonly type: "string";
                }, {
                    readonly name: "ativo";
                    readonly type: "boolean";
                }];
                readonly readsEntities: readonly ["MenuItem", "MenuCategory"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarItensCardapio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listarCategoriasCardapio";
                readonly purpose: "Exibir categorias do cardápio para seleção";
                readonly kind: "query";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "categoriaId";
                    readonly type: "string";
                }, {
                    readonly name: "nome";
                    readonly type: "string";
                }, {
                    readonly name: "ativo";
                    readonly type: "boolean";
                }];
                readonly readsEntities: readonly ["MenuCategory"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarCategoriasCardapio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "criarOuAtualizarItemCardapio";
                readonly purpose: "Criar ou atualizar item do cardápio";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "nome";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "preco";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "categoriaId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "ativo";
                    readonly type: "boolean";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["MenuCategory"];
                readonly writesEntities: readonly ["MenuItem"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["criarOuAtualizarItemCardapio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["menuItemRequiresCategory"];
            }, {
                readonly commandName: "listarItensEstoque";
                readonly purpose: "Exibir itens de estoque com quantidades";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "categoriaId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                }, {
                    readonly name: "nome";
                    readonly type: "string";
                }, {
                    readonly name: "quantidadeAtual";
                    readonly type: "number";
                }, {
                    readonly name: "unidadeMedidaId";
                    readonly type: "string";
                }, {
                    readonly name: "quantidadeMinima";
                    readonly type: "number";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["StockItem", "UnitOfMeasure"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarItensEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "criarOuAtualizarItemEstoque";
                readonly purpose: "Criar ou atualizar item de estoque";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "nome";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "unidadeMedidaId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "quantidadeMinima";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "ativo";
                    readonly type: "boolean";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["UnitOfMeasure"];
                readonly writesEntities: readonly ["StockItem"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["criarOuAtualizarItemEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "registrarMovimentacaoEstoque";
                readonly purpose: "Registrar entrada/saída/ajuste de estoque";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "movementType";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "occurredAt";
                    readonly type: "date";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "stockMovementId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["StockItem", "UnitOfMeasure"];
                readonly writesEntities: readonly ["StockMovement", "LowStockAlert"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["stock_movements", "low_stock_alerts", "low_stock_metrics"];
                readonly usecaseRefs: readonly ["registrarMovimentacaoEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["lowStockThresholdRule"];
            }, {
                readonly commandName: "listarMovimentacoesEstoque";
                readonly purpose: "Exibir histórico de movimentações";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "dataInicio";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "dataFim";
                    readonly type: "date";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "stockMovementId";
                    readonly type: "string";
                }, {
                    readonly name: "stockItemId";
                    readonly type: "string";
                }, {
                    readonly name: "movementType";
                    readonly type: "string";
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                }, {
                    readonly name: "occurredAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["StockMovement"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["stock_movements"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarMovimentacoesEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listarAlertasEstoqueBaixo";
                readonly purpose: "Exibir alertas de estoque baixo";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "lowStockAlertId";
                    readonly type: "string";
                }, {
                    readonly name: "stockItemId";
                    readonly type: "string";
                }, {
                    readonly name: "triggeredAt";
                    readonly type: "date";
                }, {
                    readonly name: "currentQuantity";
                    readonly type: "number";
                }, {
                    readonly name: "minimumQuantity";
                    readonly type: "number";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["LowStockAlert"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["low_stock_alerts"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarAlertasEstoqueBaixo"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["lowStockThresholdRule"];
            }];
        };
    };
    export default cardapioEstoquePagePlan;
}
declare module "_102043_/l2/cafeFlow/dashboardGerente.defs" {
    export const dashboardGerentePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "dashboardGerente";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 59;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "dashboardGerente";
                readonly pageName: "Dashboard do gerente";
                readonly actor: "gerente";
                readonly purpose: "Acompanhar métricas operacionais e de vendas do dia.";
                readonly capabilities: readonly ["consultarDashboard"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "periodoInicio";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Data inicial do período para filtros do dashboard.";
                }, {
                    readonly name: "periodoFim";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Data final do período para filtros do dashboard.";
                }, {
                    readonly name: "turnoId";
                    readonly type: "turnoId";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Turno selecionado para filtrar métricas.";
                    readonly entityRef: "turnoEntity";
                    readonly fieldRef: "turnoId";
                }, {
                    readonly name: "statusAlerta";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Status do alerta de estoque baixo para filtragem.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "cardapioEstoque";
                    readonly trigger: "Acessar métricas a partir do cardápio/estoque";
                }, {
                    readonly direction: "inbound";
                    readonly pageId: "fechamentoTurno";
                    readonly trigger: "Acessar métricas após fechamento";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "VisaoGeralDoDia";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "ResumoVendasDiarias";
                        readonly purpose: "Exibir receita total, quantidade de pedidos e ticket médio do período.";
                        readonly userActions: readonly ["viewDashboard"];
                        readonly requiredEntities: readonly ["metricasEntity"];
                        readonly readsFields: readonly ["metricasEntity.totalRevenue", "metricasEntity.orderCount", "metricasEntity.averageTicket", "metricasEntity.itemsSold"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "GraficoVendasPorTurno";
                        readonly purpose: "Exibir evolução de vendas por turno no período selecionado.";
                        readonly userActions: readonly ["viewDashboard"];
                        readonly requiredEntities: readonly ["metricasEntity"];
                        readonly readsFields: readonly ["metricasEntity.totalRevenue", "metricasEntity.orderCount", "metricasEntity.shiftId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "ItensMaisVendidos";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "RankingItensMaisVendidos";
                        readonly purpose: "Listar itens mais vendidos e receita gerada.";
                        readonly userActions: readonly ["viewDashboard"];
                        readonly requiredEntities: readonly ["metricasEntity"];
                        readonly readsFields: readonly ["metricasEntity.menuItemId", "metricasEntity.menuCategoryId", "metricasEntity.quantitySold", "metricasEntity.itemRevenue", "metricasEntity.orderCount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "AlertasDeEstoqueBaixo";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "ListaAlertasEstoqueBaixo";
                        readonly purpose: "Exibir alertas ativos de estoque baixo.";
                        readonly userActions: readonly ["viewDashboard"];
                        readonly requiredEntities: readonly ["estoqueEntity"];
                        readonly readsFields: readonly ["estoqueEntity.stockItemId", "estoqueEntity.currentQuantity", "estoqueEntity.thresholdValue", "estoqueEntity.alertCount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "consultarDashboardGerente";
                readonly purpose: "Carregar métricas e visão geral do dia.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "periodoInicio";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "periodoFim";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "turnoId";
                    readonly type: "turnoId";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "totalRevenue";
                    readonly type: "number";
                }, {
                    readonly name: "orderCount";
                    readonly type: "number";
                }, {
                    readonly name: "averageTicket";
                    readonly type: "number";
                }, {
                    readonly name: "itemsSold";
                    readonly type: "number";
                }, {
                    readonly name: "serieVendasPorTurno";
                    readonly type: "metricasEntityId";
                }, {
                    readonly name: "rankingItensMaisVendidos";
                    readonly type: "metricasEntityId";
                }];
                readonly readsEntities: readonly ["metricasEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["consultarDashboardGerente"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listarAlertasEstoqueBaixo";
                readonly purpose: "Exibir alertas de estoque baixo no painel.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "statusAlerta";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "alertas";
                    readonly type: "estoqueEntityId";
                }];
                readonly readsEntities: readonly ["estoqueEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarAlertasEstoqueBaixo"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default dashboardGerentePagePlan;
}
declare module "_102043_/l2/cafeFlow/fechamentoTurno.defs" {
    export const fechamentoTurnoPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "fechamentoTurno";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 58;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "fechamentoTurno";
                readonly pageName: "Fechamento de turno";
                readonly actor: "gerente";
                readonly purpose: "Validar pedidos do turno e confirmar o fechamento com geração de relatório.";
                readonly capabilities: readonly ["fecharTurno"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["shiftClosureWorkflow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["shiftConfig"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "dashboardGerente";
                    readonly trigger: "Ver resumo do turno";
                    readonly description: "Após confirmar o fechamento e revisar o relatório.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Seleção de turno";
                    readonly mode: "selection";
                    readonly organisms: readonly [{
                        readonly organismName: "Seletor de turno";
                        readonly purpose: "Selecionar o turno a fechar e visualizar seu status.";
                        readonly userActions: readonly ["selecionarTurno"];
                        readonly requiredEntities: readonly ["Shift"];
                        readonly readsFields: readonly ["Shift.shiftId", "Shift.status", "Shift.openedAt", "Shift.closedAt", "Shift.shiftConfigId"];
                        readonly writesFields: readonly ["Shift.shiftId"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Validação de pedidos do turno";
                    readonly mode: "review";
                    readonly organisms: readonly [{
                        readonly organismName: "Lista de pedidos do turno";
                        readonly purpose: "Validar se todos os pedidos do turno estão finalizados.";
                        readonly userActions: readonly ["filtrarPedidos", "revisarStatus"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.orderId", "Order.status", "Order.shiftId", "Order.createdAt", "Order.updatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
                    }];
                }, {
                    readonly sectionName: "Relatório do turno";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "Resumo de fechamento";
                        readonly purpose: "Exibir o relatório consolidado do turno selecionado.";
                        readonly userActions: readonly ["visualizarRelatorio"];
                        readonly requiredEntities: readonly ["ShiftReport"];
                        readonly readsFields: readonly ["ShiftReport.shiftReportId", "ShiftReport.shiftId", "ShiftReport.totalSalesAmount", "ShiftReport.totalOrders", "ShiftReport.totalItems", "ShiftReport.notes", "ShiftReport.createdAt", "ShiftReport.updatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Confirmação de fechamento";
                    readonly mode: "action";
                    readonly organisms: readonly [{
                        readonly organismName: "Confirmar fechamento";
                        readonly purpose: "Confirmar o fechamento do turno e gerar o relatório.";
                        readonly userActions: readonly ["confirmarFechamento"];
                        readonly requiredEntities: readonly ["Shift", "ShiftReport", "Order"];
                        readonly readsFields: readonly ["Shift.shiftId", "Shift.status"];
                        readonly writesFields: readonly ["Shift.status", "Shift.closedAt", "ShiftReport.shiftReportId"];
                        readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listarTurnos";
                readonly purpose: "Carregar turnos para seleção.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "dataInicio";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "dataFim";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "Shift";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "openedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "closedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "shiftConfigId";
                    readonly type: "ShiftConfig";
                }];
                readonly readsEntities: readonly ["Shift"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["shifts"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarTurnos"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listarPedidos";
                readonly purpose: "Listar pedidos do turno para validação.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "Shift";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "shiftId";
                    readonly type: "Shift";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["orders", "order_status_history"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarPedidos"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "fecharTurno";
                readonly purpose: "Confirmar fechamento do turno e gerar relatório.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "Shift";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "Shift";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "closedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "shiftReportId";
                    readonly type: "ShiftReport";
                }];
                readonly readsEntities: readonly ["Shift", "Order"];
                readonly writesEntities: readonly ["Shift", "ShiftReport"];
                readonly readsTables: readonly ["shifts", "orders"];
                readonly writesTables: readonly ["shifts", "shift_reports", "daily_sales_metrics"];
                readonly usecaseRefs: readonly ["fecharTurno"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
            }, {
                readonly commandName: "obterRelatorioTurno";
                readonly purpose: "Exibir relatório do turno selecionado.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "Shift";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "shiftReportId";
                    readonly type: "ShiftReport";
                }, {
                    readonly name: "shiftId";
                    readonly type: "Shift";
                }, {
                    readonly name: "totalSalesAmount";
                    readonly type: "money";
                }, {
                    readonly name: "totalOrders";
                    readonly type: "number";
                }, {
                    readonly name: "totalItems";
                    readonly type: "number";
                }, {
                    readonly name: "notes";
                    readonly type: "text";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["ShiftReport"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["shift_reports"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["obterRelatorioTurno"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default fechamentoTurnoPagePlan;
}
declare module "_102043_/l2/cafeFlow/module" {
    import type { AuraModuleFrontendDefinition, IPaths, ISkill, IGenomeConfig } from '_102029_/l2/contracts/bootstrap';
    export const moduleGenome: Record<string, IGenomeConfig>;
    export const shared: IPaths;
    export const skills: ISkill;
    export const moduleStates: {};
    export const moduleShellPreferences: {
        readonly layout: {
            readonly asideMode: {
                readonly desktop: "inline";
                readonly mobile: "fullscreen";
            };
        };
    };
    export const moduleFrontendDefinition: AuraModuleFrontendDefinition;
}
declare module "_102043_/l2/cafeFlow/painelCozinha.defs" {
    export const painelCozinhaPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "painelCozinha";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 56;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "painelCozinha";
                readonly pageName: "Painel da cozinha";
                readonly actor: "cozinha";
                readonly purpose: "Visualizar a fila de pedidos e atualizar status de preparo e entrega.";
                readonly capabilities: readonly ["atualizarStatusCozinha"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderStatusWorkflow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "posRapido";
                    readonly trigger: "Pedidos enviados para preparo";
                    readonly description: "Pedidos confirmados no POS entram na fila da cozinha.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Fila de pedidos";
                    readonly mode: "list";
                    readonly organisms: readonly [{
                        readonly organismName: "ListaDePedidosCozinha";
                        readonly purpose: "Exibir pedidos recebidos para preparo com status atual e horário.";
                        readonly userActions: readonly ["selecionarPedido", "iniciarPreparo", "finalizarPreparo", "cancelarPedido"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.orderId", "Order.status", "Order.createdAt", "Order.shiftId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["orderStatusTransition"];
                    }];
                }, {
                    readonly sectionName: "Detalhe e atualização de status";
                    readonly mode: "detail";
                    readonly organisms: readonly [{
                        readonly organismName: "AtualizarStatusPedido";
                        readonly purpose: "Atualizar status do pedido selecionado conforme o fluxo de preparo.";
                        readonly userActions: readonly ["iniciarPreparo", "finalizarPreparo", "cancelarPedido"];
                        readonly requiredEntities: readonly ["Order", "OrderStatusHistory"];
                        readonly readsFields: readonly ["Order.orderId", "Order.status", "Order.updatedAt"];
                        readonly writesFields: readonly ["Order.status", "Order.updatedAt", "OrderStatusHistory.fromStatus", "OrderStatusHistory.toStatus", "OrderStatusHistory.changedAt", "OrderStatusHistory.changedBy"];
                        readonly rulesApplied: readonly ["orderStatusTransition"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listarPedidosCozinha";
                readonly purpose: "Carregar pedidos recebidos para a fila da cozinha.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "shiftId";
                    readonly type: "Shift";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "createdAt";
                    readonly type: "date";
                }, {
                    readonly name: "shiftId";
                    readonly type: "Shift";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["orders"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarPedidosCozinha"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "atualizarStatusPedido";
                readonly purpose: "Atualizar status do pedido conforme preparo e entrega.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                    readonly required: true;
                }, {
                    readonly name: "novoStatus";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly ["Order", "OrderStatusHistory"];
                readonly readsTables: readonly ["orders"];
                readonly writesTables: readonly ["orders", "order_status_history", "daily_sales_metrics", "top_selling_items_metrics"];
                readonly usecaseRefs: readonly ["atualizarStatusPedido"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["orderStatusTransition"];
            }];
        };
    };
    export default painelCozinhaPagePlan;
}
declare module "_102043_/l2/cafeFlow/posRapido.defs" {
    export const posRapidoPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "posRapido";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 55;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "posRapido";
                readonly pageName: "POS rápido";
                readonly actor: "atendente";
                readonly purpose: "Registrar pedidos rapidamente no POS, revisar itens e confirmar envio para a cozinha.";
                readonly capabilities: readonly ["registrarPedido"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly ["posOrderCaptureWorkflow"];
                    readonly entityLifecycles: readonly ["orderStatusWorkflow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "painelCozinha";
                    readonly trigger: "Pedido enviado para a cozinha";
                    readonly description: "Após confirmação e envio do pedido para preparo.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Pedidos do dia";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "Lista de pedidos do dia";
                        readonly purpose: "Consultar rapidamente pedidos recentes e seus status atuais.";
                        readonly userActions: readonly ["filtrarPorStatus", "filtrarPorPeriodo", "visualizarResumo"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["orderId", "status", "createdAt", "updatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Captura rápida";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "Editor rápido de itens";
                        readonly purpose: "Adicionar e ajustar itens do pedido e observações antes da confirmação.";
                        readonly userActions: readonly ["adicionarItem", "alterarQuantidade", "removerItem", "adicionarObservacao"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Revisão e envio";
                    readonly mode: "confirm";
                    readonly organisms: readonly [{
                        readonly organismName: "Resumo e envio para cozinha";
                        readonly purpose: "Revisar o pedido e confirmar o envio para preparo.";
                        readonly userActions: readonly ["confirmarEEnviar", "voltarParaEditar"];
                        readonly requiredEntities: readonly ["Order", "OrderStatusHistory"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["orderRequiresItem", "orderStatusTransition"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listarPedidos";
                readonly purpose: "Listar pedidos do dia para consulta rápida no POS.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "dateFrom";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "dateTo";
                    readonly type: "date";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "createdAt";
                    readonly type: "date";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["orders", "order_status_history"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarPedidos"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "criarPedido";
                readonly purpose: "Criar um pedido com itens e enviar para a cozinha com status recebido.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "orderItems";
                    readonly type: "OrderItem[]";
                    readonly required: true;
                }, {
                    readonly name: "observacao";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "createdAt";
                    readonly type: "date";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["cardapioEntity"];
                readonly writesEntities: readonly ["Order", "OrderStatusHistory"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["orders", "order_status_history", "daily_sales_metrics", "top_selling_items_metrics"];
                readonly usecaseRefs: readonly ["criarPedido"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["orderRequiresItem"];
            }];
        };
    };
    export default posRapidoPagePlan;
}
declare module "_102043_/l2/cafeFlow/plugins/llmSalesAssistant.defs" {
    export const llmSalesAssistantPluginConnectionPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginConnection";
        readonly artifactId: "llmSalesAssistant";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 16;
            readonly planId: "plan-plugins";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "llmSalesAssistant";
                readonly provider: "Llm Sales Assistant";
                readonly priority: "soon";
                readonly reason: "Necessário para executar o assistente IA de vendas previsto para a fase soon.";
                readonly events: readonly [];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly ["Resumo diário de vendas", "Itens mais vendidos (últimos 7 dias)", "Dados de estoque e promoções ativas (se aplicável)"];
                readonly outputData: readonly ["Resumo de vendas", "Sugestões de promoção", "Insights de desempenho"];
                readonly webhooks: readonly [];
                readonly risks: readonly ["Dependência de decisão do cliente sobre uso de IA e proxy de LLM."];
                readonly questions: readonly ["Qual provedor/endpoint do proxy de LLM deve ser usado e quais limites de uso estão previstos?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102043_/l2/plugins/llmSalesAssistant/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102043_/l2/cafeFlow/plugins/llmSalesAssistant.defs.ts";
            };
        };
    };
    export default llmSalesAssistantPluginConnectionPlan;
}
declare module "_102043_/l2/cafeFlow/web/contracts/cardapioEstoque.defs" {
    export const definition: ({
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: string[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    } | {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: string[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    })[];
    export const pipeline: readonly [{
        readonly id: "cardapioEstoque__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102043_/l2/cafeFlow/web/contracts/cardapioEstoque.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/contracts/cardapioEstoque.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/contracts/dashboardGerente.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: any[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: any[];
    }[];
    export const pipeline: readonly [{
        readonly id: "dashboardGerente__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102043_/l2/cafeFlow/web/contracts/dashboardGerente.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/contracts/dashboardGerente.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/contracts/fechamentoTurno.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: string[];
        writesTables: string[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "fechamentoTurno__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102043_/l2/cafeFlow/web/contracts/fechamentoTurno.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/contracts/fechamentoTurno.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/contracts/painelCozinha.defs" {
    export const definition: {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: string[];
        writesTables: string[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    }[];
    export const pipeline: readonly [{
        readonly id: "painelCozinha__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102043_/l2/cafeFlow/web/contracts/painelCozinha.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/contracts/painelCozinha.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/contracts/posRapido.defs" {
    export const definition: ({
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: any[];
        readsTables: string[];
        writesTables: any[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: any[];
    } | {
        commandName: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
        }[];
        output: {
            name: string;
            type: string;
        }[];
        readsEntities: string[];
        writesEntities: string[];
        readsTables: any[];
        writesTables: string[];
        usecaseRefs: string[];
        layerContract: {
            controllerLayer: string;
            mustCallLayer: string;
            directTableAccessForbidden: boolean;
        };
        rulesApplied: string[];
    })[];
    export const pipeline: readonly [{
        readonly id: "posRapido__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102043_/l2/cafeFlow/web/contracts/posRapido.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/contracts/posRapido.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genContract.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/desktop/page11/cardapioEstoque.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: string[];
        };
        pluginRefs: any[];
        mdmRefs: string[];
        pageInputs: any[];
        navigationRefs: {
            direction: string;
            pageId: string;
            trigger: string;
        }[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "cardapioEstoque__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102043_/l2/cafeFlow/web/desktop/page11/cardapioEstoque.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/desktop/page11/cardapioEstoque.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l2/cafeFlow/web/shared/cardapioEstoque.ts", "_102043_/l2/cafeFlow/web/contracts/cardapioEstoque.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly tone: "Moderno e minimalista";
            readonly layout: "Interface rápida com foco em POS e painéis operacionais";
            readonly palette: readonly ["#C85A2A", "#F2C57C", "#F6F1EB", "#3B2F2F", "#2E7D32"];
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/shared/cardapioEstoque" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { BffClientOptions } from '_102029_/l2/bffClient';
    import type { CardapioEstoqueListarItensCardapioInput, CardapioEstoqueListarItensCardapioOutputItem, CardapioEstoqueListarCategoriasCardapioInput, CardapioEstoqueListarCategoriasCardapioOutputItem, CardapioEstoqueCriarOuAtualizarItemCardapioInput, CardapioEstoqueListarItensEstoqueInput, CardapioEstoqueListarItensEstoqueOutputItem, CardapioEstoqueCriarOuAtualizarItemEstoqueInput, CardapioEstoqueRegistrarMovimentacaoEstoqueInput, CardapioEstoqueListarMovimentacoesEstoqueInput, CardapioEstoqueListarMovimentacoesEstoqueOutputItem, CardapioEstoqueListarAlertasEstoqueBaixoInput, CardapioEstoqueListarAlertasEstoqueBaixoOutputItem } from "_102043_/l2/cafeFlow/web/contracts/cardapioEstoque";
    const message_en: {
        brand: string;
        pageTitle: string;
        loaded: string;
        couldNotLoad: string;
        loadingListarItensCardapio: string;
        loadingListarCategoriasCardapio: string;
        loadingListarItensEstoque: string;
        loadingListarMovimentacoesEstoque: string;
        loadingListarAlertasEstoqueBaixo: string;
        criarOuAtualizarItemCardapioLabel: string;
        criarOuAtualizarItemCardapioLoading: string;
        couldNotCriarOuAtualizarItemCardapio: string;
        criarOuAtualizarItemEstoqueLabel: string;
        criarOuAtualizarItemEstoqueLoading: string;
        couldNotCriarOuAtualizarItemEstoque: string;
        registrarMovimentacaoEstoqueLabel: string;
        registrarMovimentacaoEstoqueLoading: string;
        couldNotRegistrarMovimentacaoEstoque: string;
        navigateToDashboardGerente: string;
    };
    type MessageType = typeof message_en;
    export class CardapioEstoqueBase extends CollabLitElement {
        private readonly _stateKeys;
        itensCardapio: CardapioEstoqueListarItensCardapioOutputItem[];
        categoriasCardapio: CardapioEstoqueListarCategoriasCardapioOutputItem[];
        itensEstoque: CardapioEstoqueListarItensEstoqueOutputItem[];
        movimentacoesEstoque: CardapioEstoqueListarMovimentacoesEstoqueOutputItem[];
        alertasEstoqueBaixo: CardapioEstoqueListarAlertasEstoqueBaixoOutputItem[];
        criarOuAtualizarItemCardapioState: 'idle' | 'loading' | 'success' | 'error';
        criarOuAtualizarItemEstoqueState: 'idle' | 'loading' | 'success' | 'error';
        registrarMovimentacaoEstoqueState: 'idle' | 'loading' | 'success' | 'error';
        status: string;
        menuItemId: string | undefined;
        nome: string;
        preco: number;
        categoriaId: string;
        ativo: boolean;
        stockItemId: string | undefined;
        unidadeMedidaId: string;
        quantidadeMinima: number;
        movementType: string;
        quantity: number;
        reason: string | undefined;
        occurredAt: string;
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(params?: unknown, options?: BffClientOptions): Promise<void>;
        loadListarItensCardapio(params?: CardapioEstoqueListarItensCardapioInput, options?: BffClientOptions): Promise<void>;
        loadListarCategoriasCardapio(params?: CardapioEstoqueListarCategoriasCardapioInput, options?: BffClientOptions): Promise<void>;
        loadListarItensEstoque(params?: CardapioEstoqueListarItensEstoqueInput, options?: BffClientOptions): Promise<void>;
        loadListarMovimentacoesEstoque(params?: CardapioEstoqueListarMovimentacoesEstoqueInput, options?: BffClientOptions): Promise<void>;
        loadListarAlertasEstoqueBaixo(params?: CardapioEstoqueListarAlertasEstoqueBaixoInput, options?: BffClientOptions): Promise<void>;
        criarOuAtualizarItemCardapio(params: CardapioEstoqueCriarOuAtualizarItemCardapioInput, signal?: AbortSignal): Promise<void>;
        handleCriarOuAtualizarItemCardapioClick(): void;
        criarOuAtualizarItemEstoque(params: CardapioEstoqueCriarOuAtualizarItemEstoqueInput, signal?: AbortSignal): Promise<void>;
        handleCriarOuAtualizarItemEstoqueClick(): void;
        registrarMovimentacaoEstoque(params: CardapioEstoqueRegistrarMovimentacaoEstoqueInput, signal?: AbortSignal): Promise<void>;
        handleRegistrarMovimentacaoEstoqueClick(): void;
        handleNavigateToDashboardGerenteClick(params?: Record<string, unknown>): void;
    }
}
declare module "_102043_/l2/cafeFlow/web/desktop/page11/cardapioEstoque" {
    import { CardapioEstoqueBase } from "_102043_/l2/cafeFlow/web/shared/cardapioEstoque";
    export class CardapioEstoqueDesktopPage11CardapioEstoquePage extends CardapioEstoqueBase {
        render(): any;
    }
}
declare module "_102043_/l2/cafeFlow/web/desktop/page11/dashboardGerente.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: ({
            name: string;
            type: string;
            required: boolean;
            sources: string[];
            description: string;
            entityRef?: undefined;
            fieldRef?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            sources: string[];
            description: string;
            entityRef: string;
            fieldRef: string;
        })[];
        navigationRefs: {
            direction: string;
            pageId: string;
            trigger: string;
        }[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "dashboardGerente__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102043_/l2/cafeFlow/web/desktop/page11/dashboardGerente.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/desktop/page11/dashboardGerente.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l2/cafeFlow/web/shared/dashboardGerente.ts", "_102043_/l2/cafeFlow/web/contracts/dashboardGerente.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly tone: "Moderno e minimalista";
            readonly layout: "Interface rápida com foco em POS e painéis operacionais";
            readonly palette: readonly ["#C85A2A", "#F2C57C", "#F6F1EB", "#3B2F2F", "#2E7D32"];
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/shared/dashboardGerente" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { BffClientOptions } from '_102029_/l2/bffClient';
    import type { DashboardGerenteConsultarDashboardGerenteInput, DashboardGerenteConsultarDashboardGerenteOutput, DashboardGerenteListarAlertasEstoqueBaixoInput, DashboardGerenteListarAlertasEstoqueBaixoOutputItem } from "_102043_/l2/cafeFlow/web/contracts/dashboardGerente";
    const message_en: {
        brand: string;
        pageTitle: string;
        loaded: string;
        couldNotLoad: string;
        loadingConsultarDashboardGerente: string;
        loadingListarAlertasEstoqueBaixo: string;
    };
    type MessageType = typeof message_en;
    export class DashboardGerenteDashboardGerenteBase extends CollabLitElement {
        private readonly _stateKeys;
        totalRevenue: DashboardGerenteConsultarDashboardGerenteOutput['totalRevenue'] | undefined;
        orderCount: DashboardGerenteConsultarDashboardGerenteOutput['orderCount'] | undefined;
        averageTicket: DashboardGerenteConsultarDashboardGerenteOutput['averageTicket'] | undefined;
        itemsSold: DashboardGerenteConsultarDashboardGerenteOutput['itemsSold'] | undefined;
        serieVendasPorTurno: DashboardGerenteConsultarDashboardGerenteOutput['serieVendasPorTurno'] | undefined;
        rankingItensMaisVendidos: DashboardGerenteConsultarDashboardGerenteOutput['rankingItensMaisVendidos'] | undefined;
        alertasEstoqueBaixo: DashboardGerenteListarAlertasEstoqueBaixoOutputItem[];
        status: string;
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(params?: unknown, options?: BffClientOptions): Promise<void>;
        loadConsultarDashboardGerente(params?: DashboardGerenteConsultarDashboardGerenteInput, options?: BffClientOptions): Promise<void>;
        loadListarAlertasEstoqueBaixo(params?: DashboardGerenteListarAlertasEstoqueBaixoInput, options?: BffClientOptions): Promise<void>;
    }
}
declare module "_102043_/l2/cafeFlow/web/desktop/page11/dashboardGerente" {
    import { DashboardGerenteDashboardGerenteBase } from "_102043_/l2/cafeFlow/web/shared/dashboardGerente";
    export class DashboardGerenteDesktopPage11DashboardGerentePage extends DashboardGerenteDashboardGerenteBase {
        render(): any;
    }
}
declare module "_102043_/l2/cafeFlow/web/desktop/page11/fechamentoTurno.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: string[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: string[];
        pageInputs: any[];
        navigationRefs: {
            direction: string;
            pageId: string;
            trigger: string;
            description: string;
        }[];
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "fechamentoTurno__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102043_/l2/cafeFlow/web/desktop/page11/fechamentoTurno.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/desktop/page11/fechamentoTurno.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l2/cafeFlow/web/shared/fechamentoTurno.ts", "_102043_/l2/cafeFlow/web/contracts/fechamentoTurno.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly tone: "Moderno e minimalista";
            readonly layout: "Interface rápida com foco em POS e painéis operacionais";
            readonly palette: readonly ["#C85A2A", "#F2C57C", "#F6F1EB", "#3B2F2F", "#2E7D32"];
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/shared/fechamentoTurno" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { BffClientOptions } from '_102029_/l2/bffClient';
    import type { FechamentoTurnoListarTurnosInput, FechamentoTurnoListarTurnosOutputItem, FechamentoTurnoListarPedidosInput, FechamentoTurnoListarPedidosOutputItem, FechamentoTurnoFecharTurnoInput, FechamentoTurnoObterRelatorioTurnoInput, FechamentoTurnoObterRelatorioTurnoOutput } from "_102043_/l2/cafeFlow/web/contracts/fechamentoTurno";
    const message_en: {
        brand: string;
        pageTitle: string;
        loaded: string;
        couldNotLoad: string;
        loadingListarTurnos: string;
        loadingListarPedidos: string;
        loadingObterRelatorioTurno: string;
        fecharTurnoLabel: string;
        fecharTurnoLoading: string;
        couldNotFecharTurno: string;
        navigateToDashboardGerente: string;
    };
    type MessageType = typeof message_en;
    export class FechamentoTurnoFechamentoTurnoBase extends CollabLitElement {
        private readonly _stateKeys;
        turnos: FechamentoTurnoListarTurnosOutputItem[];
        pedidos: FechamentoTurnoListarPedidosOutputItem[];
        shiftReportId: FechamentoTurnoObterRelatorioTurnoOutput['shiftReportId'] | undefined;
        shiftId: FechamentoTurnoObterRelatorioTurnoOutput['shiftId'] | undefined;
        totalSalesAmount: FechamentoTurnoObterRelatorioTurnoOutput['totalSalesAmount'] | undefined;
        totalOrders: FechamentoTurnoObterRelatorioTurnoOutput['totalOrders'] | undefined;
        totalItems: FechamentoTurnoObterRelatorioTurnoOutput['totalItems'] | undefined;
        notes: FechamentoTurnoObterRelatorioTurnoOutput['notes'] | undefined;
        createdAt: FechamentoTurnoObterRelatorioTurnoOutput['createdAt'] | undefined;
        updatedAt: FechamentoTurnoObterRelatorioTurnoOutput['updatedAt'] | undefined;
        fecharTurnoState: 'idle' | 'loading' | 'success' | 'error';
        status: string;
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(params?: unknown, options?: BffClientOptions): Promise<void>;
        loadListarTurnos(params?: FechamentoTurnoListarTurnosInput, options?: BffClientOptions): Promise<void>;
        loadListarPedidos(params?: FechamentoTurnoListarPedidosInput, options?: BffClientOptions): Promise<void>;
        loadObterRelatorioTurno(params?: FechamentoTurnoObterRelatorioTurnoInput, options?: BffClientOptions): Promise<void>;
        fecharTurno(params: FechamentoTurnoFecharTurnoInput, signal?: AbortSignal): Promise<void>;
        handleFecharTurnoClick(): void;
        handleNavigateToDashboardGerenteClick(params?: Record<string, unknown>): void;
    }
}
declare module "_102043_/l2/cafeFlow/web/desktop/page11/fechamentoTurno" {
    import { FechamentoTurnoFechamentoTurnoBase } from "_102043_/l2/cafeFlow/web/shared/fechamentoTurno";
    export class FechamentoTurnoDesktopPage11FechamentoTurnoPage extends FechamentoTurnoFechamentoTurnoBase {
        render(): any;
    }
}
declare module "_102043_/l2/cafeFlow/web/desktop/page11/painelCozinha.defs" {
    export const definition: {
        sections: {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
            }[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "painelCozinha__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102043_/l2/cafeFlow/web/desktop/page11/painelCozinha.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/desktop/page11/painelCozinha.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l2/cafeFlow/web/shared/painelCozinha.ts", "_102043_/l2/cafeFlow/web/contracts/painelCozinha.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly tone: "Moderno e minimalista";
            readonly layout: "Interface rápida com foco em POS e painéis operacionais";
            readonly palette: readonly ["#C85A2A", "#F2C57C", "#F6F1EB", "#3B2F2F", "#2E7D32"];
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/shared/painelCozinha" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { BffClientOptions } from '_102029_/l2/bffClient';
    import type { PainelCozinhaListarPedidosCozinhaInput, PainelCozinhaListarPedidosCozinhaOutput, PainelCozinhaAtualizarStatusPedidoInput } from "_102043_/l2/cafeFlow/web/contracts/painelCozinha";
    const message_en: {
        brand: string;
        pageTitle: string;
        loaded: string;
        couldNotLoad: string;
        loadingListarPedidosCozinha: string;
        atualizarStatusPedidoLabel: string;
        atualizarStatusPedidoLoading: string;
        couldNotAtualizarStatusPedido: string;
    };
    type MessageType = typeof message_en;
    export class PainelCozinhaPainelCozinhaBase extends CollabLitElement {
        private readonly _stateKeys;
        pedidosCozinha: PainelCozinhaListarPedidosCozinhaOutput;
        atualizarStatusPedidoState: 'idle' | 'loading' | 'success' | 'error';
        status: string;
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(params?: unknown, options?: BffClientOptions): Promise<void>;
        loadListarPedidosCozinha(params?: PainelCozinhaListarPedidosCozinhaInput, options?: BffClientOptions): Promise<void>;
        atualizarStatusPedido(params: PainelCozinhaAtualizarStatusPedidoInput, signal?: AbortSignal): Promise<void>;
        handleAtualizarStatusPedidoClick(): void;
    }
}
declare module "_102043_/l2/cafeFlow/web/desktop/page11/painelCozinha" {
    import { PainelCozinhaPainelCozinhaBase } from "_102043_/l2/cafeFlow/web/shared/painelCozinha";
    export class PainelCozinhaDesktopPage11PainelCozinhaPage extends PainelCozinhaPainelCozinhaBase {
        render(): any;
    }
}
declare module "_102043_/l2/cafeFlow/web/desktop/page11/posRapido.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: string[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        pageInputs: any[];
        navigationRefs: {
            direction: string;
            pageId: string;
            trigger: string;
            description: string;
        }[];
        sections: ({
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
            }[];
        } | {
            sectionName: string;
            mode: string;
            organisms: {
                organismName: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
            }[];
        })[];
    };
    export const pipeline: readonly [{
        readonly id: "posRapido__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102043_/l2/cafeFlow/web/desktop/page11/posRapido.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/desktop/page11/posRapido.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l2/cafeFlow/web/shared/posRapido.ts", "_102043_/l2/cafeFlow/web/contracts/posRapido.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentMaterializeSolution/skills/genPageRender.ts", "_102020_/l2/agentMaterializeSolution/skills/genPageDS.ts"];
        readonly afterSaveFrontEnd: "_102020_/l2/agentMaterializeSolution/registerFrontEnd.ts?registerPage";
        readonly visualStyle: {
            readonly tone: "Moderno e minimalista";
            readonly layout: "Interface rápida com foco em POS e painéis operacionais";
            readonly palette: readonly ["#C85A2A", "#F2C57C", "#F6F1EB", "#3B2F2F", "#2E7D32"];
        };
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/shared/posRapido" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { BffClientOptions } from '_102029_/l2/bffClient';
    import type { PosRapidoListarPedidosInput, PosRapidoListarPedidosOutputItem, PosRapidoCriarPedidoInput } from "_102043_/l2/cafeFlow/web/contracts/posRapido";
    const message_en: {
        brand: string;
        pageTitle: string;
        loaded: string;
        couldNotLoad: string;
        loadingListarPedidos: string;
        criarPedidoLabel: string;
        criarPedidoLoading: string;
        couldNotCriarPedido: string;
        navigateToPainelCozinha: string;
    };
    type MessageType = typeof message_en;
    export class PosRapidoBase extends CollabLitElement {
        private readonly _stateKeys;
        status: string;
        pedidos: PosRapidoListarPedidosOutputItem[];
        criarPedidoState: 'idle' | 'loading' | 'success' | 'error';
        protected msg: MessageType;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        loadInitialData(params?: unknown, options?: BffClientOptions): Promise<void>;
        loadListarPedidos(params?: PosRapidoListarPedidosInput, options?: BffClientOptions): Promise<void>;
        criarPedido(params: PosRapidoCriarPedidoInput, signal?: AbortSignal): Promise<void>;
        handleCriarPedidoClick(): void;
        handleNavigateToPainelCozinhaClick(params?: Record<string, unknown>): void;
    }
}
declare module "_102043_/l2/cafeFlow/web/desktop/page11/posRapido" {
    import { PosRapidoBase } from "_102043_/l2/cafeFlow/web/shared/posRapido";
    export class PosRapidoDesktopPage11PosRapidoPage extends PosRapidoBase {
        render(): any;
    }
}
declare module "_102043_/l2/cafeFlow/web/shared/cardapioEstoque.defs" {
    export const definition: {
        bffCommands: ({
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: string[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        } | {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: any[];
            readsTables: string[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        })[];
        navigationRefs: {
            direction: string;
            pageId: string;
            trigger: string;
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "cardapioEstoque__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102043_/l2/cafeFlow/web/shared/cardapioEstoque.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/shared/cardapioEstoque.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l2/cafeFlow/web/contracts/cardapioEstoque.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["menuItemRequiresCategory", "lowStockThresholdRule"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/shared/dashboardGerente.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: any[];
            readsTables: any[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: any[];
        }[];
        navigationRefs: {
            direction: string;
            pageId: string;
            trigger: string;
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "dashboardGerente__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102043_/l2/cafeFlow/web/shared/dashboardGerente.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/shared/dashboardGerente.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l2/cafeFlow/web/contracts/dashboardGerente.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/shared/fechamentoTurno.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: string[];
            writesTables: string[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: {
            direction: string;
            pageId: string;
            trigger: string;
            description: string;
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "fechamentoTurno__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102043_/l2/cafeFlow/web/shared/fechamentoTurno.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/shared/fechamentoTurno.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l2/cafeFlow/web/contracts/fechamentoTurno.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["shiftClosureRequiresNoOpenOrders"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/shared/painelCozinha.defs" {
    export const definition: {
        bffCommands: {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: string[];
            writesTables: string[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        }[];
        navigationRefs: {
            direction: string;
            pageId: string;
            trigger: string;
            description: string;
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "painelCozinha__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102043_/l2/cafeFlow/web/shared/painelCozinha.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/shared/painelCozinha.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l2/cafeFlow/web/contracts/painelCozinha.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["orderStatusTransition"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/cafeFlow/web/shared/posRapido.defs" {
    export const definition: {
        bffCommands: ({
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: any[];
            readsTables: string[];
            writesTables: any[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: any[];
        } | {
            commandName: string;
            purpose: string;
            kind: string;
            input: {
                name: string;
                type: string;
                required: boolean;
            }[];
            output: {
                name: string;
                type: string;
            }[];
            readsEntities: string[];
            writesEntities: string[];
            readsTables: any[];
            writesTables: string[];
            usecaseRefs: string[];
            layerContract: {
                controllerLayer: string;
                mustCallLayer: string;
                directTableAccessForbidden: boolean;
            };
            rulesApplied: string[];
        })[];
        navigationRefs: {
            direction: string;
            pageId: string;
            trigger: string;
            description: string;
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "posRapido__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102043_/l2/cafeFlow/web/shared/posRapido.ts";
        readonly defPath: "_102043_/l2/cafeFlow/web/shared/posRapido.defs.ts";
        readonly dependsFiles: readonly ["_102043_/l2/cafeFlow/web/contracts/posRapido.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["/_102020_/l2/agentMaterializeSolution/skills/genPageShared.ts"];
        readonly rulesPath: "_102043_/l5/cafeFlow/rules.defs.ts";
        readonly rulesApplied: readonly ["orderRequiresItem"];
        readonly agent: "agentMaterializeGen";
    }];
}
declare module "_102043_/l2/plugins/llmSalesAssistant/plugin.defs" {
    export const llmSalesAssistantPluginPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginDraft";
        readonly artifactId: "llmSalesAssistant";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 16;
            readonly planId: "plan-plugins";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "llmSalesAssistant";
                readonly provider: "Llm Sales Assistant";
                readonly priority: "soon";
                readonly reason: "Necessário para executar o assistente IA de vendas previsto para a fase soon.";
                readonly events: readonly [];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly ["Resumo diário de vendas", "Itens mais vendidos (últimos 7 dias)", "Dados de estoque e promoções ativas (se aplicável)"];
                readonly outputData: readonly ["Resumo de vendas", "Sugestões de promoção", "Insights de desempenho"];
                readonly webhooks: readonly [];
                readonly risks: readonly ["Dependência de decisão do cliente sobre uso de IA e proxy de LLM."];
                readonly questions: readonly ["Qual provedor/endpoint do proxy de LLM deve ser usado e quais limites de uso estão previstos?"];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102043_/l2/plugins/llmSalesAssistant/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102043_/l2/cafeFlow/plugins/llmSalesAssistant.defs.ts";
            };
        };
    };
    export default llmSalesAssistantPluginPlan;
}
