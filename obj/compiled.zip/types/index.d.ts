declare module "_102043_/l1/cafeFlow/layer_1_external/dailySalesMetrics.defs" {
    export const dailySalesMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "dailySalesMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 54;
            readonly planId: "plan-metric-table-definition:dailySalesMetrics";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "dailySalesMetrics";
                readonly tableName: "daily_sales_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Métricas de Vendas Diárias";
                readonly purpose: "Agregação diária e por turno de pedidos, itens e receita para acompanhamento operacional e fechamento.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "bucket_time";
                readonly columns: readonly [{
                    readonly name: "bucket_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do bucket de agregação.";
                }, {
                    readonly name: "shift_id";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Identificador do turno diário.";
                }, {
                    readonly name: "order_type";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Tipo do pedido: mesa ou takeout.";
                }, {
                    readonly name: "total_orders";
                    readonly type: "int";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade total de pedidos no período.";
                }, {
                    readonly name: "total_items";
                    readonly type: "int";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade total de itens vendidos no período.";
                }, {
                    readonly name: "gross_amount";
                    readonly type: "numeric(12,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor bruto total no período.";
                }, {
                    readonly name: "net_amount";
                    readonly type: "numeric(12,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor líquido total no período.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "shiftId";
                    readonly column: "shift_id";
                    readonly type: "string";
                    readonly description: "Identificador do turno diário.";
                }, {
                    readonly dimensionId: "orderType";
                    readonly column: "order_type";
                    readonly type: "string";
                    readonly description: "Tipo do pedido: mesa ou takeout.";
                }];
                readonly measures: readonly [{
                    readonly measureId: "totalOrders";
                    readonly column: "total_orders";
                    readonly aggregation: "sum";
                    readonly unit: "orders";
                    readonly description: "Quantidade total de pedidos no período.";
                }, {
                    readonly measureId: "totalItems";
                    readonly column: "total_items";
                    readonly aggregation: "sum";
                    readonly unit: "items";
                    readonly description: "Quantidade total de itens vendidos no período.";
                }, {
                    readonly measureId: "grossAmount";
                    readonly column: "gross_amount";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Valor bruto total no período.";
                }, {
                    readonly measureId: "netAmount";
                    readonly column: "net_amount";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Valor líquido total no período.";
                }];
                readonly sourceWriteEvents: readonly ["orderCreated", "orderDelivered", "dailyShiftClosed"];
                readonly hypertable: {
                    readonly timeColumn: "bucket_time";
                    readonly chunkTimeInterval: "1 day";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_daily_sales_metrics_bucket_time";
                        readonly columns: readonly ["bucket_time"];
                        readonly purpose: "Ordenação e recortes por tempo.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_shift_time";
                        readonly columns: readonly ["shift_id", "bucket_time"];
                        readonly purpose: "Filtros por turno e período.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_order_type_time";
                        readonly columns: readonly ["order_type", "bucket_time"];
                        readonly purpose: "Filtros por tipo de pedido e período.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["usecaseCalcularMetricasDashboard", "usecaseFecharTurno"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly [];
            };
            readonly defsPlan: {
                readonly fileName: "tables/dailySalesMetrics.defs.ts";
                readonly exportName: "dailySalesMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default dailySalesMetricsMetricTableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/lowStockMetrics.defs" {
    export const lowStockMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "lowStockMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 58;
            readonly planId: "plan-metric-table-definition:lowStockMetrics";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "lowStockMetrics";
                readonly tableName: "low_stock_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Métricas de Estoque Baixo";
                readonly purpose: "Snapshot periódico de ingredientes com quantidade abaixo do nível mínimo para alertas operacionais.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "checked_at";
                readonly columns: readonly [{
                    readonly name: "checked_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora da verificação do estoque.";
                }, {
                    readonly name: "ingredient_id";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Identificador do ingrediente.";
                }, {
                    readonly name: "ingredient_name";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Nome do ingrediente.";
                }, {
                    readonly name: "current_quantity";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly description: "Quantidade disponível no momento da coleta.";
                }, {
                    readonly name: "min_level";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly description: "Nível mínimo configurado para o ingrediente.";
                }, {
                    readonly name: "shortage";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly description: "Diferença negativa entre quantidade atual e nível mínimo.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "ingredientId";
                    readonly column: "ingredient_id";
                    readonly type: "string";
                    readonly description: "Identificador do ingrediente.";
                }, {
                    readonly dimensionId: "ingredientName";
                    readonly column: "ingredient_name";
                    readonly type: "string";
                    readonly description: "Nome do ingrediente.";
                }];
                readonly measures: readonly [{
                    readonly measureId: "currentQuantity";
                    readonly column: "current_quantity";
                    readonly aggregation: "last";
                    readonly unit: "units";
                    readonly description: "Quantidade disponível no momento da coleta.";
                }, {
                    readonly measureId: "minLevel";
                    readonly column: "min_level";
                    readonly aggregation: "last";
                    readonly unit: "units";
                    readonly description: "Nível mínimo configurado para o ingrediente.";
                }, {
                    readonly measureId: "shortage";
                    readonly column: "shortage";
                    readonly aggregation: "last";
                    readonly unit: "units";
                    readonly description: "Diferença negativa entre quantidade atual e nível mínimo.";
                }];
                readonly sourceWriteEvents: readonly ["stockItemUpdated", "stockDeducted", "stockAdjusted"];
                readonly hypertable: {
                    readonly timeColumn: "checked_at";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "90 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_low_stock_metrics_checked_at";
                        readonly columns: readonly ["checked_at"];
                        readonly purpose: "Ordenação e consultas por tempo.";
                    }, {
                        readonly indexName: "idx_low_stock_metrics_ingredient_id_checked_at";
                        readonly columns: readonly ["ingredient_id", "checked_at"];
                        readonly purpose: "Filtro por ingrediente e janela temporal.";
                    }, {
                        readonly indexName: "idx_low_stock_metrics_ingredient_name_checked_at";
                        readonly columns: readonly ["ingredient_name", "checked_at"];
                        readonly purpose: "Filtro por nome do ingrediente e janela temporal.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["usecaseBaixarEstoqueIngredientes", "usecaseAjustarEstoque"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["rule-low-stock-alert"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/lowStockMetrics.defs.ts";
                readonly exportName: "lowStockMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default lowStockMetricsMetricTableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/orderAggregate.defs" {
    export const orderAggregateTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "orderAggregate";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 40;
            readonly planId: "plan-table-definition:orderAggregate";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "orderAggregate";
                readonly tableName: "order_aggregate";
                readonly moduleId: "cafeFlow";
                readonly title: "Pedidos com itens e ticket de cozinha";
                readonly purpose: "Persistir pedidos do POS com itens associados e estado operacional da cozinha em um agregado único para leitura rápida da fila e do POS.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "Order";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador do pedido.";
                }, {
                    readonly name: "order_number";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Número sequencial visível no POS e na cozinha.";
                }, {
                    readonly name: "order_type";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Tipo do pedido: mesa ou takeout.";
                }, {
                    readonly name: "table_number";
                    readonly type: "string";
                    readonly nullable: true;
                    readonly description: "Número da mesa quando aplicável.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Status do pedido (Novo, Em preparo, Pronto, Entregue).";
                }, {
                    readonly name: "kitchen_priority";
                    readonly type: "string";
                    readonly nullable: true;
                    readonly description: "Prioridade operacional do ticket de cozinha.";
                }, {
                    readonly name: "total_amount";
                    readonly type: "number";
                    readonly nullable: false;
                    readonly description: "Valor total do pedido.";
                }, {
                    readonly name: "item_count";
                    readonly type: "number";
                    readonly nullable: false;
                    readonly description: "Quantidade total de itens no pedido.";
                }, {
                    readonly name: "shift_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Identificador do turno diário associado.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamp";
                    readonly nullable: false;
                    readonly description: "Data/hora de criação do pedido.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamp";
                    readonly nullable: false;
                    readonly description: "Data/hora da última atualização.";
                }, {
                    readonly name: "closed_at";
                    readonly type: "timestamp";
                    readonly nullable: true;
                    readonly description: "Data/hora de fechamento/entrega do pedido.";
                }];
                readonly primaryKey: readonly ["order_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "shift_id";
                    readonly targetEntity: "DailyShift";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Vincular pedido ao turno diário para relatórios operacionais.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_order_aggregate_status_created_at";
                    readonly columns: readonly ["status", "created_at"];
                    readonly unique: false;
                    readonly reason: "Fila operacional e filtros por status e data no painel da cozinha.";
                }, {
                    readonly indexName: "idx_order_aggregate_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly unique: false;
                    readonly reason: "Consultas do POS e métricas por período.";
                }, {
                    readonly indexName: "idx_order_aggregate_order_number";
                    readonly columns: readonly ["order_number"];
                    readonly unique: true;
                    readonly reason: "Busca rápida por número do pedido no POS.";
                }, {
                    readonly indexName: "idx_order_aggregate_shift_id";
                    readonly columns: readonly ["shift_id"];
                    readonly unique: false;
                    readonly reason: "Agregações por turno diário para métricas.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "orderAggregateDetails";
                    readonly reason: "Armazenar itens do pedido e ticket de cozinha sem ciclo de vida independente.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["dashboardOperacionalDiario", "itensMaisVendidos"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["rule-order-status-transition", "rule-stock-deduct-by-ingredient"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/orderAggregate.defs.ts";
                readonly exportName: "orderAggregateTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default orderAggregateTableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/promotionSuggestion.defs" {
    export const promotionSuggestionTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "promotionSuggestion";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 44;
            readonly planId: "plan-table-definition:promotionSuggestion";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "promotionSuggestion";
                readonly tableName: "promotion_suggestion";
                readonly moduleId: "cafeFlow";
                readonly title: "Sugestões de promoção";
                readonly purpose: "Registrar sugestões geradas por IA para itens do cardápio com base no histórico de vendas.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "PromotionSuggestion";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "promotion_suggestion_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da sugestão de promoção.";
                }, {
                    readonly name: "menu_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Item do cardápio sugerido para promoção (MDM).";
                }, {
                    readonly name: "suggestion_status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly default: "new";
                    readonly description: "Status da sugestão (ex.: new, reviewed, approved, rejected, expired).";
                }, {
                    readonly name: "suggested_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora em que a sugestão foi gerada.";
                }, {
                    readonly name: "valid_until";
                    readonly type: "timestamptz";
                    readonly nullable: true;
                    readonly description: "Data e hora limite recomendada para a promoção.";
                }, {
                    readonly name: "score";
                    readonly type: "numeric";
                    readonly nullable: true;
                    readonly description: "Pontuação de relevância calculada pelo agente.";
                }, {
                    readonly name: "reason_summary";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Resumo do motivo da recomendação.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data da última atualização do registro.";
                }];
                readonly primaryKey: readonly ["promotion_suggestion_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "menu_item_id";
                    readonly targetEntity: "MenuItem";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Relacionar a sugestão ao item de cardápio mestre.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_promotion_suggestion_menu_item_id";
                    readonly columns: readonly ["menu_item_id"];
                    readonly unique: false;
                    readonly reason: "Busca por sugestões por item do cardápio.";
                }, {
                    readonly indexName: "idx_promotion_suggestion_status";
                    readonly columns: readonly ["suggestion_status"];
                    readonly unique: false;
                    readonly reason: "Filtrar sugestões por status no fluxo de revisão.";
                }, {
                    readonly indexName: "idx_promotion_suggestion_suggested_at";
                    readonly columns: readonly ["suggested_at"];
                    readonly unique: false;
                    readonly reason: "Ordenação e filtros por data de geração.";
                }, {
                    readonly indexName: "idx_promotion_suggestion_valid_until";
                    readonly columns: readonly ["valid_until"];
                    readonly unique: false;
                    readonly reason: "Filtro por validade da sugestão.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly [];
            };
            readonly defsPlan: {
                readonly fileName: "tables/promotionSuggestion.defs.ts";
                readonly exportName: "promotionSuggestionTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default promotionSuggestionTableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/salesSummary.defs" {
    export const salesSummaryTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "salesSummary";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 42;
            readonly planId: "plan-table-definition:salesSummary";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "salesSummary";
                readonly tableName: "sales_summary";
                readonly moduleId: "cafeFlow";
                readonly title: "Resumo de vendas do turno";
                readonly purpose: "Armazenar o resumo consolidado do turno para relatório de fechamento e geração de insights.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "SalesSummary";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "sales_summary_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do resumo de vendas.";
                }, {
                    readonly name: "shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador do turno diário relacionado.";
                }, {
                    readonly name: "status";
                    readonly type: "varchar(30)";
                    readonly nullable: false;
                    readonly description: "Status do resumo do turno (ex.: fechado, reaberto).";
                }, {
                    readonly name: "period_start_at";
                    readonly type: "timestamp";
                    readonly nullable: false;
                    readonly description: "Início do período do turno consolidado.";
                }, {
                    readonly name: "period_end_at";
                    readonly type: "timestamp";
                    readonly nullable: false;
                    readonly description: "Fim do período do turno consolidado.";
                }, {
                    readonly name: "total_orders";
                    readonly type: "int";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade total de pedidos no turno.";
                }, {
                    readonly name: "total_items";
                    readonly type: "int";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade total de itens vendidos no turno.";
                }, {
                    readonly name: "gross_amount";
                    readonly type: "numeric(12,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor bruto total do turno.";
                }, {
                    readonly name: "discount_amount";
                    readonly type: "numeric(12,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Total de descontos aplicados no turno.";
                }, {
                    readonly name: "net_amount";
                    readonly type: "numeric(12,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor líquido total do turno.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamp";
                    readonly nullable: false;
                    readonly description: "Data de criação do resumo.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamp";
                    readonly nullable: false;
                    readonly description: "Data da última atualização do resumo.";
                }];
                readonly primaryKey: readonly ["sales_summary_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "shift_id";
                    readonly targetEntity: "DailyShift";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Relacionar o resumo ao turno diário fechado.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_sales_summary_shift";
                    readonly columns: readonly ["shift_id"];
                    readonly unique: true;
                    readonly reason: "Busca rápida do resumo pelo turno e garantia de um resumo por turno.";
                }, {
                    readonly indexName: "idx_sales_summary_period";
                    readonly columns: readonly ["period_start_at", "period_end_at"];
                    readonly reason: "Filtragem por período para relatórios e dashboards.";
                }, {
                    readonly indexName: "idx_sales_summary_status";
                    readonly columns: readonly ["status"];
                    readonly reason: "Filtragem por status do fechamento.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["metricTableVendasDiarias"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["rule-shift-close-required"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/salesSummary.defs.ts";
                readonly exportName: "salesSummaryTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default salesSummaryTableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.defs" {
    export const topSellingItemsMetricsTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "topSellingItemsMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 56;
            readonly planId: "plan-metric-table-definition:topSellingItemsMetrics";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "topSellingItemsMetrics";
                readonly tableName: "top_selling_items_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Métricas de Itens Mais Vendidos";
                readonly purpose: "Ranking de vendas por item do cardápio para identificar destaques e apoiar sugestões de promoção.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "bucket_time";
                readonly columns: readonly [{
                    readonly name: "bucket_time";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Início do bucket temporal de agregação.";
                }, {
                    readonly name: "menu_item_id";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Identificador do item do cardápio.";
                }, {
                    readonly name: "menu_item_name";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Nome do item do cardápio.";
                }, {
                    readonly name: "category";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Categoria do item no cardápio.";
                }, {
                    readonly name: "quantity_sold";
                    readonly type: "bigint";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade vendida do item no período.";
                }, {
                    readonly name: "revenue";
                    readonly type: "numeric(12,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Receita gerada pelo item no período.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "menuItemId";
                    readonly column: "menu_item_id";
                    readonly type: "string";
                    readonly description: "Identificador do item do cardápio.";
                }, {
                    readonly dimensionId: "menuItemName";
                    readonly column: "menu_item_name";
                    readonly type: "string";
                    readonly description: "Nome do item do cardápio.";
                }, {
                    readonly dimensionId: "category";
                    readonly column: "category";
                    readonly type: "string";
                    readonly description: "Categoria do item no cardápio.";
                }];
                readonly measures: readonly [{
                    readonly measureId: "quantitySold";
                    readonly column: "quantity_sold";
                    readonly aggregation: "sum";
                    readonly unit: "units";
                    readonly description: "Quantidade vendida do item no período.";
                }, {
                    readonly measureId: "revenue";
                    readonly column: "revenue";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Receita gerada pelo item no período.";
                }];
                readonly sourceWriteEvents: readonly ["orderCreated", "orderDelivered", "orderItemAdded"];
                readonly hypertable: {
                    readonly timeColumn: "bucket_time";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_top_selling_items_metrics_bucket_time";
                        readonly columns: readonly ["bucket_time"];
                        readonly purpose: "Acelerar consultas por período no TimescaleDB.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_menu_item_time";
                        readonly columns: readonly ["menu_item_id", "bucket_time"];
                        readonly purpose: "Ranking e séries temporais por item do cardápio.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_category_time";
                        readonly columns: readonly ["category", "bucket_time"];
                        readonly purpose: "Filtros por categoria e período.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["usecaseCalcularMetricasDashboard"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly [];
            };
            readonly defsPlan: {
                readonly fileName: "tables/topSellingItemsMetrics.defs.ts";
                readonly exportName: "topSellingItemsMetricsTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default topSellingItemsMetricsTableDefinition;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/usecaseAjustarEstoque.defs" {
    export const usecaseAjustarEstoqueUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseAjustarEstoque";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 60;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layeredUsecaseDriven";
                readonly layer1Responsibility: "Definições de tabelas transacionais e de métricas (layer_1_external). Acesso direto apenas por layer_3_usecases.";
                readonly layer2Responsibility: "Controllers BFF que recebem comandos de páginas, workflows e agentes. Devem sempre delegar para usecases de layer_3.";
                readonly layer3Responsibility: "Usecases que encapsulam regras de negócio, leitura e escrita em tabelas de layer_1, e atualização de métricas.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseAjustarEstoque";
                readonly title: "Ajustar Estoque Manual";
                readonly purpose: "Registrar ajustes manuais de estoque e nível mínimo para ingredientes, gerando alertas quando necessário.";
                readonly actor: "gerente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["stockItemEntity", "ingredientEntity"];
                readonly outputEntities: readonly ["stockItemEntity"];
                readonly readsTables: readonly [{
                    readonly tableName: "StockItem";
                    readonly ownership: "mdmOwned";
                }, {
                    readonly tableName: "Ingredient";
                    readonly ownership: "mdmOwned";
                }];
                readonly writesTables: readonly [{
                    readonly tableName: "StockItem";
                    readonly ownership: "mdmOwned";
                }, {
                    readonly tableName: "low_stock_metrics";
                    readonly ownership: "moduleOwned";
                }];
                readonly commands: readonly ["adjustStockQuantity", "setMinStockLevel"];
                readonly rulesApplied: readonly ["rule-low-stock-alert"];
            };
        };
        readonly implementation: {
            readonly functionName: "adjustStockQuantity";
            readonly inputTypeName: "AdjustStockQuantityInput";
            readonly outputTypeName: "StockItemOutput";
            readonly inputTypeDefinition: "export interface AdjustStockQuantityInput {\n  stockItemId: string;\n  newQuantity: number;\n}";
            readonly outputTypeDefinition: "export type StockItemOutput = StockItemRecord;";
        };
    };
    export default usecaseAjustarEstoqueUsecasePlan;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/usecaseAtualizarStatusPedido.defs" {
    export const usecaseAtualizarStatusPedidoUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseAtualizarStatusPedido";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 60;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layeredUsecaseDriven";
                readonly layer1Responsibility: "Definições de tabelas transacionais e de métricas (layer_1_external). Acesso direto apenas por layer_3_usecases.";
                readonly layer2Responsibility: "Controllers BFF que recebem comandos de páginas, workflows e agentes. Devem sempre delegar para usecases de layer_3.";
                readonly layer3Responsibility: "Usecases que encapsulam regras de negócio, leitura e escrita em tabelas de layer_1, e atualização de métricas.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseAtualizarStatusPedido";
                readonly title: "Atualizar Status do Pedido";
                readonly purpose: "Transicionar status do pedido (Novo → Em preparo → Pronto → Entregue) e atualizar ticket de cozinha.";
                readonly actor: "cozinha";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregateEntity"];
                readonly outputEntities: readonly ["orderAggregateEntity"];
                readonly readsTables: readonly [{
                    readonly tableName: "order_aggregate";
                    readonly ownership: "moduleOwned";
                }];
                readonly writesTables: readonly [{
                    readonly tableName: "order_aggregate";
                    readonly ownership: "moduleOwned";
                }];
                readonly commands: readonly ["updateOrderStatusPreparing", "updateOrderStatusReady", "updateOrderStatusDelivered"];
                readonly rulesApplied: readonly ["rule-order-status-transition"];
            };
        };
        readonly implementation: {
            readonly functionName: "updateOrderStatusPreparing";
            readonly inputTypeName: "UpdateOrderStatusPreparingInput";
            readonly outputTypeName: "OrderAggregate";
            readonly inputTypeDefinition: "export interface UpdateOrderStatusPreparingInput {\n  orderId: string;\n}";
            readonly outputTypeDefinition: "export interface OrderAggregate {\n  orderId: string;\n  status: OrderStatus;\n  kitchenTicketStatus?: KitchenTicketStatus;\n  updatedAt?: string;\n}";
        };
    };
    export default usecaseAtualizarStatusPedidoUsecasePlan;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/usecaseBaixarEstoqueIngredientes.defs" {
    export const usecaseBaixarEstoqueIngredientesUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseBaixarEstoqueIngredientes";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 60;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layeredUsecaseDriven";
                readonly layer1Responsibility: "Definições de tabelas transacionais e de métricas (layer_1_external). Acesso direto apenas por layer_3_usecases.";
                readonly layer2Responsibility: "Controllers BFF que recebem comandos de páginas, workflows e agentes. Devem sempre delegar para usecases de layer_3.";
                readonly layer3Responsibility: "Usecases que encapsulam regras de negócio, leitura e escrita em tabelas de layer_1, e atualização de métricas.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseBaixarEstoqueIngredientes";
                readonly title: "Baixa de Estoque por Ingrediente";
                readonly purpose: "Deduzir estoque de ingredientes com base nos itens do pedido entregue, usando receitas do cardápio.";
                readonly actor: "cozinha";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregateEntity", "recipeLineEntity", "stockItemEntity"];
                readonly outputEntities: readonly ["stockItemEntity"];
                readonly readsTables: readonly [{
                    readonly tableName: "order_aggregate";
                    readonly ownership: "moduleOwned";
                }, {
                    readonly tableName: "RecipeLine";
                    readonly ownership: "mdmOwned";
                }, {
                    readonly tableName: "Ingredient";
                    readonly ownership: "mdmOwned";
                }, {
                    readonly tableName: "StockItem";
                    readonly ownership: "mdmOwned";
                }];
                readonly writesTables: readonly [{
                    readonly tableName: "StockItem";
                    readonly ownership: "mdmOwned";
                }, {
                    readonly tableName: "low_stock_metrics";
                    readonly ownership: "moduleOwned";
                }];
                readonly commands: readonly ["deductStockByRecipe"];
                readonly rulesApplied: readonly ["rule-stock-deduct-by-ingredient", "rule-low-stock-alert"];
            };
        };
        readonly implementation: {
            readonly functionName: "deductStockByRecipe";
            readonly inputTypeName: "DeductStockByRecipeInput";
            readonly outputTypeName: "DeductStockByRecipeOutput";
            readonly inputTypeDefinition: "export interface DeductStockByRecipeInput {\n  orderId: string;\n}";
            readonly outputTypeDefinition: "export interface DeductStockByRecipeOutput {\n  stockItems: StockItemRecord[];\n}";
        };
    };
    export default usecaseBaixarEstoqueIngredientesUsecasePlan;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/usecaseCalcularMetricasDashboard.defs" {
    export const usecaseCalcularMetricasDashboardUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseCalcularMetricasDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 60;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layeredUsecaseDriven";
                readonly layer1Responsibility: "Definições de tabelas transacionais e de métricas (layer_1_external). Acesso direto apenas por layer_3_usecases.";
                readonly layer2Responsibility: "Controllers BFF que recebem comandos de páginas, workflows e agentes. Devem sempre delegar para usecases de layer_3.";
                readonly layer3Responsibility: "Usecases que encapsulam regras de negócio, leitura e escrita em tabelas de layer_1, e atualização de métricas.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseCalcularMetricasDashboard";
                readonly title: "Calcular Métricas do Dashboard";
                readonly purpose: "Atualizar métricas de vendas diárias e itens mais vendidos para o dashboard do gerente.";
                readonly actor: "gerente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregateEntity", "menuItemEntity"];
                readonly outputEntities: readonly [];
                readonly readsTables: readonly [{
                    readonly tableName: "order_aggregate";
                    readonly ownership: "moduleOwned";
                }, {
                    readonly tableName: "MenuItem";
                    readonly ownership: "mdmOwned";
                }];
                readonly writesTables: readonly [{
                    readonly tableName: "daily_sales_metrics";
                    readonly ownership: "moduleOwned";
                }, {
                    readonly tableName: "top_selling_items_metrics";
                    readonly ownership: "moduleOwned";
                }];
                readonly commands: readonly ["refreshDailySalesMetrics", "refreshTopSellingItemsMetrics"];
                readonly rulesApplied: readonly [];
            };
        };
        readonly implementation: {
            readonly functionName: "refreshDailySalesMetrics";
            readonly inputTypeName: "RefreshDailySalesMetricsInput";
            readonly outputTypeName: "RefreshDailySalesMetricsOutput";
            readonly inputTypeDefinition: "export interface RefreshDailySalesMetricsInput {\n  metricDate: string; // YYYY-MM-DD\n}";
            readonly outputTypeDefinition: "export interface RefreshDailySalesMetricsOutput {\n  metricDate: string;\n  totalSales: number;\n  totalOrders: number;\n  updatedAt: string;\n}";
        };
    };
    export default usecaseCalcularMetricasDashboardUsecasePlan;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/usecaseCriarPedido.defs" {
    export const usecaseCriarPedidoUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseCriarPedido";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 60;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layeredUsecaseDriven";
                readonly layer1Responsibility: "Definições de tabelas transacionais e de métricas (layer_1_external). Acesso direto apenas por layer_3_usecases.";
                readonly layer2Responsibility: "Controllers BFF que recebem comandos de páginas, workflows e agentes. Devem sempre delegar para usecases de layer_3.";
                readonly layer3Responsibility: "Usecases que encapsulam regras de negócio, leitura e escrita em tabelas de layer_1, e atualização de métricas.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseCriarPedido";
                readonly title: "Criar Pedido";
                readonly purpose: "Registrar novo pedido com itens e criar ticket de cozinha para fila operacional.";
                readonly actor: "caixa";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["orderAggregateEntity", "menuItemEntity"];
                readonly outputEntities: readonly ["orderAggregateEntity"];
                readonly readsTables: readonly [{
                    readonly tableName: "MenuItem";
                    readonly ownership: "mdmOwned";
                }, {
                    readonly tableName: "DailyShift";
                    readonly ownership: "mdmOwned";
                }];
                readonly writesTables: readonly [{
                    readonly tableName: "order_aggregate";
                    readonly ownership: "moduleOwned";
                }];
                readonly commands: readonly ["createOrder", "addOrderItem", "sendToKitchen"];
                readonly rulesApplied: readonly ["rule-order-status-transition"];
            };
        };
        readonly implementation: {
            readonly functionName: "createOrder";
            readonly inputTypeName: "CreateOrderInput";
            readonly outputTypeName: "OrderAggregate";
            readonly inputTypeDefinition: "export interface CreateOrderInput {\n  shiftId: string;\n  items: CreateOrderItemInput[];\n}";
            readonly outputTypeDefinition: "export interface OrderAggregate {\n  orderId: string;\n  shiftId: string;\n  status: OrderStatus;\n  items: OrderItem[];\n  totalAmount: number;\n  createdAt: string;\n  updatedAt: string;\n  kitchenTicketId?: string | null;\n  kitchenSentAt?: string | null;\n}";
        };
    };
    export default usecaseCriarPedidoUsecasePlan;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/usecaseFecharTurno.defs" {
    export const usecaseFecharTurnoUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseFecharTurno";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 60;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layeredUsecaseDriven";
                readonly layer1Responsibility: "Definições de tabelas transacionais e de métricas (layer_1_external). Acesso direto apenas por layer_3_usecases.";
                readonly layer2Responsibility: "Controllers BFF que recebem comandos de páginas, workflows e agentes. Devem sempre delegar para usecases de layer_3.";
                readonly layer3Responsibility: "Usecases que encapsulam regras de negócio, leitura e escrita em tabelas de layer_1, e atualização de métricas.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseFecharTurno";
                readonly title: "Fechar Turno";
                readonly purpose: "Consolidar vendas do turno diário e gerar resumo para relatório de fechamento.";
                readonly actor: "gerente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["dailyShiftEntity", "orderAggregateEntity"];
                readonly outputEntities: readonly ["salesSummaryEntity"];
                readonly readsTables: readonly [{
                    readonly tableName: "DailyShift";
                    readonly ownership: "mdmOwned";
                }, {
                    readonly tableName: "order_aggregate";
                    readonly ownership: "moduleOwned";
                }];
                readonly writesTables: readonly [{
                    readonly tableName: "sales_summary";
                    readonly ownership: "moduleOwned";
                }, {
                    readonly tableName: "DailyShift";
                    readonly ownership: "mdmOwned";
                }, {
                    readonly tableName: "daily_sales_metrics";
                    readonly ownership: "moduleOwned";
                }];
                readonly commands: readonly ["closeDailyShift", "generateSalesSummary"];
                readonly rulesApplied: readonly ["rule-shift-close-required"];
            };
        };
        readonly implementation: {
            readonly functionName: "closeDailyShift";
            readonly inputTypeName: "CloseDailyShiftInput";
            readonly outputTypeName: "CloseDailyShiftOutput";
            readonly inputTypeDefinition: "export interface CloseDailyShiftInput {\n  dailyShiftId: string;\n  closedByUserId: string;\n}";
            readonly outputTypeDefinition: "export interface CloseDailyShiftOutput {\n  dailyShiftId: string;\n  status: DailyShiftStatus;\n  closedAt: string;\n}";
        };
    };
    export default usecaseFecharTurnoUsecasePlan;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/usecaseGerarResumoVendasIA.defs" {
    export const usecaseGerarResumoVendasIAUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGerarResumoVendasIA";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 60;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layeredUsecaseDriven";
                readonly layer1Responsibility: "Definições de tabelas transacionais e de métricas (layer_1_external). Acesso direto apenas por layer_3_usecases.";
                readonly layer2Responsibility: "Controllers BFF que recebem comandos de páginas, workflows e agentes. Devem sempre delegar para usecases de layer_3.";
                readonly layer3Responsibility: "Usecases que encapsulam regras de negócio, leitura e escrita em tabelas de layer_1, e atualização de métricas.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGerarResumoVendasIA";
                readonly title: "Gerar Resumo de Vendas (IA)";
                readonly purpose: "Produzir resumo narrativo das vendas do dia para o agente de IA.";
                readonly actor: "assistenteIA";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["salesSummaryEntity", "dailyShiftEntity"];
                readonly outputEntities: readonly [];
                readonly readsTables: readonly [{
                    readonly tableName: "sales_summary";
                    readonly ownership: "moduleOwned";
                }, {
                    readonly tableName: "DailyShift";
                    readonly ownership: "mdmOwned";
                }, {
                    readonly tableName: "daily_sales_metrics";
                    readonly ownership: "moduleOwned";
                }];
                readonly writesTables: readonly [];
                readonly commands: readonly ["generateSalesNarrative"];
                readonly rulesApplied: readonly [];
            };
        };
        readonly implementation: {
            readonly functionName: "generateSalesNarrative";
            readonly inputTypeName: "GenerateSalesNarrativeInput";
            readonly outputTypeName: "GenerateSalesNarrativeOutput";
            readonly inputTypeDefinition: "export interface GenerateSalesNarrativeInput {\n  businessDate?: string;\n  shiftId?: string;\n}";
            readonly outputTypeDefinition: "export interface GenerateSalesNarrativeOutput {\n  narrative: string;\n  dataPoints: {\n    totalGrossSales: number;\n    totalNetSales: number;\n    totalOrders: number;\n    avgTicket: number;\n    summariesFound: number;\n    metricsFound: number;\n    shiftsFound: number;\n  };\n}";
        };
    };
    export default usecaseGerarResumoVendasIAUsecasePlan;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/usecaseGerarSugestoesPromocaoIA.defs" {
    export const usecaseGerarSugestoesPromocaoIAUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGerarSugestoesPromocaoIA";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 60;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layeredUsecaseDriven";
                readonly layer1Responsibility: "Definições de tabelas transacionais e de métricas (layer_1_external). Acesso direto apenas por layer_3_usecases.";
                readonly layer2Responsibility: "Controllers BFF que recebem comandos de páginas, workflows e agentes. Devem sempre delegar para usecases de layer_3.";
                readonly layer3Responsibility: "Usecases que encapsulam regras de negócio, leitura e escrita em tabelas de layer_1, e atualização de métricas.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGerarSugestoesPromocaoIA";
                readonly title: "Gerar Sugestões de Promoção (IA)";
                readonly purpose: "Sugerir itens do cardápio para promover com base no histórico de vendas dos últimos 7 dias.";
                readonly actor: "assistenteIA";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["menuItemEntity", "salesSummaryEntity"];
                readonly outputEntities: readonly ["promotionSuggestionEntity"];
                readonly readsTables: readonly [{
                    readonly tableName: "MenuItem";
                    readonly ownership: "mdmOwned";
                }, {
                    readonly tableName: "top_selling_items_metrics";
                    readonly ownership: "moduleOwned";
                }, {
                    readonly tableName: "sales_summary";
                    readonly ownership: "moduleOwned";
                }];
                readonly writesTables: readonly [{
                    readonly tableName: "promotion_suggestion";
                    readonly ownership: "moduleOwned";
                }];
                readonly commands: readonly ["analyzeSellingTrends", "createPromotionSuggestion"];
                readonly rulesApplied: readonly [];
            };
        };
        readonly implementation: {
            readonly functionName: "analyzeSellingTrends";
            readonly inputTypeName: "AnalyzeSellingTrendsInput";
            readonly outputTypeName: "AnalyzeSellingTrendsOutput";
            readonly inputTypeDefinition: "export interface AnalyzeSellingTrendsInput {\n  limit?: number;\n}";
            readonly outputTypeDefinition: "export interface AnalyzeSellingTrendsOutput {\n  trends: SellingTrend[];\n}";
        };
    };
    export default usecaseGerarSugestoesPromocaoIAUsecasePlan;
}
declare module "_102043_/l1/cafeFlow/layer_3_usecases/usecaseGerenciarCardapio.defs" {
    export const usecaseGerenciarCardapioUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "usecaseGerenciarCardapio";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 60;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layeredUsecaseDriven";
                readonly layer1Responsibility: "Definições de tabelas transacionais e de métricas (layer_1_external). Acesso direto apenas por layer_3_usecases.";
                readonly layer2Responsibility: "Controllers BFF que recebem comandos de páginas, workflows e agentes. Devem sempre delegar para usecases de layer_3.";
                readonly layer3Responsibility: "Usecases que encapsulam regras de negócio, leitura e escrita em tabelas de layer_1, e atualização de métricas.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "usecaseGerenciarCardapio";
                readonly title: "Gerenciar Cardápio e Receitas";
                readonly purpose: "Criar e editar itens do cardápio com linhas de receita vinculadas para baixa automática de estoque.";
                readonly actor: "gerente";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["menuItemEntity", "recipeLineEntity", "ingredientEntity"];
                readonly outputEntities: readonly ["menuItemEntity", "recipeLineEntity"];
                readonly readsTables: readonly [{
                    readonly tableName: "MenuItem";
                    readonly ownership: "mdmOwned";
                }, {
                    readonly tableName: "RecipeLine";
                    readonly ownership: "mdmOwned";
                }, {
                    readonly tableName: "Ingredient";
                    readonly ownership: "mdmOwned";
                }];
                readonly writesTables: readonly [{
                    readonly tableName: "MenuItem";
                    readonly ownership: "mdmOwned";
                }, {
                    readonly tableName: "RecipeLine";
                    readonly ownership: "mdmOwned";
                }];
                readonly commands: readonly ["createMenuItem", "updateMenuItem", "addRecipeLine", "removeRecipeLine"];
                readonly rulesApplied: readonly ["rule-menuitem-recipe-required"];
            };
        };
        readonly implementation: {
            readonly functionName: "createMenuItem";
            readonly inputTypeName: "CreateMenuItemInput";
            readonly outputTypeName: "CreateMenuItemOutput";
            readonly inputTypeDefinition: "export interface CreateMenuItemInput {\n  name: string;\n  description?: string | null;\n  price: number;\n  isActive?: boolean;\n  recipeLines: RecipeLineInput[];\n}";
            readonly outputTypeDefinition: "export interface CreateMenuItemOutput {\n  menuItem: MenuItemRecord;\n  recipeLines: RecipeLineRecord[];\n}";
        };
    };
    export default usecaseGerenciarCardapioUsecasePlan;
}
declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102043_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102043_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102043_/l2/cafeFlow/inventoryManagement.defs" {
    export const inventoryManagementPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "inventoryManagement";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 83;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "inventoryManagement";
                readonly pageName: "Gerenciar Estoque de Ingredientes";
                readonly actor: "gerente";
                readonly purpose: "Ajustar quantidades e níveis mínimos de estoque por ingrediente.";
                readonly capabilities: readonly ["gerenciarEstoqueIngredientes"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["lowStockAlert"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["ingredient"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "menuManagement";
                    readonly trigger: "ajuste de ingredientes requerido";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "dashboardMetricasGerente";
                    readonly trigger: "ver alertas e métricas";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Lista de ingredientes em estoque";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "tabelaEstoqueIngredientes";
                        readonly purpose: "Exibir ingredientes com quantidade atual e nível mínimo para ajuste.";
                        readonly userActions: readonly ["selecionarIngrediente", "editarQuantidade", "editarNivelMinimo"];
                        readonly requiredEntities: readonly ["ingredientEntity", "stockItemEntity"];
                        readonly readsFields: readonly ["ingredientEntity.ingredientId", "ingredientEntity.name", "stockItemEntity.currentQuantity", "stockItemEntity.minLevel"];
                        readonly writesFields: readonly ["stockItemEntity.currentQuantity", "stockItemEntity.minLevel"];
                        readonly rulesApplied: readonly ["rule-low-stock-alert"];
                    }];
                }, {
                    readonly sectionName: "Ajuste de estoque";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "formAjusteEstoque";
                        readonly purpose: "Registrar ajuste manual de quantidade e nível mínimo do ingrediente selecionado.";
                        readonly userActions: readonly ["confirmarAjuste", "cancelarAjuste"];
                        readonly requiredEntities: readonly ["stockItemEntity", "ingredientEntity"];
                        readonly readsFields: readonly ["ingredientEntity.ingredientId", "ingredientEntity.name", "stockItemEntity.currentQuantity", "stockItemEntity.minLevel"];
                        readonly writesFields: readonly ["stockItemEntity.currentQuantity", "stockItemEntity.minLevel"];
                        readonly rulesApplied: readonly ["rule-low-stock-alert"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listIngredients";
                readonly purpose: "Listar ingredientes com estoque atual.";
                readonly kind: "query";
                readonly input: {
                    readonly filters: {
                        readonly searchText: "string?";
                        readonly onlyLowStock: "boolean?";
                        readonly limit: "number?";
                        readonly offset: "number?";
                    };
                };
                readonly output: {
                    readonly items: readonly [{
                        readonly ingredientId: "string";
                        readonly ingredientName: "string";
                        readonly currentQuantity: "number";
                        readonly minLevel: "number";
                        readonly isLowStock: "boolean";
                    }];
                    readonly total: "number";
                };
                readonly readsEntities: readonly ["ingredientEntity", "stockItemEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseAjustarEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-low-stock-alert"];
            }, {
                readonly commandName: "updateIngredientStock";
                readonly purpose: "Atualizar estoque manualmente.";
                readonly kind: "command";
                readonly input: {
                    readonly ingredientId: "string";
                    readonly currentQuantity: "number?";
                    readonly minLevel: "number?";
                };
                readonly output: {
                    readonly stockItem: {
                        readonly ingredientId: "string";
                        readonly currentQuantity: "number";
                        readonly minLevel: "number";
                        readonly isLowStock: "boolean";
                        readonly updatedAt: "string";
                    };
                };
                readonly readsEntities: readonly ["ingredientEntity", "stockItemEntity"];
                readonly writesEntities: readonly ["stockItemEntity"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseAjustarEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-low-stock-alert"];
            }];
        };
    };
    export default inventoryManagementPagePlan;
}
declare module "_102043_/l2/cafeFlow/kitchenQueue.defs" {
    export const kitchenQueuePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "kitchenQueue";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 81;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "kitchenQueue";
                readonly pageName: "Fila da Cozinha";
                readonly actor: "cozinha";
                readonly purpose: "Acompanhar pedidos pendentes e atualizar status de preparo, pronto e entregue.";
                readonly capabilities: readonly ["acompanharFilaCozinha", "atualizarStatusPedido"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["ingredient"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "posOrderConfirm";
                    readonly trigger: "novo pedido confirmado";
                    readonly description: "Pedido confirmado no POS entra na fila da cozinha.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Fila de pedidos";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "KitchenQueueList";
                        readonly purpose: "Listar pedidos em aberto com status e prioridade para acompanhamento rápido da cozinha.";
                        readonly userActions: readonly ["selecionarPedido", "filtrarPorStatus", "ordenarPorTempo"];
                        readonly requiredEntities: readonly ["orderAggregateEntity"];
                        readonly readsFields: readonly ["Order.orderNumber", "Order.orderType", "Order.tableNumber", "Order.status", "Order.kitchenPriority", "Order.itemCount", "Order.createdAt", "Order.updatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-order-status-transition"];
                    }];
                }, {
                    readonly sectionName: "Detalhes e atualização de status";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "OrderDetailsPanel";
                        readonly purpose: "Exibir detalhes do pedido selecionado com itens e horários relevantes.";
                        readonly userActions: readonly ["visualizarDetalhesPedido"];
                        readonly requiredEntities: readonly ["orderAggregateEntity"];
                        readonly readsFields: readonly ["Order.orderNumber", "Order.orderType", "Order.tableNumber", "Order.status", "Order.itemCount", "Order.totalAmount", "Order.createdAt", "Order.updatedAt", "Order.closedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-order-status-transition"];
                    }, {
                        readonly organismName: "OrderStatusActions";
                        readonly purpose: "Permitir transicionar o status do pedido conforme o fluxo da cozinha.";
                        readonly userActions: readonly ["updateOrderStatusPreparing", "updateOrderStatusReady", "updateOrderStatusDelivered"];
                        readonly requiredEntities: readonly ["orderAggregateEntity"];
                        readonly readsFields: readonly ["Order.status"];
                        readonly writesFields: readonly ["Order.status", "Order.updatedAt", "Order.closedAt"];
                        readonly rulesApplied: readonly ["rule-order-status-transition", "rule-stock-deduct-by-ingredient"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getKitchenQueue";
                readonly purpose: "Listar pedidos aguardando preparo ou finalização para exibição na fila da cozinha.";
                readonly kind: "query";
                readonly input: {
                    readonly statusFilter: readonly ["Novo", "Em preparo", "Pronto"];
                    readonly createdAfter: "timestamp?";
                    readonly limit: "number?";
                    readonly offset: "number?";
                };
                readonly output: {
                    readonly orders: readonly [{
                        readonly orderId: "uuid";
                        readonly orderNumber: "string";
                        readonly orderType: "string";
                        readonly tableNumber: "string?";
                        readonly status: "string";
                        readonly kitchenPriority: "string?";
                        readonly itemCount: "number";
                        readonly totalAmount: "number";
                        readonly createdAt: "timestamp";
                        readonly updatedAt: "timestamp";
                    }];
                };
                readonly readsEntities: readonly ["orderAggregateEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order_aggregate"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseAtualizarStatusPedido"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-order-status-transition"];
            }, {
                readonly commandName: "updateOrderStatus";
                readonly purpose: "Atualizar status do pedido pela cozinha conforme a sequência permitida.";
                readonly kind: "command";
                readonly input: {
                    readonly orderId: "uuid";
                    readonly newStatus: "string";
                    readonly action: "updateOrderStatusPreparing|updateOrderStatusReady|updateOrderStatusDelivered";
                };
                readonly output: {
                    readonly order: {
                        readonly orderId: "uuid";
                        readonly status: "string";
                        readonly updatedAt: "timestamp";
                        readonly closedAt: "timestamp?";
                    };
                };
                readonly readsEntities: readonly ["orderAggregateEntity"];
                readonly writesEntities: readonly ["orderAggregateEntity", "stockItemEntity"];
                readonly readsTables: readonly ["order_aggregate"];
                readonly writesTables: readonly ["order_aggregate"];
                readonly usecaseRefs: readonly ["usecaseAtualizarStatusPedido", "usecaseBaixarEstoqueIngredientes"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-order-status-transition", "rule-stock-deduct-by-ingredient"];
            }];
        };
    };
    export default kitchenQueuePagePlan;
}
declare module "_102043_/l2/cafeFlow/menuManagement.defs" {
    export const menuManagementPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "menuManagement";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 82;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "menuManagement";
                readonly pageName: "Gerenciar Cardápio";
                readonly actor: "gerente";
                readonly purpose: "Criar e manter itens do cardápio e suas receitas.";
                readonly capabilities: readonly ["gerenciarCardapio"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["menuItem", "ingredient"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "inventoryManagement";
                    readonly trigger: "ajustar ingredientes";
                    readonly description: "Ir para ajustes de estoque e ingredientes quando necessário.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Lista de itens do cardápio";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "listaItensCardapio";
                        readonly purpose: "Exibir itens existentes do cardápio com preço e resumo da receita.";
                        readonly userActions: readonly ["visualizarItem", "selecionarItemParaEdicao"];
                        readonly requiredEntities: readonly ["menuItemEntity", "recipeLineEntity"];
                        readonly readsFields: readonly ["MenuItem.id", "MenuItem.nome", "MenuItem.preco", "RecipeLine.ingredientId", "RecipeLine.quantidade"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-menuitem-recipe-required"];
                    }];
                }, {
                    readonly sectionName: "Criar novo item";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "formularioNovoItemCardapio";
                        readonly purpose: "Cadastrar item do cardápio com preço e receita obrigatória.";
                        readonly userActions: readonly ["informarNome", "informarPreco", "adicionarLinhaReceita", "removerLinhaReceita", "salvarItem"];
                        readonly requiredEntities: readonly ["menuItemEntity", "recipeLineEntity", "ingredientEntity"];
                        readonly readsFields: readonly ["Ingredient.id", "Ingredient.nome", "Ingredient.unidadeMedida"];
                        readonly writesFields: readonly ["MenuItem.nome", "MenuItem.preco", "RecipeLine.ingredientId", "RecipeLine.quantidade"];
                        readonly rulesApplied: readonly ["rule-menuitem-recipe-required"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listMenuItems";
                readonly purpose: "Exibir itens existentes do cardápio com preço e receita.";
                readonly kind: "query";
                readonly input: {
                    readonly filtros: {
                        readonly nome: "string?";
                        readonly ativo: "boolean?";
                    };
                };
                readonly output: {
                    readonly items: readonly [{
                        readonly id: "string";
                        readonly nome: "string";
                        readonly preco: "number";
                        readonly receita: readonly [{
                            readonly ingredientId: "string";
                            readonly quantidade: "number";
                        }];
                    }];
                };
                readonly readsEntities: readonly ["menuItemEntity", "recipeLineEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseGerenciarCardapio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-menuitem-recipe-required"];
            }, {
                readonly commandName: "listIngredientsForRecipe";
                readonly purpose: "Listar ingredientes disponíveis para compor a receita do item.";
                readonly kind: "query";
                readonly input: {
                    readonly filtros: {
                        readonly nome: "string?";
                    };
                };
                readonly output: {
                    readonly items: readonly [{
                        readonly id: "string";
                        readonly nome: "string";
                        readonly unidadeMedida: "string";
                    }];
                };
                readonly readsEntities: readonly ["ingredientEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseGerenciarCardapio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "createMenuItem";
                readonly purpose: "Criar novo item do cardápio com receita.";
                readonly kind: "command";
                readonly input: {
                    readonly nome: "string";
                    readonly preco: "number";
                    readonly receita: readonly [{
                        readonly ingredientId: "string";
                        readonly quantidade: "number";
                    }];
                };
                readonly output: {
                    readonly id: "string";
                    readonly nome: "string";
                    readonly preco: "number";
                    readonly receita: readonly [{
                        readonly ingredientId: "string";
                        readonly quantidade: "number";
                    }];
                };
                readonly readsEntities: readonly ["ingredientEntity"];
                readonly writesEntities: readonly ["menuItemEntity", "recipeLineEntity"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseGerenciarCardapio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-menuitem-recipe-required"];
            }];
        };
    };
    export default menuManagementPagePlan;
}
declare module "_102043_/l2/cafeFlow/posOrderConfirm.defs" {
    export const posOrderConfirmPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "posOrderConfirm";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 80;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "posOrderConfirm";
                readonly pageName: "POS - Confirmar Pedido";
                readonly actor: "caixa";
                readonly purpose: "Revisar itens e confirmar envio do pedido para a cozinha.";
                readonly capabilities: readonly ["registrarPedido"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["menuItem"];
                readonly pageInputs: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do pedido em rascunho para confirmação.";
                    readonly entityRef: "Order";
                    readonly fieldRef: "order_id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "posOrderCreate";
                    readonly trigger: "pedido montado";
                    readonly description: "Após montar itens e tipo de pedido.";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "kitchenQueue";
                    readonly trigger: "pedido enviado para cozinha";
                    readonly description: "Depois da confirmação do caixa.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo do pedido";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "orderSummaryPanel";
                        readonly purpose: "Exibir tipo de pedido, mesa e totais para validação do caixa.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["orderAggregateEntity"];
                        readonly readsFields: readonly ["order_type", "table_number", "item_count", "total_amount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-order-status-transition"];
                    }];
                }, {
                    readonly sectionName: "Itens do pedido";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "orderItemsList";
                        readonly purpose: "Revisar itens do pedido antes de enviar para a cozinha.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["orderAggregateEntity", "menuItemEntity"];
                        readonly readsFields: readonly ["details.items", "details.notes"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-menuitem-recipe-required"];
                    }];
                }, {
                    readonly sectionName: "Confirmação de envio";
                    readonly mode: "confirm";
                    readonly organisms: readonly [{
                        readonly organismName: "confirmSendToKitchenAction";
                        readonly purpose: "Confirmar envio do pedido para a cozinha.";
                        readonly userActions: readonly ["confirmOrderSendKitchen"];
                        readonly requiredEntities: readonly ["orderAggregateEntity"];
                        readonly readsFields: readonly ["order_id", "status"];
                        readonly writesFields: readonly ["status", "updated_at"];
                        readonly rulesApplied: readonly ["rule-order-status-transition"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getOrderDraft";
                readonly purpose: "Carregar resumo do pedido para confirmação.";
                readonly kind: "query";
                readonly input: {
                    readonly orderId: "uuid";
                };
                readonly output: {
                    readonly order: {
                        readonly orderId: "uuid";
                        readonly orderNumber: "string";
                        readonly orderType: "string";
                        readonly tableNumber: "string?";
                        readonly status: "string";
                        readonly itemCount: "number";
                        readonly totalAmount: "number";
                        readonly items: readonly [{
                            readonly menuItemId: "uuid";
                            readonly menuItemName: "string";
                            readonly quantity: "number";
                            readonly unitPrice: "number";
                            readonly lineTotal: "number";
                            readonly notes: "string?";
                        }];
                        readonly notes: "string?";
                    };
                };
                readonly readsEntities: readonly ["orderAggregateEntity", "menuItemEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order_aggregate"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseCriarPedido"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-menuitem-recipe-required"];
            }, {
                readonly commandName: "submitOrderToKitchen";
                readonly purpose: "Confirmar pedido e enviar para a cozinha.";
                readonly kind: "command";
                readonly input: {
                    readonly orderId: "uuid";
                    readonly confirmedByCashier: "boolean";
                };
                readonly output: {
                    readonly order: {
                        readonly orderId: "uuid";
                        readonly status: "string";
                        readonly updatedAt: "timestamp";
                    };
                };
                readonly readsEntities: readonly ["orderAggregateEntity"];
                readonly writesEntities: readonly ["orderAggregateEntity"];
                readonly readsTables: readonly ["order_aggregate"];
                readonly writesTables: readonly ["order_aggregate"];
                readonly usecaseRefs: readonly ["usecaseCriarPedido"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-order-status-transition"];
            }];
        };
    };
    export default posOrderConfirmPagePlan;
}
declare module "_102043_/l2/cafeFlow/posOrderCreate.defs" {
    export const posOrderCreatePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "posOrderCreate";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 79;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "posOrderCreate";
                readonly pageName: "POS - Novo Pedido";
                readonly actor: "caixa";
                readonly purpose: "Selecionar tipo de pedido e montar itens antes de confirmar envio à cozinha.";
                readonly capabilities: readonly ["registrarPedido"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["menuItem"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "posOrderConfirm";
                    readonly trigger: "continuar para confirmação";
                    readonly description: "Seguir para revisar itens e confirmar envio à cozinha.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Tipo de Pedido";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "orderTypeSelector";
                        readonly purpose: "Selecionar o tipo de pedido antes de adicionar itens.";
                        readonly userActions: readonly ["selectOrderType"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["orderAggregate.order_type", "orderAggregate.table_number"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Itens do Cardápio";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "menuItemCatalog";
                        readonly purpose: "Listar itens do cardápio disponíveis para seleção.";
                        readonly userActions: readonly ["addOrderItem"];
                        readonly requiredEntities: readonly ["MenuItem"];
                        readonly readsFields: readonly ["menuItem.id", "menuItem.name", "menuItem.price", "menuItem.category", "menuItem.availability"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["rule-menuitem-recipe-required"];
                    }, {
                        readonly organismName: "orderItemBuilder";
                        readonly purpose: "Adicionar itens selecionados ao rascunho do pedido.";
                        readonly userActions: readonly ["addOrderItem"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["orderAggregate.order_id", "orderAggregate.details.items"];
                        readonly writesFields: readonly ["orderAggregate.details.items", "orderAggregate.item_count", "orderAggregate.total_amount"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Resumo do Pedido";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "orderDraftSummary";
                        readonly purpose: "Exibir resumo do rascunho do pedido antes da confirmação.";
                        readonly userActions: readonly ["continueToConfirm"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["orderAggregate.order_id", "orderAggregate.order_type", "orderAggregate.table_number", "orderAggregate.item_count", "orderAggregate.total_amount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listMenuItems";
                readonly purpose: "Listar itens do cardápio disponíveis para venda.";
                readonly kind: "query";
                readonly input: {
                    readonly "categoryId?": "string";
                    readonly "onlyAvailable?": "boolean";
                };
                readonly output: {
                    readonly menuItems: readonly [{
                        readonly menuItemId: "string";
                        readonly name: "string";
                        readonly price: "number";
                        readonly categoryId: "string";
                        readonly availability: "string";
                    }];
                };
                readonly readsEntities: readonly ["menuItemEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["usecaseCriarPedido"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["rule-menuitem-recipe-required"];
            }, {
                readonly commandName: "startOrderDraft";
                readonly purpose: "Iniciar rascunho de pedido com tipo selecionado.";
                readonly kind: "command";
                readonly input: {
                    readonly orderType: "string";
                    readonly "tableNumber?": "string";
                };
                readonly output: {
                    readonly orderId: "string";
                    readonly orderType: "string";
                    readonly "tableNumber?": "string";
                    readonly items: readonly [];
                    readonly itemCount: "number";
                    readonly totalAmount: "number";
                };
                readonly readsEntities: readonly ["menuItemEntity", "dailyShiftEntity"];
                readonly writesEntities: readonly ["orderAggregateEntity"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["order_aggregate"];
                readonly usecaseRefs: readonly ["usecaseCriarPedido"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default posOrderCreatePagePlan;
}
